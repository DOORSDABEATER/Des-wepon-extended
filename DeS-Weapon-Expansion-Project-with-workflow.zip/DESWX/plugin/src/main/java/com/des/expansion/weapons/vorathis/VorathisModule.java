package com.des.expansion.weapons.vorathis;

import com.des.expansion.abilities.AbilityDef;
import com.des.expansion.abilities.Ctx;
import com.des.expansion.abilities.Prims;
import com.des.expansion.abilities.Weapon;
import com.des.expansion.core.DeSWeaponExpansion;
import com.des.expansion.core.Fx;
import com.des.expansion.data.Profile;
import com.des.expansion.data.Relic;
import com.des.expansion.utilities.Locs;
import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.world.ChunkLoadEvent;
import org.bukkit.event.world.ChunkUnloadEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * VORATHIS - THE SIXFOLD SOVEREIGN (SECRET). A living companion weapon (never handheld in combat form): one core + six fragments that follow
 * the wielder, six relics with independent physical items and persistent progression, 12 abilities. The item in the inventory is only the
 * "token" that summons/binds the companion; ordinary acquisition is disabled (admin commands only).
 */
public final class VorathisModule implements Weapon, Listener {
    public static final String KEY = "vorathis", NS = "deswx_vorathis:";
    static final Color CORE = Color.fromRGB(255, 236, 160);
    private final DeSWeaponExpansion pl;
    private final Map<String, AbilityDef> defs = new LinkedHashMap<>();
    private final List<String> sel = new ArrayList<>();
    private final CompanionManager comps; private final RelicDisplays relics;
    private final Map<UUID, Double> adapt = new HashMap<>();
    private final Map<UUID, UUID> witnessTarget = new HashMap<>(); private final Map<UUID, Long> witnessUntil = new HashMap<>(); private final Map<UUID, Boolean> glowPrev = new HashMap<>();
    private final Map<UUID, Location> domainCenter = new HashMap<>(); private final Map<UUID, Long> domainUntil = new HashMap<>();
    private BukkitTask decay;

    public VorathisModule(DeSWeaponExpansion pl) { this.pl = pl; comps = new CompanionManager(pl); relics = new RelicDisplays(pl); }
    public CompanionManager companions() { return comps; }
    public RelicDisplays displays() { return relics; }

    private void reg(String id, String name, double cd, AbilityDef.Runner r, boolean ult) { defs.put(id, new AbilityDef(KEY, id, name, cd, 0, ult, false, r)); sel.add(id); }

    public void enable() {
        reg("sovereigns_arrival", "SOVEREIGN'S ARRIVAL", 10, this::arrival, false);
        reg("voidstep", "VOIDSTEP", 12, this::voidstep, false);
        reg("judgement_of_the_witness", "JUDGEMENT OF THE WITNESS", 16, this::witness, false);
        reg("seconds_reprieve", "SECOND'S REPRIEVE", 24, this::reprieve, false);
        reg("gravitys_embrace", "GRAVITY'S EMBRACE", 22, this::gravity, false);
        reg("genesis_shatter", "GENESIS SHATTER", 20, this::genesis, false);
        reg("ashes_of_tomorrow", "ASHES OF TOMORROW", 22, this::ashes, false);
        reg("unbound_domain", "UNBOUND DOMAIN", 40, this::domain, false);
        reg("fractured_horizon", "FRACTURED HORIZON", 24, this::horizon, false);
        reg("the_unnamed_law", "THE UNNAMED LAW", 30, this::law, false);
        reg("sixfold_reckoning", "SIXFOLD RECKONING", 45, this::reckoning, false);
        reg("beyond_the_impossible", "BEYOND THE IMPOSSIBLE", 180, this::beyond, true);
        comps.start(); relics.start();
        decay = new BukkitRunnable() { @Override public void run() { adapt.replaceAll((k, v) -> Math.max(0, v - 2)); adapt.values().removeIf(v -> v <= 0); } }.runTaskTimer(pl, 40L, 40L);
    }

    public void disable() {
        if (decay != null) decay.cancel();
        for (Map.Entry<UUID, UUID> e : witnessTarget.entrySet()) { org.bukkit.entity.Entity t = Bukkit.getEntity(e.getValue()); if (t != null) t.setGlowing(glowPrev.getOrDefault(e.getValue(), false)); }
        comps.stop(); relics.stop();
    }

    // ------------------------------------------------------------------ progression API (independent from physical items)
    public void setRelic(UUID id, Relic r, boolean on) {
        Profile pr = pl.profiles.get(id); boolean was = pr.relicUnlocked[r.index()]; pr.relicUnlocked[r.index()] = on; pl.profiles.saveSync(id);
        Player p = Bukkit.getPlayer(id);
        if (p != null) { comps.refresh(p); if (on && !was) awaken(p, r); }
    }
    public void setAll(UUID id, boolean on) { Profile pr = pl.profiles.get(id); for (Relic r : Relic.values()) pr.relicUnlocked[r.index()] = on; pl.profiles.saveSync(id); Player p = Bukkit.getPlayer(id); if (p != null) { comps.refresh(p); if (on) awaken(p, Relic.UNNAMED); } }
    public void resetProgress(UUID id) { Profile pr = pl.profiles.get(id); for (Relic r : Relic.values()) pr.relicUnlocked[r.index()] = false; pr.vorathisXp = 0; adapt.remove(id); pl.profiles.saveSync(id); Player p = Bukkit.getPlayer(id); if (p != null) comps.refresh(p); }

    /** Visual awakening: fragment flare + burst + sound, appearance already refreshed by the caller. */
    public void awaken(Player p, Relic r) {
        pl.tasks.later(p.getUniqueId(), 8, () -> {
            Location c = comps.coreLoc(p); pl.fx.sound(c, NS + "r" + r.index() + "_awaken", 1.4f, 1f);
            Fx.Aud a = pl.fx.at(c); pl.fx.sphere(a, c, 1.6, 30, r.color, 1.4f); pl.fx.ring(a, c, 2.2, 30, 0, r.color, 1.3f); a.dust(c, 20, 0.8, CORE, 1.2f);
            comps.form(p, 40, (idx, t) -> idx == r.index() ? c.clone().add(0, 1.2 + Math.sin(t * 0.2) * 0.2, 0) : null);
            p.sendMessage(net.kyori.adventure.text.minimessage.MiniMessage.miniMessage().deserialize("<white>[VORATHIS] <gray>" + r.display + " <white>awakens. <dark_gray>(" + r.authority + ")"));
        });
    }

    public void toggleSummon(Player p) {
        Profile pr = pl.profiles.get(p.getUniqueId());
        if (!pl.items.has(p, KEY)) return;
        pr.vorathisSummoned = !pr.vorathisSummoned; comps.refresh(p);
        pl.abilities.msg(p, pr.vorathisSummoned ? "<white>VORATHIS <gray>answers your call" : "<white>VORATHIS <gray>rests");
    }

    // ------------------------------------------------------------------ Weapon
    @Override public String key() { return KEY; }
    @Override public String display() { return "VORATHIS"; }
    @Override public Map<String, AbilityDef> abilities() { return defs; }
    @Override public List<String> selectable() { return sel; }
    @Override public String ultimateId() { return "beyond_the_impossible"; }
    @Override public boolean holds(Player p) { return pl.items.holds(p, KEY); }
    @Override public String resourceName() { return "Adaptation"; }
    @Override public double resource(Player p) { return adapt.getOrDefault(p.getUniqueId(), 0.0); }
    @Override public boolean spend(Player p, double a) { return true; }

    private Relic[] requires(String id) {
        return switch (id) {
            case "voidstep", "gravitys_embrace", "fractured_horizon" -> new Relic[]{Relic.WEIGHTLESS_HEART};
            case "judgement_of_the_witness" -> new Relic[]{Relic.WITNESS};
            case "seconds_reprieve" -> new Relic[]{Relic.LAST_SECOND};
            case "genesis_shatter" -> new Relic[]{Relic.FIRST_SPARK};
            case "ashes_of_tomorrow" -> new Relic[]{Relic.FINAL_REMNANT};
            case "the_unnamed_law" -> new Relic[]{Relic.UNNAMED};
            case "beyond_the_impossible" -> Relic.values();
            default -> new Relic[0];
        };
    }

    @Override public String blockReason(Player p, AbilityDef d, boolean forced) {
        if (forced) return null;                                                       // /vorathis test bypasses gating (admin)
        if (!pl.cfg.b("vorathis.yml", "enabled", true)) return "VORATHIS is disabled";
        if (!p.hasPermission("deswx.vorathis.use")) return "no permission";
        Profile pr = pl.profiles.get(p.getUniqueId());
        if (d.id().equals("sixfold_reckoning") && pr.relicCount() < 1) return "needs at least one awakened relic";
        for (Relic r : requires(d.id())) if (!pr.relicUnlocked[r.index()]) return "requires " + r.display + " (" + r.authority + ")";
        return null;
    }

    @Override public String hud(Player p) {
        int sIdx = pl.abilities.selected(p, KEY); AbilityDef d = defs.get(sel.get(sIdx)); Profile pr = pl.profiles.get(p.getUniqueId()); long cd = pl.cooldowns.remainingMs(p, d.key());
        String st = blockReason(p, d, false) != null ? "<dark_gray>LOCKED" : cd > 0 ? "<red>" + String.format("%.1fs", cd / 1000.0) : "<green>READY";
        return "<white><bold>VORATHIS</bold> <dark_gray>| <gold>" + pr.stageName() + " <dark_gray>| <white>" + pr.relicCount() + "<gray>/6 <dark_gray>| <yellow>" + (sIdx + 1) + ". " + d.name() + " " + st;
    }

    @Override public void onFirstHit(Ctx c, LivingEntity t) {
        UUID o = c.p.getUniqueId(); adapt.merge(o, pl.cfg.d("vorathis.yml", "adaptation.per-hit", 4), Double::sum); if (adapt.get(o) > 100) adapt.put(o, 100.0); c.prof.vorathisXp++;
        if (t.getUniqueId().equals(witnessTarget.get(o)) && witnessUntil.getOrDefault(o, 0L) > System.currentTimeMillis()) endWitness(o);
    }

    @Override public double damageMult(Ctx c, LivingEntity t) {
        UUID o = c.p.getUniqueId(); double m = 1.0 + adapt.getOrDefault(o, 0.0) / 100.0 * pl.cfg.d("vorathis.yml", "adaptation.max-damage-bonus", 0.10);
        if (t.getUniqueId().equals(witnessTarget.get(o)) && witnessUntil.getOrDefault(o, 0L) > System.currentTimeMillis()) m *= pl.cfg.ab(KEY, "judgement_of_the_witness", "strike-multiplier", 1.35);
        Location dc = domainCenter.get(o); if (dc != null && domainUntil.getOrDefault(o, 0L) > System.currentTimeMillis() && dc.getWorld() == c.p.getWorld() && dc.distanceSquared(c.p.getLocation()) <= 64) m *= pl.cfg.ab(KEY, "unbound_domain", "damage-multiplier", 1.2);
        return m;
    }

    @Override public void onMelee(Player p, LivingEntity v, EntityDamageByEntityEvent e) {
        UUID o = p.getUniqueId(); pl.combat.tag(p, v, KEY);
        if (v.getUniqueId().equals(witnessTarget.get(o)) && witnessUntil.getOrDefault(o, 0L) > System.currentTimeMillis()) { e.setDamage(e.getDamage() * 1.35); endWitness(o); }
    }
    @Override public void onHurt(Player p, EntityDamageEvent e, LivingEntity attacker) { if (comps.exists(p)) { comps.flinch(p); adapt.merge(p.getUniqueId(), 3.0, Double::sum); } }
    @Override public void abort(Player p) {
        UUID id = p.getUniqueId(); comps.despawn(id); comps.clearHistory(id); endWitness(id); domainCenter.remove(id); domainUntil.remove(id); adapt.remove(id);
    }

    private void endWitness(UUID o) {
        UUID t = witnessTarget.remove(o); witnessUntil.remove(o); if (t == null) return;
        org.bukkit.entity.Entity e = Bukkit.getEntity(t); if (e != null) e.setGlowing(glowPrev.getOrDefault(t, false)); glowPrev.remove(t);
    }

    // relic display events
    @EventHandler public void chunkLoad(ChunkLoadEvent e) { relics.chunkLoaded(e.getChunk()); }
    @EventHandler public void chunkUnload(ChunkUnloadEvent e) { relics.chunkUnloaded(e.getChunk()); }
    @EventHandler public void breakBlock(BlockBreakEvent e) { if (relics.isPedestal(e.getBlock()) && !e.getPlayer().hasPermission("deswx.admin")) { e.setCancelled(true); e.getPlayer().sendActionBar(net.kyori.adventure.text.minimessage.MiniMessage.miniMessage().deserialize("<red>This block supports a protected relic.")); } }

    // ------------------------------------------------------------------ helpers
    private boolean ensure(Player p) {
        if (comps.exists(p)) return true;
        Profile pr = pl.profiles.get(p.getUniqueId()); if (!pl.items.has(p, KEY)) return false;
        pr.vorathisSummoned = true; comps.refresh(p); return true;       // companion is created by its next tick
    }
    private Color rc(int i) { return Relic.values()[i].color; }
    private Location frag(Player p, int i) { return comps.fragLoc(p, i); }

    // ------------------------------------------------------------------ abilities
    private boolean arrival(Ctx c) {
        Player p = c.p; if (!ensure(p)) return false; List<LivingEntity> es = new ArrayList<>(pl.combat.enemies(p, p.getLocation(), c.v("range", 16)));
        if (es.isEmpty()) { pl.abilities.msg(p, "<red>SOVEREIGN'S ARRIVAL <gray>- no enemies nearby"); return false; }
        es.sort(Comparator.comparingDouble(e -> e.getLocation().distanceSquared(p.getLocation()))); c.maxHits = 2;
        final Location[] pos = new Location[6]; final boolean[] out = new boolean[6], done = new boolean[6]; for (int i = 0; i < 6; i++) pos[i] = frag(p, i);
        comps.form(p, 160, (idx, t) -> idx < 0 ? null : pos[idx]); pl.fx.sound(p.getLocation(), NS + "a01_arrival", 1.3f, 1f); p.swingMainHand();
        double speed = c.v("speed", 1.5), dmg = c.v("damage", 4);
        pl.tasks.timer(p.getUniqueId(), 1, 1, 100, t -> {
            if (!c.alive()) return false; boolean all = true;
            for (int i = 0; i < 6; i++) {
                if (done[i]) continue; all = false; Fx.Aud a = pl.fx.at(pos[i]); a.dust(pos[i], 3, 0.15, rc(i), 1.1f);
                LivingEntity tg = es.get(i % es.size());
                if (!out[i] && t >= i * 2) { if (!tg.isValid() || tg.isDead()) { out[i] = true; continue; } Location aim = tg.getLocation().add(0, tg.getHeight() / 2, 0); Vector to = aim.toVector().subtract(pos[i].toVector()); double d = to.length();
                    if (d < 1.2) { if (c.hit(tg, dmg)) { pl.fx.at(aim).dust(aim, 12, 0.4, rc(i), 1.2f); pl.fx.sound(aim, NS + "a01_arrival", 0.5f, 1.4f); } out[i] = true; } else pos[i].add(to.normalize().multiply(Math.min(d, speed))); }
                else if (out[i]) { Location home = comps.coreLoc(p); Vector to = home.toVector().subtract(pos[i].toVector()); double d = to.length(); if (d < 1.2) done[i] = true; else pos[i].add(to.normalize().multiply(Math.min(d, speed * 1.3))); }
            }
            return !all;
        }, () -> comps.endForm(p));
        return true;
    }

    private boolean voidstep(Ctx c) {
        Player p = c.p; Location start = p.getLocation().clone(); Vector dir = p.getEyeLocation().getDirection().clone(); dir.setY(Math.max(-0.3, Math.min(0.3, dir.getY()))).normalize(); Location last = start.clone();
        for (double d = 0.5; d <= c.v("distance", 8); d += 0.5) { Location l = start.clone().add(dir.clone().multiply(d)); if (!Locs.standable(l)) break; last = l; }
        while (last.distanceSquared(start) > 1 && !Locs.hasFloor(last, 5)) last.subtract(dir.clone().multiply(0.5));
        if (last.distanceSquared(start) < 1) { pl.abilities.msg(p, "<red>VOIDSTEP <gray>- no safe space ahead"); return false; }
        final Location end = last; last.setYaw(start.getYaw()); last.setPitch(start.getPitch());
        for (Location l : new Location[]{start, end}) { ItemDisplay r = pl.fx.display(p.getUniqueId(), l.clone().add(0, 1, 0), NS + "rift", 2.6f, Fx.orient(new Vector(0, 1, 0), dir), true, rc(2), 0); if (r != null) pl.tasks.later(p.getUniqueId(), 12, () -> pl.tasks.release(p.getUniqueId(), r)); }
        pl.fx.line(pl.fx.at(start), start.clone().add(0, 1, 0), end.clone().add(0, 1, 0), 0.3, rc(2), 1.3f); pl.fx.sound(start, NS + "a02_voidstep", 1.2f, 1f);
        p.teleport(end); p.setVelocity(new Vector(0, 0, 0)); pl.fx.sound(end, NS + "a02_voidstep", 1.2f, 1.3f); pl.fx.sphere(pl.fx.at(end), end.clone().add(0, 1, 0), 1.2, 20, rc(2), 1.3f); return true;
    }

    private boolean witness(Ctx c) {
        Player p = c.p; UUID o = p.getUniqueId(); LivingEntity t = Prims.aimTarget(c, c.v("range", 26), 25);
        if (t == null) { pl.abilities.msg(p, "<red>JUDGEMENT OF THE WITNESS <gray>- no target in sight"); return false; }
        endWitness(o); witnessTarget.put(o, t.getUniqueId()); witnessUntil.put(o, System.currentTimeMillis() + (long) (c.v("duration-seconds", 8) * 1000));
        glowPrev.put(t.getUniqueId(), t.isGlowing()); t.setGlowing(true); ensure(p); p.swingMainHand();
        pl.fx.sound(t.getLocation(), NS + "a03_witness", 1.3f, 1f);
        comps.form(p, 50, (idx, tt) -> idx == 0 && t.isValid() ? t.getLocation().add(0, t.getHeight() + 1.0, 0) : null);
        pl.fx.ring(pl.fx.at(t.getLocation()), t.getLocation().add(0, 0.1, 0), 1.6, 24, 0, rc(0), 1.4f);
        pl.tasks.later(o, (long) (c.v("duration-seconds", 8) * 20) + 2, () -> { if (t.getUniqueId().equals(witnessTarget.get(o))) endWitness(o); });
        pl.abilities.msg(p, "<white>THE WITNESS sees <gray>" + t.getName() + " <white>- your next strike is improved"); return true;
    }

    private boolean reprieve(Ctx c) {
        Player p = c.p; Location dest = comps.rewind(p, c.v("seconds", 4));
        if (dest == null || dest.getWorld() != p.getWorld() || dest.distanceSquared(p.getLocation()) > 1600 || dest.distanceSquared(p.getLocation()) < 4 || !Locs.standable(dest) || !Locs.hasFloor(dest, 6)) { pl.abilities.msg(p, "<red>SECOND'S REPRIEVE <gray>- no safe recent position"); return false; }
        Location from = p.getLocation(); pl.fx.line(pl.fx.at(from), from.clone().add(0, 1, 0), dest.clone().add(0, 1, 0), 0.3, rc(1), 1.2f); pl.fx.sound(from, NS + "a04_reprieve", 1.3f, 1f);
        for (Location l : new Location[]{from, dest}) pl.fx.sphere(pl.fx.at(l), l.clone().add(0, 1, 0), 1.0, 18, rc(1), 1.2f);
        dest.setYaw(from.getYaw()); dest.setPitch(from.getPitch()); p.teleport(dest); p.setVelocity(new Vector(0, 0, 0));   // position only: health, items and world state are untouched
        pl.fx.sound(dest, NS + "a04_reprieve", 1.2f, 1.4f); return true;
    }

    private boolean gravity(Ctx c) {
        Player p = c.p; ensure(p); Prims.F f = new Prims.F(); f.center = Prims.aimPoint(p, c.v("range", 16)); f.radius = c.v("radius", 6); f.pull = c.v("pull", 0.5); f.ticks = c.vi("duration-ticks", 60); f.endDmg = c.v("collapse-damage", 7); f.endKnock = 0.8;
        f.c1 = rc(2); f.c2 = CORE; f.model = NS + "rift"; f.coreModel = NS + "sigil"; f.coreScale = 2.0f; f.tickSound = NS + "a05_gravity"; f.soundEvery = 40; f.endSound = NS + "a05_gravity"; final Location ctr = f.center;
        comps.form(p, f.ticks + 4, (idx, t) -> { if (idx < 0) return null; double a = t * 0.35 + idx * Math.PI / 3; return ctr.clone().add(Math.cos(a) * 2.6, 2.2 + Math.sin(t * 0.2 + idx) * 0.3, Math.sin(a) * 2.6); });
        p.swingMainHand(); pl.fx.sound(ctr, NS + "a05_gravity", 1.3f, 1f); f.onEnd = () -> comps.endForm(p); Prims.field(c, f); return true;
    }

    private boolean genesis(Ctx c) {
        Player p = c.p; ensure(p); int wind = c.vi("charge-ticks", 18); p.swingMainHand(); pl.fx.sound(p.getLocation(), NS + "a06_genesis", 1.4f, 1f);
        comps.form(p, wind + 6, (idx, t) -> { if (idx < 0) return null; Location e = p.getEyeLocation(); Vector d = e.getDirection(); return e.clone().add(d.clone().multiply(1.6 + idx * 0.7)).add(0, Math.sin(t * 0.3 + idx) * 0.1 - 0.2, 0); });
        pl.tasks.timer(p.getUniqueId(), 1, 1, wind, t -> { Location e = p.getEyeLocation(); pl.fx.at(e).trans(e.clone().add(e.getDirection().multiply(2.5)), 6, 0.5, rc(3), CORE, 1.4f); return c.alive(); }, () -> {
            comps.endForm(p); if (!c.alive()) return; Location e = p.getEyeLocation(); Vector dir = e.getDirection().clone().normalize(); pl.fx.sound(p.getLocation(), NS + "a06_genesis", 1.5f, 1.2f);
            Prims.P s = new Prims.P(); s.model = NS + "construct"; s.scale = 3f; s.start = e.clone().add(dir.clone().multiply(1.8)); s.dir = dir; s.range = c.v("range", 18); s.speed = c.v("speed", 1.6); s.radius = c.v("hit-radius", 2.2); s.dmg = c.v("damage", 14);
            s.c1 = rc(3); s.c2 = CORE; s.arc = false; s.glow = rc(3); s.hitSound = NS + "a06_genesis"; s.onEnd = end -> pl.fx.sphere(pl.fx.at(end), end, 1.6, 24, rc(3), 1.4f); Prims.projectile(c, s); });
        return true;
    }

    private boolean ashes(Ctx c) {
        Player p = c.p; Prims.F f = new Prims.F(); f.center = Prims.aimPoint(p, c.v("range", 14)); f.radius = c.v("radius", 5.5); f.ticks = c.vi("duration-ticks", 100); f.tickDmg = c.v("tick-damage", 1.5); f.slowAmp = 0; f.c1 = rc(4); f.c2 = Color.fromRGB(90, 90, 80);
        f.model = NS + "rift"; f.tickSound = NS + "a07_ashes"; f.soundEvery = 40; final Location ctr = f.center; final int weak = c.vi("weakness-ticks", 60);
        f.onTick = t -> { pl.fx.at(ctr).particle(Particle.ASH, ctr.clone().add(0, 1.5, 0), 12, f.radius * 0.5, 1.2, f.radius * 0.5, 0.01);
            if (t % 5 == 0) for (LivingEntity e : pl.combat.enemies(p, ctr, f.radius)) if (!pl.combat.isBoss(e)) e.addPotionEffect(new PotionEffect(PotionEffectType.WEAKNESS, weak, 0, false, true, true)); };
        p.swingMainHand(); pl.fx.sound(ctr, NS + "a07_ashes", 1.3f, 1f); Prims.field(c, f); return true;
    }

    private boolean domain(Ctx c) {
        Player p = c.p; UUID o = p.getUniqueId(); ensure(p); int dur = c.vi("duration-ticks", 140); double rad = c.v("radius", 8); Location ctr = Locs.ground(p.getLocation());
        domainCenter.put(o, ctr); domainUntil.put(o, System.currentTimeMillis() + dur * 50L); pl.fx.sound(ctr, NS + "a08_domain", 1.4f, 1f); p.swingMainHand();
        comps.form(p, dur, (idx, t) -> { if (idx < 0) return null; double a = t * 0.22 + idx * Math.PI / 3; return ctr.clone().add(Math.cos(a) * 3.2, 2.4 + Math.sin(t * 0.1 + idx) * 0.5, Math.sin(a) * 3.2); });
        ItemDisplay ring = pl.fx.display(o, ctr.clone().add(0, 0.12, 0), NS + "rift", (float) (rad * 2.13), Fx.flat(), false, null, 0);
        pl.tasks.timer(o, 2, 2, dur / 2, t -> {
            if (!c.alive()) return false; Fx.Aud a = pl.fx.at(ctr); for (int i = 0; i < 6; i++) pl.fx.ring(a, ctr.clone().add(0, 0.15 + i * 0.05, 0), rad - i * 0.3, (int) (rad * 3), t * 0.1 + i, rc(i), 1.0f);
            if (p.getWorld() == ctr.getWorld() && p.getLocation().distanceSquared(ctr) <= rad * rad) { p.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 30, 0, false, false, true)); p.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, 30, 0, false, false, true)); }
            return true;
        }, () -> { pl.tasks.release(o, ring); comps.endForm(p); domainCenter.remove(o); domainUntil.remove(o); });
        return true;
    }

    private boolean horizon(Ctx c) {
        Player p = c.p; UUID o = p.getUniqueId(); ensure(p); LivingEntity t = Prims.aimTarget(c, c.v("range", 20), 35); if (t == null) { List<LivingEntity> es = pl.combat.enemies(p, p.getLocation(), c.v("range", 20)); if (es.isEmpty()) { pl.abilities.msg(p, "<red>FRACTURED HORIZON <gray>- no target"); return false; } t = es.get(0); }
        final LivingEntity tg = t; c.maxHits = 6; final Location[] pos = new Location[6]; final boolean[] go = new boolean[6], done = new boolean[6]; final Vector[] dir = new Vector[6]; for (int i = 0; i < 6; i++) pos[i] = frag(p, i);
        comps.form(p, 120, (idx, tt) -> idx < 0 ? null : pos[idx]); pl.fx.sound(tg.getLocation(), NS + "a09_horizon", 1.3f, 1f); p.swingMainHand(); double base = Math.random() * 6.28;
        for (int i = 0; i < 6; i++) { final int k = i; pl.tasks.later(o, 4L + i * 4, () -> {
            if (!c.alive() || !tg.isValid() || tg.isDead()) { done[k] = true; return; }
            Location tc = tg.getLocation().add(0, tg.getHeight() / 2, 0); double a = base + k * 1.047; Location r = tc.clone().add(Math.cos(a) * 5, 0.5 + (k % 3) * 0.8, Math.sin(a) * 5); dir[k] = tc.toVector().subtract(r.toVector()).normalize();
            ItemDisplay rift = pl.fx.display(o, r, NS + "rift", 2.2f, Fx.orient(new Vector(0, 1, 0), dir[k]), true, rc(2), 0); if (rift != null) pl.tasks.later(o, 14, () -> pl.tasks.release(o, rift));
            pos[k] = r.clone(); go[k] = true; pl.fx.sound(r, NS + "a09_horizon", 0.6f, 1f + k * 0.1f); }); }
        pl.tasks.timer(o, 1, 1, 90, t2 -> {
            if (!c.alive()) return false; boolean all = true;
            for (int i = 0; i < 6; i++) { if (done[i]) continue; all = false; if (!go[i]) continue; pos[i].add(dir[i].clone().multiply(2.0)); pl.fx.at(pos[i]).dust(pos[i], 4, 0.15, rc(i), 1.2f);
                for (LivingEntity e : pl.combat.enemies(p, pos[i], 1.6)) if (c.hit(e, c.v("damage", 3.5))) { pl.fx.at(e.getLocation()).dust(e.getLocation().add(0, 1, 0), 10, 0.3, rc(i), 1.2f); done[i] = true; }
                if (pos[i].distanceSquared(tg.getLocation()) > 400 || t2 > 70) done[i] = true; }
            return !all;
        }, () -> comps.endForm(p));
        return true;
    }

    private static boolean beneficial(PotionEffect e) { return e.getType().getCategory() == PotionEffectType.Category.BENEFICIAL; }

    private boolean law(Ctx c) {
        Player p = c.p; LivingEntity t = Prims.aimTarget(c, c.v("range", 20), 25); if (t == null) { pl.abilities.msg(p, "<red>THE UNNAMED LAW <gray>- no target in sight"); return false; }
        if (pl.combat.isBoss(t)) { pl.abilities.msg(p, "<yellow>THE UNNAMED LAW <gray>- the target is beyond its reach"); return false; }
        int ticks = t instanceof Player ? Math.min(c.vi("duration-ticks", 60), 60) : c.vi("duration-ticks", 60) * 2; final long start = System.currentTimeMillis();
        List<PotionEffect> removed = new ArrayList<>(); for (PotionEffect e : t.getActivePotionEffects()) if (beneficial(e)) { removed.add(e); t.removePotionEffect(e.getType()); }
        if (t instanceof Player tp) {
            Material m = tp.getInventory().getItemInMainHand().getType(); if (m != Material.AIR) tp.setCooldown(m, Math.min(ticks, 60));
            for (com.des.expansion.abilities.Weapon w : pl.abilities.all()) if (w.holds(tp)) { String id = w.selectable().get(pl.abilities.selected(tp, w.key())); pl.cooldowns.set(tp, w.key() + ":" + id, Math.max(ticks / 20.0, pl.cooldowns.remainingMs(tp, w.key() + ":" + id) / 1000.0)); }
        }
        pl.fx.sound(t.getLocation(), NS + "a10_law", 1.5f, 1f); p.swingMainHand(); Location l = t.getLocation().add(0, t.getHeight() / 2, 0);
        pl.fx.sphere(pl.fx.at(l), l, 1.4, 30, rc(5), 1.4f); pl.fx.crack(pl.fx.at(l), p.getEyeLocation(), l, 0.8, rc(5), 1.2f);
        c.hit(t, c.v("damage", 5));
        pl.tasks.later(p.getUniqueId(), ticks, () -> { if (!t.isValid() || t.isDead()) return; int elapsed = (int) ((System.currentTimeMillis() - start) / 50);
            for (PotionEffect e : removed) { int left = e.getDuration() - elapsed; if (left > 0 && e.getDuration() < 20 * 600) t.addPotionEffect(new PotionEffect(e.getType(), left, e.getAmplifier(), e.isAmbient(), e.hasParticles(), e.hasIcon())); }
            pl.fx.at(t.getLocation()).dust(t.getLocation().add(0, 1, 0), 12, 0.4, rc(5), 1.1f); });
        return true;
    }

    private boolean reckoning(Ctx c) {
        Player p = c.p; Profile pr = c.prof; ensure(p); int n = pr.relicCount(); c.maxHits = 3; Location ctr = Prims.aimPoint(p, c.v("range", 12)); double rad = c.v("radius", 7);
        comps.form(p, 60, (idx, t) -> idx < 0 || !pr.relicUnlocked[idx] ? null : ctr.clone().add(Math.cos(t * 0.3 + idx * 1.05) * 2.0, 3.0 + Math.sin(t * 0.2) * 0.3, Math.sin(t * 0.3 + idx * 1.05) * 2.0));
        pl.fx.sound(ctr, NS + "a11_reckoning", 1.6f, 1f); p.swingMainHand(); UUID o = p.getUniqueId();
        Prims.telegraph(c, ctr, rad, 20, CORE, rc(0), () -> {
            comps.endForm(p); double dmg = Math.min(c.v("max-damage", 14), c.v("base-damage", 6) + n * c.v("damage-per-relic", 1.5));
            Prims.burst(c, ctr, rad, dmg, 1.0, CORE, rc(0), true);
            for (int i = 0; i < 6; i++) if (pr.relicUnlocked[i]) { final int k = i; pl.tasks.later(o, i * 2L, () -> pl.fx.ring(pl.fx.at(ctr), ctr.clone().add(0, 0.3 + k * 0.1, 0), 2 + k * 1.1, 40, 0, rc(k), 1.5f)); }
            List<LivingEntity> es = pl.combat.enemies(p, ctr, rad + 3);
            if (pr.relicUnlocked[0]) for (LivingEntity e : es) { boolean prev = e.isGlowing(); e.setGlowing(true); pl.tasks.later(o, 50, () -> { if (e.isValid()) e.setGlowing(prev); }); }
            if (pr.relicUnlocked[1]) pl.tasks.later(o, 20, () -> { if (c.alive()) { pl.fx.sound(ctr, NS + "a04_reprieve", 1f, 1.5f); Prims.burst(c, ctr, rad, 3, 0, rc(1), CORE, true); } });
            if (pr.relicUnlocked[2]) for (LivingEntity e : es) pl.combat.push(p, e, ctr.toVector().subtract(e.getLocation().toVector()).setY(0.2).normalize().multiply(0.5), c.castId);
            if (pr.relicUnlocked[3]) { Vector d = ctr.toVector().subtract(p.getEyeLocation().toVector()).normalize(); Prims.P s = new Prims.P(); s.model = NS + "construct"; s.scale = 2.4f; s.start = p.getEyeLocation().add(d.clone().multiply(1.5)); s.dir = d; s.range = 14; s.speed = 1.8; s.radius = 1.8; s.dmg = 5; s.c1 = rc(3); s.c2 = CORE; s.arc = false; s.glow = rc(3); Prims.projectile(c, s); }
            if (pr.relicUnlocked[4]) for (LivingEntity e : es) if (!pl.combat.isBoss(e)) e.addPotionEffect(new PotionEffect(PotionEffectType.WEAKNESS, 80, 0, false, true, true));
            if (pr.relicUnlocked[5]) for (LivingEntity e : es) if (e instanceof Player tp) for (com.des.expansion.abilities.Weapon w : pl.abilities.all()) if (w.holds(tp)) pl.cooldowns.set(tp, w.key() + ":" + w.selectable().get(pl.abilities.selected(tp, w.key())), 2);
        });
        return true;
    }

    private boolean beyond(Ctx c) {
        final Player p = c.p; final UUID o = p.getUniqueId(); if (!ensure(p)) return false; c.maxHits = 1; pl.abilities.setBusy(p, true);
        final Location ctr = Locs.ground(Prims.aimPoint(p, 10)); final double rad = c.v("final-radius", 7); final ItemDisplay[] beam = {null};
        comps.form(p, 140, (idx, t) -> {
            if (idx < 0) return null; Location pc = p.getLocation().add(0, 1.5, 0); double tt = t / 2.0;
            if (tt < 60) { double R = 2.5 + 3.5 * Math.min(1, tt / 40.0), a = tt * 0.3 * (idx % 2 == 0 ? 1 : -1) + idx * Math.PI / 3, tilt = 0.25 + 0.3 * idx; return pc.clone().add(Math.cos(a) * R * Math.cos(tilt), Math.sin(a) * R * Math.sin(tilt) * 0.8, Math.sin(a) * R * Math.cos(tilt)); }
            double f = Math.min(1, (tt - 60) / 20.0); Location ring = pc.clone().add(Math.cos(idx * 1.047) * 6, 0, Math.sin(idx * 1.047) * 6); Location tgt = ctr.clone().add(0, 3, 0); return ring.add(tgt.toVector().subtract(ring.toVector()).multiply(f));
        });
        pl.tasks.timer(o, 0, 1, 112, t -> {
            if (!c.alive()) return false; Location pc = p.getLocation(); Fx.Aud a = pl.fx.at(pc);
            if (t == 0) { pl.fx.sound(pc, NS + "a12_charge", 3f, 1f); comps.setScale(p, 3.4f); titleNear(p, rad + 20, "<white><bold>VORATHIS REVEALS ITS TRUE FORM</bold>", "<gray>stand clear"); Prims.telegraph(c, ctr, rad * 1.5, 40, CORE, rc(0), null); }
            if (t < 60) { for (int i = 0; i < 6; i++) a.dust(pc.clone().add(0, 1.5, 0).add(Math.cos(t * 0.3 + i) * 3, Math.sin(t * 0.2 + i) * 1.5, Math.sin(t * 0.3 + i) * 3), 2, 0.1, rc(i), 1.3f); pl.fx.sphere(a, pc.clone().add(0, 1.2, 0), 2.6, 12, CORE, 1.1f); }
            if (t == 60) { pl.fx.sound(pc, NS + "a12_charge", 2f, 1.3f); Vector d = ctr.clone().add(0, 3, 0).toVector().subtract(pc.clone().add(0, 1.5, 0).toVector()); double len = d.length(); d.normalize(); Vector perp = d.clone().crossProduct(Prims.UP); if (perp.lengthSquared() < 1e-4) perp = new Vector(1, 0, 0); perp.normalize();
                beam[0] = pl.fx.display(o, pc.clone().add(0, 1.5, 0).add(d.clone().multiply(len / 2)), NS + "beam", new Vector3f(1.6f, 1.6f, (float) (len / 1.875)), Fx.orient(perp, d), true, CORE, 0); }
            if (t == 80) Prims.telegraph(c, ctr, rad, 24, rc(2), CORE, null);
            if (t >= 60 && t < 104) pl.fx.sphere(pl.fx.at(ctr), ctr.clone().add(0, 3, 0), 3.5 * (1 - (t - 60) / 44.0) + 0.8, 24, CORE, 1.5f);
            if (t == 104) { pl.fx.sound(ctr, NS + "a12_strike", 5f, 1f); Prims.burst(c, ctr, rad, c.v("final-damage", 28), 1.3, CORE, rc(0), true);
                for (int i = 0; i < 6; i++) { final int k = i; pl.tasks.later(o, i * 2L, () -> { pl.fx.ring(pl.fx.at(ctr), ctr.clone().add(0, 0.3, 0), 3 + k * 1.6, 56, 0, rc(k), 1.8f); pl.fx.sphere(pl.fx.at(ctr), ctr.clone().add(0, 3, 0), 2.5 + k * 0.9, 36, rc(k), 1.6f); }); } }
            return t < 111;
        }, () -> { pl.abilities.setBusy(p, false); comps.endForm(p); comps.setScale(p, 1.25f + 0.1f * pl.profiles.get(o).stage()); pl.tasks.release(o, beam[0]); });
        return true;
    }

    private void titleNear(Player p, double range, String main, String sub) {
        net.kyori.adventure.text.minimessage.MiniMessage mm = net.kyori.adventure.text.minimessage.MiniMessage.miniMessage();
        net.kyori.adventure.title.Title t = net.kyori.adventure.title.Title.title(mm.deserialize(main), mm.deserialize(sub), net.kyori.adventure.title.Title.Times.times(java.time.Duration.ofMillis(150), java.time.Duration.ofMillis(1600), java.time.Duration.ofMillis(300)));
        for (Player o : p.getWorld().getPlayers()) if (o.getLocation().distanceSquared(p.getLocation()) <= range * range) o.showTitle(t);
    }
}
