package com.des.expansion.data;

import org.bukkit.Color;

/** The six VORATHIS relics (index = fragment index = bit in progression). */
public enum Relic {
    WITNESS("witness", "THE WITNESS", "PERCEPTION", Color.fromRGB(255, 236, 160)),
    LAST_SECOND("last_second", "THE LAST SECOND", "TIME", Color.fromRGB(80, 225, 255)),
    WEIGHTLESS_HEART("weightless_heart", "THE WEIGHTLESS HEART", "SPACE", Color.fromRGB(150, 120, 255)),
    FIRST_SPARK("first_spark", "THE FIRST SPARK", "CREATION", Color.fromRGB(255, 170, 40)),
    FINAL_REMNANT("final_remnant", "THE FINAL REMNANT", "ENTROPY", Color.fromRGB(165, 185, 95)),
    UNNAMED("unnamed", "THE UNNAMED", "BEYOND ALL LAWS", Color.fromRGB(235, 235, 245));

    public final String id, display, authority; public final Color color;
    Relic(String id, String display, String authority, Color color) { this.id = id; this.display = display; this.authority = authority; this.color = color; }
    public int index() { return ordinal(); }

    public static Relic parse(String s) {
        if (s == null) return null;
        String k = s.toLowerCase().replace('-', '_').replace(' ', '_').replace("the_", "");
        for (Relic r : values()) if (r.id.equals(k) || r.name().equalsIgnoreCase(k) || r.authority.equalsIgnoreCase(k)) return r;
        try { int n = Integer.parseInt(s); if (n >= 1 && n <= 6) return values()[n - 1]; } catch (NumberFormatException ignored) { }
        return null;
    }
}
