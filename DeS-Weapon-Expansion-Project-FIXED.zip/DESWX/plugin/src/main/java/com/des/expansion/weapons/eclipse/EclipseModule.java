package com.des.expansion.weapons.eclipse;

import com.des.expansion.abilities.AbilityDef;
import com.des.expansion.abilities.Ctx;
import com.des.expansion.abilities.Prims;
import com.des.expansion.abilities.Weapon;
import com.des.expansion.core.DeSWeaponExpansion;
import com.des.expansion.core.Fx;
import com.des.expansion.data.Profile;
import com.des.expansion.utilities.Locs;
import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/** ECLIPSE - THE SUNLESS CROWN (MYTHICAL). Dual floating chakrams, Eclipse Charge 0-100, 12 abilities + TOTAL ECLIPSE. */
public final class EclipseModule implements Weapon {
    public static final String KEY = "eclipse", NS = "deswx_eclipse:";
    static final Color ORANGE = Color.fromRGB(255, 120, 10), EMBER = Color.fromRGB(255, 175, 60), WHITE = Color.fromRGB(255, 245, 210), BLACK = Color.fromRGB(25, 18, 16);

    interface Formation { Location at(int i, int t); }
    static final class Rig { final ItemDisplay[] d = new ItemDisplay[2]; final Location[] cur = new Location[2]; double spin; Formation f; int ft; int fTicks; double scaleMul = 1; int boost; }

    private final DeSWeaponExpansion pl;
    private final Map<String, AbilityDef> defs = new LinkedHashMap<>();
    private final List<String> sel = new ArrayList<>();
    private final Map<UUID, Rig> rigs = new HashMap<>();
    private final Map<UUID, Long> guardUntil = new HashMap<>(), totalityUntil = new HashMap<>();
    private final Map<UUID, UUID> totalityBound = new HashMap<>();
    private final Map<UUID, Map<UUID, Long>> repeat = new HashMap<>();
    private final Map<UUID, Set<UUID>> ultDark = new HashMap<>();
    private BukkitTask task; private int tick;

    public EclipseModule(DeSWeaponExpansion pl) { this.pl = pl; }

    private void reg(String id, String name, double cd, double cost, boolean ult, boolean selfCd, AbilityDef.Runner r) {
        defs.put(id, new AbilityDef(KEY, id, name, cd, cost, ult, selfCd, r)); if (!ult) sel.add(id);
    }

    public void enable() {
        reg("solar_cut", "SOLAR CUT", 6, 0, false, false, this::solarCut);
        reg("crescent_rush", "CRESCENT RUSH", 12, 10, false, false, this::crescentRush);
        reg("orbital_storm", "ORBITAL STORM", 20, 20, false, false, this::orbitalStorm);
        reg("eclipse_trap", "ECLIPSE TRAP", 22, 15, false, false, this::eclipseTrap);
        reg("sunpiercer", "SUNPIERCER", 14, 20, false, false, this::sunpiercer);
        reg("return_to_zero", "RETURN TO ZERO", 16, 15, false, false, this::returnToZero);
        reg("gravity_well", "GRAVITY WELL", 26, 25, false, false, this::gravityWell);
        reg("solar_collapse", "SOLAR COLLAPSE", 30, 30, false, false, this::solarCollapse);
        reg("photon_guard", "PHOTON GUARD", 24, 15, false, false, this::photonGuard);
        reg("afterimage_execution", "AFTERIMAGE EXECUTION", 22, 25, false, false, this::afterimage);
        reg("totality", "TOTALITY", 28, 20, false, false, this::totality);
        reg("last_light", "LAST LIGHT", 40, 0, false, false, this::lastLight);
        reg("total_eclipse", "TOTAL ECLIPSE", 180, 100, true, false, this::ultimate);
        task = new BukkitRunnable() { @Override public void run() { rigTick(); } }.runTaskTimer(pl, 20L, 2L);
    }

    public void disable() { if (task != null) task.cancel(); for (UUID id : new ArrayList<>(rigs.keySet())) removeRig(id); for (Set<UUID> s : ultDark.values()) for (UUID u : s) { Player p = Bukkit.getPlayer(u); if (p != null) p.removePotionEffect(PotionEffectType.DARKNESS); } }

    // ------------------------------------------------------------------ Weapon
    @Override public String key() { return KEY; }
    @Override public String display() { return "ECLIPSE"; }
    @Override public Map<String, AbilityDef> abilities() { return defs; }
    @Override public List<String> selectable() { return sel; }
    @Override public String ultimateId() { return "total_eclipse"; }
    @Override public boolean holds(Player p) { return pl.items.holds(p, KEY); }
    @Override public String resourceName() { return "Eclipse Charge"; }
    @Override public double resource(Player p) { return pl.profiles.get(p.getUniqueId()).eclipseCharge; }
    @Override public boolean spend(Player p, double a) { Profile pr = pl.profiles.get(p.getUniqueId()); if (pr.eclipseCharge + 1e-6 < a) return false; pr.eclipseCharge = Math.max(0, pr.eclipseCharge - a); return true; }
    @Override public String blockReason(Player p, AbilityDef d, boolean forced) {
        if (!pl.cfg.b("eclipse.yml", "enabled", true) && !forced) return "ECLIPSE is disabled";
        if (!forced && !p.hasPermission("deswx.eclipse.use")) return "no permission";
        return null;
    }
    @Override public String hud(Player p) {
        int sIdx = pl.abilities.selected(p, KEY); AbilityDef d = defs.get(sel.get(sIdx)); long cd = pl.cooldowns.remainingMs(p, d.key());
        double cost = pl.cfg.cost(KEY, d.id(), d.defCost()); double ch = resource(p);
        String st = cd > 0 ? "<red>" + String.format("%.1fs", cd / 1000.0) : ch < cost ? "<yellow>NEEDS " + (int) cost : "<green>READY";
        int n = (int) Math.round(ch / 10);
        return "<gold><bold>ECLIPSE</bold> <dark_gray>| <gold>" + "\u25ae".repeat(n) + "<dark_gray>" + "\u25ae".repeat(10 - n) + " <white>" + (int) ch + "<gray>/100 <dark_gray>| <yellow>" + (sIdx + 1) + ". " + d.name() + " " + st;
    }

    @Override public void onFirstHit(Ctx c, LivingEntity t) {
        Profile pr = c.prof; double g = c.distinct() <= 1 ? pl.cfg.d("eclipse.yml", "charge.per-hit", 3) : pl.cfg.d("eclipse.yml", "charge.extra-target", 1.5);
        long now = System.currentTimeMillis(); Map<UUID, Long> rp = repeat.computeIfAbsent(c.p.getUniqueId(), k -> new HashMap<>());
        Long last = rp.get(t.getUniqueId());
        if (last != null && now - last < pl.cfg.d("eclipse.yml", "charge.repeat-window-seconds", 8) * 1000) g *= pl.cfg.d("eclipse.yml", "charge.repeat-multiplier", 0.3);
        rp.put(t.getUniqueId(), now); if (rp.size() > 64) rp.values().removeIf(x -> now - x > 60000);
        g = Math.min(g, pl.cfg.d("eclipse.yml", "charge.max-per-cast", 10) - c.gained); if (g > 0) { c.gained += g; double before = pr.eclipseCharge; pr.eclipseCharge = Math.min(100, before + g); if (before < 100 && pr.eclipseCharge >= 100) pl.fx.soundTo(c.p, NS + "charge_ready", 0.8f, 1f); }
        if (t instanceof Player || t.getMaxHealth() > 0) pr.eclipseXp++;
        UUID owner = c.p.getUniqueId();
        if (c.castId.equals(totalityBound.get(owner))) { totalityUntil.remove(owner); totalityBound.remove(owner); }
    }

    @Override public double damageMult(Ctx c, LivingEntity t) {
        double m = 1.0 + Math.floor(c.prof.eclipseCharge / 25.0) * pl.cfg.d("eclipse.yml", "orbital-dominion.bonus-per-25-charge", 0.03);
        UUID o = c.p.getUniqueId();
        if (totalityUntil.getOrDefault(o, 0L) > System.currentTimeMillis() && !"totality".equals(c.def.id())) {
            totalityBound.putIfAbsent(o, c.castId);
            if (c.castId.equals(totalityBound.get(o))) m *= pl.cfg.d("eclipse.yml", "totality.empower-multiplier", 1.4);
        }
        return m;
    }

    @Override public void onMelee(Player p, LivingEntity v, EntityDamageByEntityEvent e) {
        Profile pr = pl.profiles.get(p.getUniqueId()); UUID o = p.getUniqueId();
        if (totalityUntil.getOrDefault(o, 0L) > System.currentTimeMillis()) { e.setDamage(e.getDamage() * pl.cfg.d("eclipse.yml", "totality.empower-multiplier", 1.4)); totalityUntil.remove(o); }
        if (p.getAttackCooldown() >= 0.9f) {
            long now = System.currentTimeMillis(); Map<UUID, Long> rp = repeat.computeIfAbsent(o, k -> new HashMap<>());
            Long last = rp.get(v.getUniqueId()); double g = pl.cfg.d("eclipse.yml", "charge.melee-hit", 1.5);
            if (last != null && now - last < 8000) g *= 0.3; rp.put(v.getUniqueId(), now);
            pr.eclipseCharge = Math.min(100, pr.eclipseCharge + g);
        }
        pl.combat.tag(p, v, KEY);
        Fx.Aud a = pl.fx.at(v.getLocation()); a.dust(v.getLocation().add(0, 1, 0), 8, 0.3, ORANGE, 1.1f);
    }

    @Override public void onHurt(Player p, EntityDamageEvent e, LivingEntity attacker) {
        if (guardUntil.getOrDefault(p.getUniqueId(), 0L) > System.currentTimeMillis()) {
            e.setDamage(e.getDamage() * (1 - pl.cfg.ab(KEY, "photon_guard", "reduction", 0.35)));
            Location l = p.getLocation().add(0, 1, 0); pl.fx.at(l).dust(l, 14, 0.7, WHITE, 1.2f);
        }
    }
    @Override public void onKill(Player p, LivingEntity v) { Profile pr = pl.profiles.get(p.getUniqueId()); pr.eclipseCharge = Math.min(100, pr.eclipseCharge + pl.cfg.d("eclipse.yml", "charge.kill", 5)); }

    @Override public void abort(Player p) {
        UUID id = p.getUniqueId(); guardUntil.remove(id); totalityUntil.remove(id); totalityBound.remove(id); removeRig(id);
        Set<UUID> s = ultDark.remove(id); if (s != null) for (UUID u : s) { Player t = Bukkit.getPlayer(u); if (t != null) t.removePotionEffect(PotionEffectType.DARKNESS); }
    }

    // ------------------------------------------------------------------ chakram rig
    private void removeRig(UUID id) { Rig r = rigs.remove(id); if (r != null) for (ItemDisplay d : r.d) pl.tasks.release(id, d); }

    private Rig rig(Player p) { return rigs.get(p.getUniqueId()); }

    private Rig ensureRig(Player p) {
        Rig r = rigs.get(p.getUniqueId());
        if (r != null && r.d[0] != null && r.d[0].isValid() && r.d[1] != null && r.d[1].isValid() && r.d[0].getWorld() == p.getWorld()) return r;
        if (r != null) removeRig(p.getUniqueId());
        r = new Rig(); Location base = p.getLocation().add(0, 1.3, 0);
        for (int i = 0; i < 2; i++) { r.cur[i] = base.clone(); r.d[i] = pl.fx.display(p.getUniqueId(), base, NS + "chakram", 1.5f, null, false, null, 3); }
        rigs.put(p.getUniqueId(), r); return r;
    }

    private void rigTick() {
        tick++;
        for (Player p : Bukkit.getOnlinePlayers()) {
            boolean hold = holds(p) || (pl.items.typeOf(p.getInventory().getItemInOffHand()) != null && KEY.equals(pl.items.typeOf(p.getInventory().getItemInOffHand())) && pl.items.valid(p.getInventory().getItemInOffHand()));
            if (!hold || p.isDead() || !pl.cfg.b("eclipse.yml", "enabled", true)) { if (rigs.containsKey(p.getUniqueId())) removeRig(p.getUniqueId()); continue; }
            Rig r = ensureRig(p); if (r.d[0] == null || r.d[1] == null) continue;
            Location pos = p.getLocation(); double yaw = Math.toRadians(pos.getYaw());
            Vector fwd = new Vector(-Math.sin(yaw), 0, Math.cos(yaw)), right = new Vector(-Math.cos(yaw), 0, -Math.sin(yaw));
            r.spin += (r.boost > 0 ? 0.9 : 0.22); if (r.boost > 0) r.boost -= 2;
            if (r.f != null) { r.ft += 2; if (r.ft >= r.fTicks) r.f = null; }
            for (int i = 0; i < 2; i++) {
                Location target = r.f != null ? r.f.at(i, r.ft) : null;
                if (target == null) target = pos.clone().add(0, 1.3 + 0.12 * Math.sin(tick * 0.12 + i * Math.PI), 0).add(right.clone().multiply(i == 0 ? 0.95 : -0.95)).subtract(fwd.clone().multiply(0.3));
                Location cur = r.cur[i]; double k = r.f != null ? 0.6 : 0.35;
                if (cur.getWorld() != target.getWorld() || cur.distanceSquared(target) > 256) cur = target.clone(); else cur = cur.add(target.clone().subtract(cur).toVector().multiply(k));
                r.cur[i] = cur;
                ItemDisplay d = r.d[i]; d.teleport(cur);
                float sc = (float) (1.5 * r.scaleMul);
                pl.fx.animate(d, new Vector3f(sc, sc, sc), new Quaternionf().rotateY((float) (-yaw - Math.PI / 2)).rotateZ((float) (r.spin * (i == 0 ? 1 : -1))), 2);
            }
            if (tick % 6 == 0) for (int i = 0; i < 2; i++) pl.fx.at(r.cur[i]).dust(r.cur[i], 1, 0.15, EMBER, 0.8f);
            if (tick % 160 == 0) pl.fx.sound(pos, NS + "idle", 0.25f, 1f);
        }
    }

    private void formation(Rig r, int ticks, Formation f) { r.f = f; r.ft = 0; r.fTicks = ticks; }

    // ------------------------------------------------------------------ abilities
    private boolean solarCut(Ctx c) {
        Player p = c.p; Location eye = p.getEyeLocation(); Vector dir = eye.getDirection().clone(); dir.setY(dir.getY() * 0.5).normalize();
        p.swingMainHand(); pl.fx.sound(p.getLocation(), NS + "a01_cast", 1f, 1f);
        Prims.P s = new Prims.P(); s.model = NS + "solar_slash"; s.scale = (float) c.v("scale", 3.4); s.start = eye.clone().add(dir.clone().multiply(1.3)).subtract(0, 0.3, 0); s.dir = dir;
        s.range = c.v("range", 12); s.speed = c.v("speed", 1.4); s.radius = c.v("hit-radius", 1.8); s.pierce = c.vi("pierce", 4); s.dmg = c.v("damage", 7); s.c1 = ORANGE; s.c2 = WHITE; s.hitSound = NS + "a01_hit"; s.glow = ORANGE;
        Prims.projectile(c, s); return true;
    }

    private boolean crescentRush(Ctx c) {
        Player p = c.p; Rig r = ensureRig(p);
        boolean ok = Prims.dash(c, c.v("distance", 8), 4, c.v("hit-radius", 2.2), c.v("damage", 6), ORANGE, WHITE, end -> { pl.fx.at(end).dust(end.clone().add(0, 1, 0), 24, 0.7, EMBER, 1.3f); pl.fx.sound(end, NS + "a01_hit", 0.9f, 1.2f); });
        if (!ok) { pl.abilities.msg(p, "<red>CRESCENT RUSH <gray>- no room to dash"); return false; }
        r.boost = 30; pl.fx.sound(p.getLocation(), NS + "a02_rush", 1.1f, 1f); return true;
    }

    private boolean orbitalStorm(Ctx c) {
        Player p = c.p; Rig r = ensureRig(p); c.maxHits = c.vi("max-hits", 6); int dur = c.vi("duration-ticks", 100); double rad = c.v("orbit-radius", 3.2);
        formation(r, dur, (i, t) -> { double a = t * 0.38 + i * Math.PI; return p.getLocation().add(0, 1.2, 0).add(Math.cos(a) * rad, Math.sin(t * 0.2 + i) * 0.4, Math.sin(a) * rad); });
        r.scaleMul = 1.5; r.boost = dur; pl.fx.sound(p.getLocation(), NS + "a03_storm", 1.2f, 1f);
        pl.tasks.timer(p.getUniqueId(), 2, 2, dur / 2, t -> {
            if (!c.alive()) return false;
            for (int i = 0; i < 2; i++) { Location pos = r.cur[i]; Fx.Aud a = pl.fx.at(pos); a.dust(pos, 4, 0.3, ORANGE, 1.2f); if (t % 2 == 0) pl.fx.ring(a, pos, 1.0, 8, t, EMBER, 1f);
                for (LivingEntity e : pl.combat.enemies(p, pos, 1.8)) if (c.hit(e, c.v("damage", 2.5))) pl.fx.at(e.getLocation()).dust(e.getLocation().add(0, 1, 0), 8, 0.3, WHITE, 1.1f); }
            return true;
        }, () -> { r.scaleMul = 1; r.boost = 0; });
        return true;
    }

    private boolean eclipseTrap(Ctx c) {
        Prims.F f = new Prims.F(); f.center = Prims.aimPoint(c.p, c.v("range", 18)); f.radius = c.v("radius", 5); f.ticks = c.vi("duration-ticks", 120); f.slowAmp = c.vi("slow-amplifier", 2);
        f.tickDmg = c.v("tick-damage", 1.5); f.c1 = ORANGE; f.c2 = EMBER; f.model = NS + "trap"; f.tickSound = NS + "a04_trap"; f.soundEvery = 40;
        c.p.swingMainHand(); pl.fx.sound(f.center, NS + "a04_trap", 1.2f, 1f); Prims.field(c, f); return true;
    }

    private boolean sunpiercer(Ctx c) {
        Player p = c.p; Location eye = p.getEyeLocation(); Vector dir = eye.getDirection().clone().normalize();
        p.swingMainHand(); pl.fx.sound(p.getLocation(), NS + "a05_pierce", 1.2f, 1f);
        Prims.P s = new Prims.P(); s.model = NS + "sun_core"; s.scale = 1.7f; s.start = eye.clone().add(dir.clone().multiply(1.2)).subtract(0, 0.2, 0); s.dir = dir; s.range = c.v("range", 30); s.speed = c.v("speed", 2.2);
        s.radius = c.v("hit-radius", 1.2); s.pierce = c.vi("pierce", 3); s.dmg = c.v("damage", 12); s.c1 = WHITE; s.c2 = ORANGE; s.arc = false; s.glow = ORANGE; s.hitSound = NS + "a01_hit";
        s.onEnd = end -> { pl.fx.sphere(pl.fx.at(end), end, 1.2, 20, ORANGE, 1.3f); pl.fx.sound(end, NS + "a05_pierce", 0.8f, 0.8f); };
        Prims.projectile(c, s); return true;
    }

    private boolean returnToZero(Ctx c) {
        Player p = c.p; Rig r = ensureRig(p); c.maxHits = 2; Location eye = p.getEyeLocation(); Vector aim = Locs.flat(eye.getDirection());
        final Vector[] out = {aim.clone().rotateAroundY(Math.toRadians(30)), aim.clone().rotateAroundY(Math.toRadians(-30))};
        final Location[] pos = {r.cur[0].clone(), r.cur[1].clone()}; final boolean[] back = {false, false}; final double[] travelled = {0, 0};
        double range = c.v("range", 12), speed = c.v("speed", 1.5), dmg = c.v("damage", 5);
        formation(r, 400, (i, t) -> pos[i]); r.boost = 400; r.scaleMul = 1.4; pl.fx.sound(p.getLocation(), NS + "a06_throw", 1.1f, 1f);
        pl.tasks.timer(p.getUniqueId(), 1, 1, 120, t -> {
            if (!c.alive()) return false;
            boolean allDone = true;
            for (int i = 0; i < 2; i++) {
                if (!back[i]) { pos[i].add(out[i].clone().multiply(speed)); travelled[i] += speed; if (travelled[i] >= range || !pos[i].getBlock().isPassable()) { back[i] = true; pl.fx.sound(pos[i], NS + "a06_return", 0.9f, 1f); } allDone = false; }
                else { Location home = p.getLocation().add(0, 1.3, 0); Vector to = home.toVector().subtract(pos[i].toVector()); double d = to.length(); if (d < 1.4) continue; pos[i].add(to.normalize().multiply(Math.min(d, speed * 1.4))); allDone = false; }
                Fx.Aud a = pl.fx.at(pos[i]); a.dust(pos[i], 5, 0.3, ORANGE, 1.2f); a.dust(pos[i], 2, 0.2, WHITE, 1f);
                for (LivingEntity e : pl.combat.enemies(p, pos[i], 1.8)) if (c.hit(e, dmg)) pl.fx.sound(e.getLocation(), NS + "a01_hit", 0.8f, 1.1f);
            }
            return !allDone;
        }, () -> { r.f = null; r.boost = 0; r.scaleMul = 1; });
        return true;
    }

    private boolean gravityWell(Ctx c) {
        Prims.F f = new Prims.F(); f.center = Prims.aimPoint(c.p, c.v("range", 18)); f.radius = c.v("radius", 6); f.pull = c.v("pull", 0.5); f.ticks = c.vi("duration-ticks", 60); f.endDmg = c.v("collapse-damage", 8); f.endKnock = 1.0;
        f.c1 = ORANGE; f.c2 = WHITE; f.model = NS + "trap"; f.coreModel = NS + "sun_core"; f.coreScale = 2.4f; f.tickSound = NS + "a07_well"; f.soundEvery = 40; f.endSound = NS + "a08_blast";
        c.p.swingMainHand(); pl.fx.sound(f.center, NS + "a07_well", 1.3f, 1f); Prims.field(c, f); return true;
    }

    private boolean solarCollapse(Ctx c) {
        Player p = c.p; UUID id = p.getUniqueId(); Location ctr = Prims.aimPoint(p, c.v("range", 16)); double rad = c.v("radius", 6); int lead = c.vi("charge-ticks", 24);
        p.swingMainHand(); pl.fx.sound(ctr, NS + "a08_charge", 1.4f, 1f);
        ItemDisplay core = pl.fx.display(id, ctr.clone().add(0, 2.5, 0), NS + "sun_core", 0.5f, null, true, ORANGE, 2);
        pl.tasks.later(id, 1, () -> pl.fx.animate(core, new Vector3f(4f, 4f, 4f), new Quaternionf().rotateY(6f), lead));
        Prims.telegraph(c, ctr, rad, lead, ORANGE, WHITE, () -> {
            pl.fx.sound(ctr, NS + "a08_blast", 1.6f, 1f);
            Prims.burst(c, ctr, rad, c.v("damage", 16), c.v("knockback", 1.3), ORANGE, WHITE, true);
            pl.fx.sphere(pl.fx.at(ctr), ctr.clone().add(0, 2, 0), 4, 40, WHITE, 1.6f);
            pl.tasks.release(id, core);
        });
        return true;
    }

    private boolean photonGuard(Ctx c) {
        Player p = c.p; UUID id = p.getUniqueId(); Rig r = ensureRig(p); int dur = c.vi("duration-ticks", 60);
        guardUntil.put(id, System.currentTimeMillis() + dur * 50L);
        formation(r, dur, (i, t) -> { double yaw = Math.toRadians(p.getLocation().getYaw()); Vector fwd = new Vector(-Math.sin(yaw), 0, Math.cos(yaw)), right = new Vector(-Math.cos(yaw), 0, -Math.sin(yaw)); return p.getLocation().add(0, 1.3, 0).add(fwd.multiply(1.5)).add(right.multiply(i == 0 ? 0.9 : -0.9)); });
        r.scaleMul = 2.2; r.boost = dur; pl.fx.sound(p.getLocation(), NS + "a09_guard", 1.2f, 1f);
        pl.tasks.timer(id, 2, 2, dur / 2, t -> {
            if (!c.alive()) return false;
            Location l = p.getLocation().add(0, 1.1, 0); Vector f = p.getLocation().getDirection().setY(0).normalize(); Fx.Aud a = pl.fx.at(l);
            pl.fx.tilted(a, l.clone().add(f.clone().multiply(1.4)), f, 1.4, 16, t * 0.3, ORANGE, 1.2f); pl.fx.tilted(a, l.clone().add(f.clone().multiply(1.5)), f, 0.8, 10, -t * 0.3, WHITE, 1.0f);
            return true;
        }, () -> { r.scaleMul = 1; r.boost = 0; guardUntil.remove(id); if (c.alive()) { pl.fx.sound(p.getLocation(), NS + "a08_blast", 0.7f, 1.4f); Prims.burst(c, p.getLocation(), c.v("pulse-radius", 4), c.v("pulse-damage", 3), 0.9, ORANGE, WHITE, true); } });
        return true;
    }

    private boolean afterimage(Ctx c) {
        Player p = c.p; UUID id = p.getUniqueId(); LivingEntity tgt = Prims.aimTarget(c, c.v("range", 20), 30);
        if (tgt == null) { pl.abilities.msg(p, "<red>AFTERIMAGE EXECUTION <gray>- no target in sight"); return false; }
        c.maxHits = 6; p.swingMainHand(); pl.fx.sound(tgt.getLocation(), NS + "a10_afterimage", 1.2f, 1f);
        double base = Math.random() * Math.PI * 2;
        for (int k = 0; k < 4; k++) {
            final int kk = k;
            pl.tasks.later(id, 4 + k * 6L, () -> {
                if (!c.alive() || !tgt.isValid() || tgt.isDead()) return;
                Location center = tgt.getLocation().add(0, tgt.getHeight() / 2, 0); double ang = base + kk * Math.PI / 2;
                Location from = center.clone().add(Math.cos(ang) * 4.2, 0.6 + (kk % 2), Math.sin(ang) * 4.2); Vector dir = center.toVector().subtract(from.toVector()).normalize();
                ItemDisplay ghost = pl.fx.display(id, from, NS + "chakram", 2.0f, Fx.orient(new Vector(0, 1, 0), dir), true, ORANGE, 0); if (ghost != null) pl.tasks.later(id, 12, () -> pl.tasks.release(id, ghost));
                pl.fx.sound(from, NS + "a10_afterimage", 0.8f, 1f + kk * 0.1f);
                Prims.P s = new Prims.P(); s.model = NS + "solar_slash"; s.scale = 2.8f; s.start = from; s.dir = dir; s.range = 6.5; s.speed = 1.8; s.radius = 1.4; s.dmg = c.v("damage", 4); s.c1 = ORANGE; s.c2 = WHITE; s.glow = ORANGE; s.hitSound = NS + "a01_hit"; Prims.projectile(c, s);
            });
        }
        pl.tasks.later(id, 4 + 4 * 6L + 8, () -> { if (!c.alive() || !tgt.isValid() || tgt.isDead()) return; Location tl = tgt.getLocation(); pl.fx.sound(tl, NS + "a12_lastlight", 1.2f, 1.2f); Prims.burst(c, tl, 2.5, c.v("final-damage", 8), 0.7, ORANGE, WHITE, true); });
        return true;
    }

    private boolean totality(Ctx c) {
        Player p = c.p; UUID id = p.getUniqueId(); double rad = c.v("radius", 12); int dur = c.vi("duration-ticks", 80);
        pl.fx.sound(p.getLocation(), NS + "a11_totality", 1.5f, 1f); p.swingMainHand();
        for (LivingEntity e : pl.combat.enemies(p, p.getLocation(), rad)) if (e instanceof Player tp) tp.addPotionEffect(new PotionEffect(PotionEffectType.DARKNESS, dur, 0, false, false, false));
        totalityUntil.put(id, System.currentTimeMillis() + (long) (c.v("empower-seconds", 6) * 1000)); totalityBound.remove(id);
        Location up = p.getLocation().add(0, 9, 0);
        ItemDisplay disc = pl.fx.display(id, up, NS + "eclipse_disc", 0.5f, Fx.flat(), false, null, 2);
        pl.tasks.later(id, 1, () -> pl.fx.animate(disc, new Vector3f(11f, 11f, 11f), Fx.flat().rotateZ(2f), 20));
        pl.tasks.timer(id, 2, 2, dur / 2, t -> { if (!c.alive()) return false; Location l = p.getLocation(); if (disc != null && disc.isValid()) disc.teleport(l.clone().add(0, 9, 0)); Fx.Aud a = pl.fx.at(l); pl.fx.ring(a, l.clone().add(0, 0.2, 0), rad * Math.min(1, t / 8.0), 36, t * 0.1, BLACK, 1.6f); pl.fx.ring(a, l.clone().add(0, 0.25, 0), rad * Math.min(1, t / 8.0), 36, -t * 0.1, ORANGE, 1.0f); return true; },
            () -> { if (disc != null) { pl.fx.animate(disc, new Vector3f(0.3f, 0.3f, 0.3f), Fx.flat(), 8); pl.tasks.later(id, 9, () -> pl.tasks.release(id, disc)); } });
        pl.abilities.msg(p, "<gold>TOTALITY <gray>- your next attack is empowered");
        return true;
    }

    private boolean lastLight(Ctx c) {
        Player p = c.p; Profile pr = c.prof; double min = c.v("min-charge", 50);
        if (!c.forced && pr.eclipseCharge < min) { pl.abilities.msg(p, "<yellow>LAST LIGHT <gray>needs <white>" + (int) min + " <gray>Eclipse Charge"); return false; }
        LivingEntity tgt = Prims.aimTarget(c, c.v("range", 22), 30);
        if (tgt == null) { pl.abilities.msg(p, "<red>LAST LIGHT <gray>- no target in sight"); return false; }
        double charge = c.forced ? Math.max(pr.eclipseCharge, 60) : pr.eclipseCharge; if (!c.forced) pr.eclipseCharge = 0;
        double dmg = Math.min(c.v("max-damage", 32), c.v("base-damage", 10) + charge * c.v("damage-per-charge", 0.22));
        p.swingMainHand(); pl.fx.sound(tgt.getLocation(), NS + "a12_lastlight", 1.5f, 1f); UUID id = p.getUniqueId();
        Rig r = ensureRig(p); formation(r, 20, (i, t) -> tgt.getLocation().add(0, tgt.getHeight() + 1.5 + Math.sin(t) * 0.3, 0).add(i == 0 ? 0.8 : -0.8, 0, 0)); r.boost = 20;
        pl.tasks.timer(id, 0, 2, 8, t -> { if (!tgt.isValid()) return false; Location a = tgt.getLocation(); pl.fx.at(a).trans(a.clone().add(0, 4 - t * 0.4, 0), 12, 0.4, WHITE, ORANGE, 1.4f); pl.fx.column(pl.fx.at(a), a, 5, 0.5, 8, ORANGE, 1.2f); return true; },
            () -> { r.f = null; if (!c.alive() || !tgt.isValid() || tgt.isDead()) return; double m = tgt.getHealth() < Math.max(1, tgt.getMaxHealth()) * 0.4 ? c.v("finisher-multiplier", 1.3) : 1.0;
                if (c.hit(tgt, dmg * m)) { Location l = tgt.getLocation().add(0, 1, 0); pl.fx.sphere(pl.fx.at(l), l, 2.5, 36, ORANGE, 1.5f); pl.fx.sphere(pl.fx.at(l), l, 1.4, 20, WHITE, 1.3f); pl.fx.sound(l, NS + "a08_blast", 1.4f, 1.3f); } });
        return true;
    }

    // ------------------------------------------------------------------ TOTAL ECLIPSE
    private boolean ultimate(Ctx c) {
        final Player p = c.p; final UUID id = p.getUniqueId(); final double radius = c.v("radius", 14); c.maxHits = c.vi("max-hits-per-target", 4);
        final Vector fwd = Locs.flat(p.getLocation().getDirection()); final Location center = Locs.ground(p.getLocation().add(fwd.clone().multiply(6)));
        final Rig r = ensureRig(p); pl.abilities.setBusy(p, true);
        final Set<UUID> dark = new HashSet<>(); ultDark.put(id, dark);
        final List<Location> spots = new ArrayList<>(); final int[] spotIdx = {0}; final ItemDisplay[] disc = {null}, sun = {null};
        final Location frozenL = r.cur[0].clone(), frozenR = r.cur[1].clone();
        pl.tasks.timer(id, 0, 1, 180, t -> {
            if (!c.alive()) return false;
            Location pp = p.getLocation(); Fx.Aud a = pl.fx.at(pp);
            if (t == 0) {
                pl.fx.sound(pp, NS + "u_blacken", 3f, 1f); titleNear(p, radius + 14, "<gold><bold>THE BLACKENING</bold>", "<dark_gray>TOTAL ECLIPSE");
                for (Player o : p.getWorld().getPlayers()) if (!o.equals(p) && o.getLocation().distanceSquared(pp) <= (radius + 14) * (radius + 14)) { o.addPotionEffect(new PotionEffect(PotionEffectType.DARKNESS, 190, 0, false, false, false)); dark.add(o.getUniqueId()); }
                formation(r, 400, (i, tt) -> i == 0 ? frozenL : frozenR);   // chakrams stop moving
            }
            if (t < 30) { double f = t / 30.0; for (int k = 0; k < 6; k++) { Vector d = new Vector(Math.random() - .5, Math.random() - .5, Math.random() - .5).normalize().multiply(6 * (1 - f) + 1); a.dust(pp.clone().add(0, 1.3, 0).add(d), 1, 0, k % 2 == 0 ? ORANGE : EMBER, 1.3f); } pl.fx.ring(a, center.clone().add(0, 0.2, 0), radius, (int) (radius * 6), t * 0.05, ORANGE, 1.4f); }
            if (t == 30) { pl.fx.sound(pp, NS + "u_ascend", 3f, 1f); r.scaleMul = 2.4; r.boost = 400; disc[0] = pl.fx.display(id, pp.clone().add(0, 12, 0), NS + "eclipse_disc", 0.5f, Fx.flat(), false, null, 2); pl.tasks.later(id, 1, () -> pl.fx.animate(disc[0], new Vector3f(16f, 16f, 16f), Fx.flat().rotateZ(3f), 36));
                formation(r, 400, (i, tt) -> { double f = Math.min(1, Math.max(0, (tt / 2 - 30) / 40.0)); Location q = p.getLocation(); double yaw = Math.toRadians(q.getYaw()); Vector right = new Vector(-Math.cos(yaw), 0, -Math.sin(yaw)); return q.clone().add(0, 1.3 + 7 * f, 0).add(right.multiply((i == 0 ? 1 : -1) * (0.95 + 2.2 * f))); }); }
            if (t >= 30 && t < 70) { for (int i = 0; i < 2; i++) { Location cl = r.cur[i]; a.trans(cl, 6, 0.5, WHITE, ORANGE, 1.5f); pl.fx.ring(a, cl, 1.2, 10, t, WHITE, 1.1f); } }
            if (t == 70) {
                pl.fx.sound(pp, NS + "u_execute", 3f, 1f); titleNear(p, radius + 14, "<gold><bold>THE ORBITAL EXECUTION</bold>", "<gray>get out of the rings");
                List<LivingEntity> es = new ArrayList<>(pl.combat.enemies(p, center, radius)); es.sort(Comparator.comparingDouble(e -> e.getLocation().distanceSquared(center)));
                for (int k = 0; k < Math.min(8, es.size()); k++) spots.add(Locs.ground(es.get(k).getLocation()));
                for (int k = spots.size(); k < 4; k++) { double ang = Math.random() * Math.PI * 2, rr = Math.random() * radius * 0.7; spots.add(Locs.ground(center.clone().add(Math.cos(ang) * rr, 0, Math.sin(ang) * rr))); }
                for (int k = 0; k < spots.size(); k++) { final Location s = spots.get(k); pl.tasks.later(id, k * 7L, () -> Prims.telegraph(c, s, 2.4, 24, ORANGE, WHITE, null)); }
            }
            if (t >= 70 && t < 140) { r.boost = 400; int idx = spotIdx[0]; int when = 94 + idx * 7;
                for (int i = 0; i < 2; i++) { Location cl = r.cur[i]; a.dust(cl, 6, 0.4, ORANGE, 1.4f); }
                if (idx < spots.size() && t >= when) { Location s = spots.get(idx); spotIdx[0]++; Location from = r.cur[idx % 2].clone();
                    pl.fx.line(pl.fx.at(s), from, s.clone().add(0, 0.5, 0), 0.3, ORANGE, 1.6f); pl.fx.line(pl.fx.at(s), from, s.clone().add(0, 0.5, 0), 0.5, WHITE, 1.1f);
                    pl.fx.sound(s, NS + "a08_blast", 1.0f, 1.4f); Prims.burst(c, s, 2.4, c.v("strike-damage", 6), 0.8, ORANGE, WHITE, true); } }
            if (t == 140) {
                pl.fx.sound(pp, NS + "u_totality", 3.5f, 1f); titleNear(p, radius + 14, "<gold><bold>TOTALITY</bold>", "<dark_gray>the sun is gone");
                formation(r, 400, (i, tt) -> { double f = Math.min(1, (tt / 2 - 70) / 20.0); Location from = i == 0 ? frozenL : frozenR; Location top = center.clone().add(0, 3.0, 0); Location base = p.getLocation().add(0, 8.3, 0); return base.add(top.clone().subtract(base).toVector().multiply(f)); });
                Prims.telegraph(c, center, c.v("final-radius", 8), 24, ORANGE, WHITE, null);
                sun[0] = pl.fx.display(id, center.clone().add(0, 3, 0), NS + "sun_core", 2.5f, null, true, ORANGE, 2); pl.tasks.later(id, 1, () -> pl.fx.animate(sun[0], new Vector3f(9f, 9f, 9f), new Quaternionf().rotateY(8f), 24)); }
            if (t > 140 && t < 165) { pl.fx.sphere(a.getClass() == null ? a : pl.fx.at(center), center.clone().add(0, 3, 0), 5 * (1 - (t - 140) / 25.0) + 1, 24, WHITE, 1.4f); }
            if (t == 165) {
                pl.fx.sound(center, NS + "u_totality", 5f, 0.8f); Prims.burst(c, center, c.v("final-radius", 8), c.v("final-damage", 25), 1.4, ORANGE, WHITE, true);
                for (int k = 0; k < 3; k++) { final int kk = k; pl.tasks.later(id, k * 3L, () -> { pl.fx.ring(pl.fx.at(center), center.clone().add(0, 0.3, 0), 4 + kk * 3, 50, 0, ORANGE, 1.8f); pl.fx.sphere(pl.fx.at(center), center.clone().add(0, 3, 0), 3 + kk * 2.5, 40, kk == 0 ? WHITE : ORANGE, 1.7f); }); }
            }
            return t < 176;
        }, () -> {
            pl.abilities.setBusy(p, false); r.f = null; r.scaleMul = 1; r.boost = 0;
            pl.tasks.release(id, disc[0]); pl.tasks.release(id, sun[0]);
            for (UUID u : dark) { Player o = Bukkit.getPlayer(u); if (o != null) o.removePotionEffect(PotionEffectType.DARKNESS); }
            ultDark.remove(id);
        });
        return true;
    }

    private void titleNear(Player p, double range, String main, String sub) {
        net.kyori.adventure.text.minimessage.MiniMessage mm = net.kyori.adventure.text.minimessage.MiniMessage.miniMessage();
        net.kyori.adventure.title.Title t = net.kyori.adventure.title.Title.title(mm.deserialize(main), mm.deserialize(sub), net.kyori.adventure.title.Title.Times.times(java.time.Duration.ofMillis(150), java.time.Duration.ofMillis(1400), java.time.Duration.ofMillis(300)));
        for (Player o : p.getWorld().getPlayers()) if (o.getLocation().distanceSquared(p.getLocation()) <= range * range) o.showTitle(t);
    }
}
