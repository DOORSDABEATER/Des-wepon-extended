package com.des.expansion.weapons.vorathis;

import com.des.expansion.core.DeSWeaponExpansion;
import com.des.expansion.data.Profile;
import com.des.expansion.data.Relic;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Entity;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.ArrayDeque;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * VORATHIS permanent floating companion: one living core + six independent fragments per wielder.
 * Exactly one Companion per player (map key = UUID); every display is non-persistent, tagged and tracked, and is removed on quit, death,
 * world/dimension change (re-spawned in the new world), weapon removal, plugin disable/reload. Orphans of a previous plugin instance are swept on start.
 */
public final class CompanionManager {
    public interface Formation { Location at(int idx, int t); }    // idx -1 = core, 0..5 = fragment
    public static final class Companion {
        UUID owner; World world; ItemDisplay core; final ItemDisplay[] frag = new ItemDisplay[6]; Location cur; final Location[] fcur = new Location[6];
        double spin; int flinch, alert, stage, mask; Formation form; int formT, formN; float coreScale = 1.25f;
    }

    private final DeSWeaponExpansion pl;
    private final Map<UUID, Companion> map = new HashMap<>();
    private final Map<UUID, Boolean> elig = new HashMap<>();
    private final Map<UUID, ArrayDeque<Location>> hist = new HashMap<>();
    private BukkitTask task; private int tick;

    public CompanionManager(DeSWeaponExpansion pl) { this.pl = pl; }

    public void start() {
        for (World w : Bukkit.getWorlds()) for (Entity e : w.getEntitiesByClass(ItemDisplay.class)) if (e.getScoreboardTags().contains(com.des.expansion.core.Fx.COMPANION_TAG)) e.remove();   // orphan sweep
        task = new BukkitRunnable() { @Override public void run() { tick(); } }.runTaskTimer(pl, 20L, 2L);
    }

    public void stop() { if (task != null) task.cancel(); for (UUID id : new java.util.ArrayList<>(map.keySet())) despawn(id); hist.clear(); }

    public Companion get(Player p) { return map.get(p.getUniqueId()); }
    public boolean exists(Player p) { Companion c = map.get(p.getUniqueId()); return c != null && c.core != null && c.core.isValid(); }
    public Location fragLoc(Player p, int i) { Companion c = map.get(p.getUniqueId()); return c == null || c.fcur[i] == null ? p.getLocation().add(0, 1.5, 0) : c.fcur[i].clone(); }
    public Location coreLoc(Player p) { Companion c = map.get(p.getUniqueId()); return c == null || c.cur == null ? p.getLocation().add(0, 2, 0) : c.cur.clone(); }
    public void form(Player p, int ticks, Formation f) { Companion c = map.get(p.getUniqueId()); if (c != null) { c.form = f; c.formT = 0; c.formN = ticks; } }
    public void endForm(Player p) { Companion c = map.get(p.getUniqueId()); if (c != null) { c.form = null; c.coreScale = 1.25f + 0.1f * pl.profiles.get(p.getUniqueId()).stage(); } }
    public void flinch(Player p) { Companion c = map.get(p.getUniqueId()); if (c != null && c.flinch <= 0) { c.flinch = 14; pl.fx.sound(coreLoc(p), "deswx_vorathis:flinch", 0.6f, 1f); } }
    public void setScale(Player p, float s) { Companion c = map.get(p.getUniqueId()); if (c != null) c.coreScale = s; }

    public boolean eligible(Player p) {
        if (!p.isOnline() || p.isDead() || !pl.cfg.b("vorathis.yml", "enabled", true) || pl.cfg.worldDisabled(p.getWorld().getName())) return false;
        Profile pr = pl.profiles.get(p.getUniqueId());
        return pr.vorathisSummoned && pl.items.has(p, "vorathis");
    }

    public void refresh(Player p) { despawn(p.getUniqueId()); elig.remove(p.getUniqueId()); }
    public void despawn(UUID id) { Companion c = map.remove(id); if (c == null) return; pl.tasks.release(id, c.core); for (ItemDisplay d : c.frag) pl.tasks.release(id, d); }

    private int maskOf(Profile pr) { int m = 0; for (int i = 0; i < 6; i++) if (pr.relicUnlocked[i]) m |= 1 << i; return m; }

    private Companion spawn(Player p) {
        Profile pr = pl.profiles.get(p.getUniqueId()); Companion c = new Companion(); c.owner = p.getUniqueId(); c.world = p.getWorld(); c.stage = pr.stage(); c.mask = maskOf(pr); c.coreScale = 1.25f + 0.1f * c.stage;
        Location t = target(p, 0); c.cur = t.clone();
        c.core = pl.fx.display(c.owner, t, "deswx_vorathis:core_" + c.stage, c.coreScale, null, false, null, 3);
        for (int i = 0; i < 6; i++) { c.fcur[i] = t.clone(); boolean aw = (c.mask & (1 << i)) != 0; c.frag[i] = pl.fx.display(c.owner, t, "deswx_vorathis:frag_" + Relic.values()[i].id + (aw ? "_awake" : "_dormant"), aw ? 1.05f : 0.9f, null, false, null, 3); }
        map.put(c.owner, c); pl.fx.sound(t, "deswx_vorathis:summon", 0.8f, 1f);
        return c;
    }

    private Location target(Player p, int t) {
        Location l = p.getLocation(); double yaw = Math.toRadians(l.getYaw()); Vector fwd = new Vector(-Math.sin(yaw), 0, Math.cos(yaw));
        boolean low = p.isSwimming() || p.isGliding();
        double gap = pl.cfg.d("vorathis.yml", "companion.gap", 1.7), h = pl.cfg.d("vorathis.yml", "companion.height", 1.95);
        return l.clone().add(0, (low ? h * 0.6 : h) + 0.12 * Math.sin(t * 0.07), 0).subtract(fwd.multiply(low ? gap * 0.8 : gap));
    }

    private void tick() {
        tick += 2;
        for (Player p : Bukkit.getOnlinePlayers()) {
            UUID id = p.getUniqueId();
            boolean el = (tick % 10 == 0 || !elig.containsKey(id)) ? eligible(p) : elig.get(id);
            elig.put(id, el);
            if (!el) { if (map.containsKey(id)) despawn(id); continue; }
            Companion c = map.get(id);
            Profile pr = pl.profiles.get(id);
            if (c != null && (c.world != p.getWorld() || c.core == null || !c.core.isValid() || anyInvalid(c) || c.stage != pr.stage() || c.mask != maskOf(pr))) { despawn(id); c = null; }
            if (c == null) c = spawn(p);
            if (c.core == null) continue;
            update(p, c);
            if (tick % 10 == 0) { ArrayDeque<Location> h = hist.computeIfAbsent(id, k -> new ArrayDeque<>()); h.addFirst(p.getLocation().clone()); while (h.size() > 14) h.removeLast(); }
        }
        hist.keySet().removeIf(u -> Bukkit.getPlayer(u) == null);
    }

    private boolean anyInvalid(Companion c) { for (ItemDisplay d : c.frag) if (d == null || !d.isValid()) return true; return false; }

    /** Position the wielder was at roughly `seconds` ago (for SECOND'S REPRIEVE), or null. */
    public Location rewind(Player p, double seconds) {
        ArrayDeque<Location> h = hist.get(p.getUniqueId()); if (h == null || h.isEmpty()) return null;
        int idx = Math.min(h.size() - 1, (int) Math.round(seconds * 2)); int i = 0;
        for (Location l : h) { if (i++ == idx) return l.clone(); }
        return null;
    }
    public void clearHistory(UUID id) { hist.remove(id); }

    private void update(Player p, Companion c) {
        if (tick % 10 == 0) c.alert = pl.combat.enemies(p, p.getLocation(), pl.cfg.d("vorathis.yml", "companion.alert-radius", 14)).isEmpty() ? Math.max(0, c.alert - 10) : 24;
        else if (c.alert > 0) c.alert -= 2;
        if (c.flinch > 0) c.flinch -= 2;
        double speed = c.flinch > 0 ? 0.32 : c.alert > 0 ? 0.14 : 0.05; c.spin += speed;
        if (c.form != null) { c.formT += 2; if (c.formT >= c.formN) c.form = null; }
        Location tgt = target(p, tick);
        Location core = c.form != null ? c.form.at(-1, c.formT) : null;
        if (core == null) core = tgt;
        if (c.cur.getWorld() != core.getWorld() || c.cur.distanceSquared(core) > 400) c.cur = core.clone(); else c.cur.add(core.toVector().subtract(c.cur.toVector()).multiply(c.form != null ? 0.55 : p.getVelocity().lengthSquared() > 0.04 ? 0.5 : 0.3));
        float pulse = (float) (c.coreScale * (1 + (c.alert > 0 ? 0.08 * Math.sin(tick * 0.5) : 0.03 * Math.sin(tick * 0.1))));
        c.core.teleport(c.cur); pl.fx.animate(c.core, new Vector3f(pulse, pulse, pulse), new Quaternionf().rotateY((float) (c.spin * 0.6)).rotateX((float) (0.25 * Math.sin(tick * 0.04))), 2);
        for (int i = 0; i < 6; i++) {
            Location f = c.form != null ? c.form.at(i, c.formT) : null;
            if (f == null) {
                double R = c.flinch > 0 ? 1.7 : c.alert > 0 ? 0.95 : 1.2 + 0.08 * Math.sin(tick * 0.05 + i);
                double ang = c.spin * (i % 2 == 0 ? 1 : -1) * (0.8 + 0.12 * i) + i * Math.PI / 3, tilt = 0.3 + 0.35 * i, phi = i * 1.2;
                Vector nrm = new Vector(Math.sin(tilt) * Math.cos(phi), Math.cos(tilt), Math.sin(tilt) * Math.sin(phi)).normalize();
                Vector u = nrm.clone().crossProduct(new Vector(0, 1, 0)); if (u.lengthSquared() < 1e-4) u = new Vector(1, 0, 0); u.normalize(); Vector v = nrm.clone().crossProduct(u).normalize();
                f = c.cur.clone().add(u.multiply(Math.cos(ang) * R)).add(v.multiply(Math.sin(ang) * R));
            }
            Location fc = c.fcur[i]; if (fc.getWorld() != f.getWorld() || fc.distanceSquared(f) > 400) fc = f.clone(); else fc.add(f.toVector().subtract(fc.toVector()).multiply(c.form != null ? 0.6 : 0.4)); c.fcur[i] = fc;
            boolean aw = (c.mask & (1 << i)) != 0; float sc = aw ? 1.05f : 0.9f;
            c.frag[i].teleport(fc); pl.fx.animate(c.frag[i], new Vector3f(sc, sc, sc), new Quaternionf().rotateY((float) (c.spin * 2 + i)).rotateX((float) (c.spin * 1.3)), 2);
            if (aw && tick % 12 == i * 2 % 12) pl.fx.at(fc).dust(fc, 1, 0.1, Relic.values()[i].color, 0.8f);
        }
        if (tick % 200 == 0) pl.fx.sound(c.cur, "deswx_vorathis:idle", 0.2f, 1f);
        if (c.alert > 0 && tick % 40 == 0) pl.fx.sound(c.cur, "deswx_vorathis:alert", 0.25f, 1.1f);
    }
}
