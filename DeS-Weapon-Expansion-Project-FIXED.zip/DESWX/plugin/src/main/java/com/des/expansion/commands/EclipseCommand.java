package com.des.expansion.commands;

import com.des.expansion.core.DeSWeaponExpansion;
import com.des.expansion.data.Profile;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;

/** /eclipse give|remove|charge|reset|test|reload  (all administrative) */
public final class EclipseCommand implements TabExecutor {
    private final DeSWeaponExpansion pl;
    public EclipseCommand(DeSWeaponExpansion pl) { this.pl = pl; }

    @Override public boolean onCommand(CommandSender s, Command c, String l, String[] a) {
        if (a.length == 0) { Cmd.say(s, "<gold>/eclipse <gray>give|remove|charge|reset|test|reload <dark_gray>(administrators only)"); return true; }
        if (!Cmd.admin(s)) return true;
        switch (a[0].toLowerCase()) {
            case "give" -> { if (a.length < 2) return usage(s, "give <player>"); Player t = Cmd.online(s, a[1]); if (t == null) return true;
                var left = t.getInventory().addItem(pl.items.weapon("eclipse")); if (!left.isEmpty()) { pl.items.revokeSerial(left.values().iterator().next()); Cmd.say(s, "<red>Inventory full - nothing given."); return true; }
                pl.profiles.get(t.getUniqueId()).eclipseOwned = true; pl.adminLog.log(s, "eclipse give " + t.getName()); Cmd.say(s, "<green>Gave ECLIPSE to " + t.getName()); }
            case "remove" -> { if (a.length < 2) return usage(s, "remove <player>"); Player t = Cmd.online(s, a[1]); if (t == null) return true;
                int n = pl.items.removeWeapon(t, "eclipse"); pl.profiles.get(t.getUniqueId()).eclipseOwned = false; pl.adminLog.log(s, "eclipse remove " + t.getName() + " (" + n + ")"); Cmd.say(s, "<green>Removed " + n + " ECLIPSE item(s) from " + t.getName()); }
            case "charge" -> { if (a.length < 2) return usage(s, "charge <player> [amount]"); Player t = Cmd.online(s, a[1]); if (t == null) return true; double v = 100;
                if (a.length > 2) { try { v = Double.parseDouble(a[2]); } catch (NumberFormatException e) { Cmd.say(s, "<red>Invalid number."); return true; } }
                pl.profiles.get(t.getUniqueId()).eclipseCharge = Math.max(0, Math.min(100, v)); pl.adminLog.log(s, "eclipse charge " + t.getName() + " " + v); Cmd.say(s, "<green>Eclipse Charge of " + t.getName() + " set to " + (int) v); }
            case "reset" -> { if (a.length < 2) return usage(s, "reset <player>"); Player t = Cmd.online(s, a[1]); if (t == null) return true; Profile p = pl.profiles.get(t.getUniqueId()); p.eclipseCharge = 0; p.eclipseXp = 0;
                pl.adminLog.log(s, "eclipse reset " + t.getName()); Cmd.say(s, "<green>ECLIPSE progress reset for " + t.getName()); }
            case "test" -> { if (!(s instanceof Player p)) { Cmd.say(s, "<red>Players only."); return true; } if (a.length < 2) return usage(s, "test <ability>"); String id = a[1].toLowerCase();
                if (!pl.abilities.weapon("eclipse").abilities().containsKey(id)) { Cmd.say(s, "<red>Unknown ability."); return true; }
                pl.adminLog.log(s, "eclipse test " + id); Cmd.say(s, "<gray>test " + id + ": <white>" + pl.abilities.cast(p, "eclipse", id, true)); }
            case "reload" -> { pl.cfg.load(); pl.adminLog.log(s, "eclipse reload"); Cmd.say(s, "<green>Configuration reloaded."); }
            default -> Cmd.say(s, "<red>Unknown subcommand.");
        }
        return true;
    }

    private boolean usage(CommandSender s, String u) { Cmd.say(s, "<gray>/eclipse " + u); return true; }

    @Override public List<String> onTabComplete(CommandSender s, Command c, String l, String[] a) {
        if (!s.hasPermission("deswx.admin")) return List.of();
        if (a.length == 1) return Cmd.filter(List.of("give", "remove", "charge", "reset", "test", "reload"), a[0]);
        if (a.length == 2 && a[0].equalsIgnoreCase("test")) return Cmd.filter(new ArrayList<>(pl.abilities.weapon("eclipse").abilities().keySet()), a[1]);
        if (a.length == 2 && !a[0].equalsIgnoreCase("reload")) return Cmd.filter(Cmd.players(), a[1]);
        return List.of();
    }
}
