package com.des.expansion.core;

import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Particle;
import org.bukkit.SoundCategory;
import org.bukkit.World;
import org.bukkit.entity.Display;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.util.Transformation;
import org.bukkit.util.Vector;
import org.joml.Matrix3f;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.UUID;

/** Shared effects toolkit: LOD-aware particles, shapes, tracked ItemDisplays, sounds. Particle counts are configurable (config.yml vfx.*). */
public final class Fx {
    public static final String COMPANION_TAG = "deswx_tracked";
    private final DeSWeaponExpansion pl;
    private final Random rnd = new Random();
    private final Map<String, ItemStack> models = new HashMap<>();
    public Fx(DeSWeaponExpansion pl) { this.pl = pl; }

    public Aud at(Location c) { return new Aud(c); }

    public final class Aud {
        private final Player[] ps; private final float[] f; private int n; private final double mult;
        Aud(Location c) {
            World w = c.getWorld();
            double max = pl.cfg.d("config.yml", "vfx.max-view-distance", 56), red = pl.cfg.d("config.yml", "vfx.reduced-quality-distance", 28);
            float rf = (float) pl.cfg.d("config.yml", "vfx.reduced-quality-factor", 0.4);
            mult = pl.cfg.d("config.yml", "vfx.particle-multiplier", 1.0);
            List<Player> l = w == null ? List.of() : w.getPlayers();
            ps = new Player[l.size()]; f = new float[l.size()];
            for (Player p : l) { double d2 = p.getLocation().distanceSquared(c); if (d2 > max * max) continue; ps[n] = p; f[n++] = d2 > red * red ? rf : 1f; }
        }
        private int st(double v) { int b = (int) v; if (rnd.nextDouble() < v - b) b++; return b; }
        public <T> void particle(Particle p, Location l, int count, double dx, double dy, double dz, double speed, T data) {
            for (int i = 0; i < n; i++) { int c = st(count * f[i] * mult); if (c > 0) ps[i].spawnParticle(p, l, c, dx, dy, dz, speed, data); }
        }
        public void particle(Particle p, Location l, int count, double dx, double dy, double dz, double speed) {
            for (int i = 0; i < n; i++) { int c = st(count * f[i] * mult); if (c > 0) ps[i].spawnParticle(p, l, c, dx, dy, dz, speed); }
        }
        public void dust(Location l, int count, double spread, Color c, float size) { particle(Particle.DUST, l, count, spread, spread, spread, 0, new Particle.DustOptions(c, size)); }
        public void trans(Location l, int count, double spread, Color a, Color b, float size) { particle(Particle.DUST_COLOR_TRANSITION, l, count, spread, spread, spread, 0, new Particle.DustTransition(a, b, size)); }
        public void block(Location l, int count, double spread, Material m) { particle(Particle.BLOCK, l, count, spread, spread, spread, 0.1, Bukkit.createBlockData(m)); }
    }

    public void ring(Aud a, Location c, double r, int pts, double phase, Color col, float size) {
        for (int i = 0; i < pts; i++) { double ang = phase + Math.PI * 2 * i / pts; a.dust(c.clone().add(Math.cos(ang) * r, 0, Math.sin(ang) * r), 1, 0, col, size); }
    }

    public void tilted(Aud a, Location c, Vector axis, double r, int pts, double phase, Color col, float size) {
        Vector ax = axis.clone().normalize();
        Vector u = Math.abs(ax.getY()) < 0.9 ? ax.clone().crossProduct(new Vector(0, 1, 0)).normalize() : new Vector(1, 0, 0);
        Vector v = ax.clone().crossProduct(u).normalize();
        for (int i = 0; i < pts; i++) { double ang = phase + Math.PI * 2 * i / pts; a.dust(c.clone().add(u.clone().multiply(Math.cos(ang) * r).add(v.clone().multiply(Math.sin(ang) * r))), 1, 0, col, size); }
    }

    public void sphere(Aud a, Location c, double r, int pts, Color col, float size) {
        double g = Math.PI * (3 - Math.sqrt(5));
        for (int i = 0; i < pts; i++) { double y = 1 - (i / (double) Math.max(1, pts - 1)) * 2, rad = Math.sqrt(Math.max(0, 1 - y * y)), th = g * i; a.dust(c.clone().add(Math.cos(th) * rad * r, y * r, Math.sin(th) * rad * r), 1, 0, col, size); }
    }

    public void line(Aud a, Location from, Location to, double step, Color col, float size) {
        Vector d = to.toVector().subtract(from.toVector()); double len = d.length();
        if (len < 0.01) return;
        d.normalize().multiply(step); Location cur = from.clone();
        for (double t = 0; t < len; t += step) { a.dust(cur, 1, 0, col, size); cur.add(d); }
    }

    public void crack(Aud a, Location from, Location to, double jitter, Color col, float size) {
        Vector d = to.toVector().subtract(from.toVector()); int segs = Math.max(2, (int) (d.length() / 0.6)); Location prev = from.clone();
        for (int i = 1; i <= segs; i++) {
            Location p = from.clone().add(d.clone().multiply(i / (double) segs));
            if (i < segs) p.add((rnd.nextDouble() - .5) * jitter, (rnd.nextDouble() - .5) * jitter, (rnd.nextDouble() - .5) * jitter);
            line(a, prev, p, 0.3, col, size); prev = p;
        }
    }

    public void column(Aud a, Location base, double h, double r, int rings, Color col, float size) {
        for (int i = 0; i < rings; i++) ring(a, base.clone().add(0, h * i / Math.max(1, rings - 1), 0), r, 8, rnd.nextDouble() * 6, col, size);
    }

    // ------------------------------------------------------------------ displays
    private ItemStack modelStack(String model) {
        return models.computeIfAbsent(model, m -> { ItemStack it = new ItemStack(Material.PAPER); ItemMeta meta = it.getItemMeta(); meta.setItemModel(NamespacedKey.fromString(m)); it.setItemMeta(meta); return it; });
    }

    /** Tracked, non-persistent ItemDisplay. Returns null when display entities are disabled or the live cap is reached. */
    public ItemDisplay display(UUID owner, Location loc, String model, Vector3f scale, Quaternionf rot, boolean glow, Color glowColor, int tp) {
        if (!pl.cfg.b("config.yml", "vfx.use-display-entities", true) || loc.getWorld() == null) return null;
        if (pl.tasks.liveEntities() >= pl.cfg.i("config.yml", "vfx.max-live-displays", 220)) return null;
        final ItemStack stack = modelStack(model); final float view = (float) pl.cfg.d("config.yml", "vfx.display-view-range", 1.0);
        ItemDisplay d = loc.getWorld().spawn(loc, ItemDisplay.class, e -> {
            e.setItemStack(stack); e.setItemDisplayTransform(ItemDisplay.ItemDisplayTransform.NONE);
            e.setTransformation(new Transformation(new Vector3f(), rot == null ? new Quaternionf() : rot, scale, new Quaternionf()));
            e.setBrightness(new Display.Brightness(15, 15)); e.setViewRange(view); e.setShadowRadius(0f);
            e.setPersistent(false); e.setInvulnerable(true); e.setGravity(false);
            e.setInterpolationDelay(0); e.setInterpolationDuration(0); e.setTeleportDuration(Math.max(0, Math.min(59, tp)));
            e.addScoreboardTag(COMPANION_TAG);
            if (glow) { e.setGlowing(true); if (glowColor != null) e.setGlowColorOverride(glowColor); }
        });
        pl.tasks.track(owner, d);
        return d;
    }

    public ItemDisplay display(UUID owner, Location loc, String model, float s, Quaternionf rot, boolean glow, Color gc, int tp) { return display(owner, loc, model, new Vector3f(s, s, s), rot, glow, gc, tp); }

    public void animate(ItemDisplay d, Vector3f scale, Quaternionf rot, int ticks) {
        if (d == null || !d.isValid()) return;
        d.setInterpolationDelay(0); d.setInterpolationDuration(Math.max(1, ticks));
        d.setTransformation(new Transformation(new Vector3f(), rot == null ? new Quaternionf() : rot, scale, new Quaternionf()));
    }

    /** Rotation sending the model's +Y along forward, +Z roughly along upHint. */
    public static Quaternionf orient(Vector forward, Vector upHint) {
        Vector3f y = new Vector3f((float) forward.getX(), (float) forward.getY(), (float) forward.getZ());
        if (y.lengthSquared() < 1e-6) return new Quaternionf();
        y.normalize();
        Vector3f z = new Vector3f((float) upHint.getX(), (float) upHint.getY(), (float) upHint.getZ());
        if (Math.abs(y.dot(z.normalize(new Vector3f()))) > 0.98f) z = new Vector3f(1, 0, 0);
        Vector3f x = new Vector3f(); y.cross(z, x); x.normalize();
        Vector3f zz = new Vector3f(); x.cross(y, zz); zz.normalize();
        return new Quaternionf().setFromNormalized(new Matrix3f(x, y, zz));
    }

    /** XY-plane models (rings, discs, sigils) lie flat on the ground with this rotation. */
    public static Quaternionf flat() { return new Quaternionf().rotateX((float) (-Math.PI / 2)); }

    // ------------------------------------------------------------------ sound
    public void sound(Location l, String id, float vol, float pitch) {
        if (l.getWorld() != null) l.getWorld().playSound(l, id, SoundCategory.PLAYERS, (float) (vol * pl.cfg.d("config.yml", "sounds.master-volume", 1.0)), pitch);
    }
    public void soundTo(Player p, String id, float vol, float pitch) { p.playSound(p.getLocation(), id, SoundCategory.PLAYERS, (float) (vol * pl.cfg.d("config.yml", "sounds.master-volume", 1.0)), pitch); }
}
