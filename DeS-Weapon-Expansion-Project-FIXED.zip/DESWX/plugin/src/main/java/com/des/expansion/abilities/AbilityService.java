package com.des.expansion.abilities;

import com.des.expansion.core.DeSWeaponExpansion;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/** Shared activation pipeline: world/enable checks, cooldown, resource, busy lock, dispatch, selection, HUD. */
public final class AbilityService {
    public enum Result { OK, NOT_HOLDING, BLOCKED, COOLDOWN, NO_RESOURCE, BUSY, FAILED, UNKNOWN }
    private final DeSWeaponExpansion pl;
    private final Map<String, Weapon> weapons = new LinkedHashMap<>();
    private final Set<UUID> busy = new HashSet<>();
    private final Map<UUID, Map<String, Integer>> sel = new HashMap<>();
    private final Map<UUID, Long> msgUntil = new HashMap<>();

    public AbilityService(DeSWeaponExpansion pl) {
        this.pl = pl;
        new BukkitRunnable() { @Override public void run() { hudTick(); } }.runTaskTimer(pl, 20L, 5L);
    }

    public void register(Weapon w) { weapons.put(w.key(), w); }
    public Weapon weapon(String key) { return weapons.get(key); }
    public Iterable<Weapon> all() { return weapons.values(); }
    public boolean isBusy(Player p) { return busy.contains(p.getUniqueId()); }
    public void setBusy(Player p, boolean b) { if (b) busy.add(p.getUniqueId()); else busy.remove(p.getUniqueId()); }

    public int selected(Player p, String weapon) { return sel.computeIfAbsent(p.getUniqueId(), k -> new HashMap<>()).getOrDefault(weapon, 0); }

    public void select(Player p, String weapon, int delta) {
        Weapon w = weapons.get(weapon); int n = w.selectable().size();
        int i = Math.floorMod(selected(p, weapon) + delta, n);
        sel.computeIfAbsent(p.getUniqueId(), k -> new HashMap<>()).put(weapon, i);
        AbilityDef d = w.abilities().get(w.selectable().get(i));
        msg(p, "<gold>[" + (i + 1) + "/" + n + "] <white><bold>" + d.name() + "</bold> <gray>cost <white>" + (int) pl.cfg.cost(weapon, d.id(), d.defCost()));
    }

    public Result castSelected(Player p, String weapon) {
        Weapon w = weapons.get(weapon);
        return cast(p, weapon, w.selectable().get(selected(p, weapon)), false);
    }

    public void msg(Player p, String mm) {
        p.sendActionBar(net.kyori.adventure.text.minimessage.MiniMessage.miniMessage().deserialize(mm));
        msgUntil.put(p.getUniqueId(), System.currentTimeMillis() + 1500);
    }

    public Result cast(Player p, String weapon, String id, boolean forced) {
        Weapon w = weapons.get(weapon);
        if (w == null) return Result.UNKNOWN;
        AbilityDef d = w.abilities().get(id);
        if (d == null) return Result.UNKNOWN;
        if (!forced && !w.holds(p)) return Result.NOT_HOLDING;
        if (!forced && pl.cfg.worldDisabled(p.getWorld().getName())) { msg(p, "<red>Weapons are disabled in this world."); return Result.BLOCKED; }
        if (p.isDead() || !p.isOnline()) return Result.BLOCKED;
        if (!forced && !pl.cfg.abilityEnabled(weapon, id)) { msg(p, "<red>" + d.name() + " is disabled."); return Result.BLOCKED; }
        String why = w.blockReason(p, d, forced);
        if (why != null) { msg(p, "<red>" + d.name() + " <gray>- " + why); pl.fx.soundTo(p, "minecraft:block.note_block.bass", 0.5f, 0.6f); return Result.BLOCKED; }
        if (busy.contains(p.getUniqueId())) return Result.BUSY;
        long cd = pl.cooldowns.remainingMs(p, d.key());
        if (!forced && cd > 0) { msg(p, "<red>" + d.name() + " <gray>cooldown <white>" + String.format("%.1fs", cd / 1000.0)); return Result.COOLDOWN; }
        double cost = pl.cfg.cost(weapon, id, d.defCost());
        if (!forced && cost > 0 && w.resource(p) + 1e-6 < cost) { msg(p, "<yellow>" + d.name() + " <gray>needs <white>" + (int) cost + " " + w.resourceName() + " <gray>(have " + (int) w.resource(p) + ")"); return Result.NO_RESOURCE; }
        Ctx c = new Ctx(pl, p, d, w, forced);
        boolean ok;
        try { ok = d.run().run(c); } catch (Throwable t) { pl.getLogger().log(java.util.logging.Level.SEVERE, "Ability " + d.key() + " failed", t); ok = false; }
        if (!ok) return Result.FAILED;
        if (!forced) { if (cost > 0) w.spend(p, cost); if (!d.selfCooldown()) pl.cooldowns.set(p, d.key(), pl.cfg.cooldown(weapon, id, d.defCd())); }
        pl.profiles.get(p.getUniqueId()).uses.merge(d.key(), 1, Integer::sum);
        w.onCastSuccess(p, d);
        return Result.OK;
    }

    /** Death / quit / world change: stop every running effect of this caster. */
    public void abort(Player p) {
        pl.tasks.cleanup(p.getUniqueId());
        busy.remove(p.getUniqueId());
        for (Weapon w : weapons.values()) w.abort(p);
    }

    private void hudTick() {
        long now = System.currentTimeMillis();
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (msgUntil.getOrDefault(p.getUniqueId(), 0L) > now || !pl.profiles.get(p.getUniqueId()).hud) continue;
            for (Weapon w : weapons.values()) if (w.holds(p)) { p.sendActionBar(net.kyori.adventure.text.minimessage.MiniMessage.miniMessage().deserialize(w.hud(p))); break; }
        }
    }
}
