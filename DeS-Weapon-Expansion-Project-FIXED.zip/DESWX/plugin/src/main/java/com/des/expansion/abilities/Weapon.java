package com.des.expansion.abilities;

import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;

import java.util.List;
import java.util.Map;

/** A weapon plugged into the shared ability framework. */
public interface Weapon {
    String key();
    String display();
    Map<String, AbilityDef> abilities();
    /** ids in selection order (the ultimate is NOT part of the selection ring unless listed here). */
    List<String> selectable();
    String ultimateId();
    /** Is the item currently in the player's main hand a valid copy of this weapon? */
    boolean holds(Player p);
    /** null = allowed; otherwise a human readable reason (locked module, relic missing, ...). */
    String blockReason(Player p, AbilityDef d, boolean forced);
    String resourceName();
    double resource(Player p);
    boolean spend(Player p, double amount);
    void onFirstHit(Ctx c, LivingEntity target);
    default double damageMult(Ctx c, LivingEntity target) { return 1.0; }
    default void onMelee(Player p, LivingEntity victim, EntityDamageByEntityEvent e) { }
    default void onHurt(Player p, EntityDamageEvent e, LivingEntity attacker) { }
    default void onKill(Player p, LivingEntity victim) { }
    default void abort(Player p) { }
    default void onCastSuccess(Player p, AbilityDef d) { }
    String hud(Player p);
}
