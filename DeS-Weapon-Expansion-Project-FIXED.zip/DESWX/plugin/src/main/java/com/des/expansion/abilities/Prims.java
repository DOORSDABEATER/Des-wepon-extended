package com.des.expansion.abilities;

import com.des.expansion.core.Fx;
import com.des.expansion.utilities.Locs;
import org.bukkit.Color;
import org.bukkit.FluidCollisionMode;
import org.bukkit.Location;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;
import java.util.function.Consumer;

/** Reusable ability building blocks shared by all weapons: projectile, field, burst, dash, telegraph, aiming. */
public final class Prims {
    private Prims() { }
    public static final Vector UP = new Vector(0, 1, 0);

    public static final class P {
        public String model; public float scale = 3f; public Location start; public Vector dir; public double range = 14, speed = 1.2, radius = 1.8, dmg = 6; public int pierce = 0;
        public Vector hint = UP; public Color c1 = Color.WHITE, c2 = Color.WHITE; public String hitSound; public boolean arc = true; public Consumer<Location> onEnd; public Consumer<LivingEntity> onHit; public Color glow;
    }

    public static void projectile(Ctx c, P s) {
        final Player p = c.p; final UUID id = p.getUniqueId(); final Vector dir = s.dir.clone().normalize(); final Location pos = s.start.clone();
        final Fx fx = c.pl.fx;
        final ItemDisplay disp = s.model == null ? null : fx.display(id, pos, s.model, s.scale, Fx.orient(dir, s.hint), s.glow != null, s.glow, 1);
        final Set<UUID> hit = new HashSet<>(); final int[] n = {0}; final double[] trav = {0};
        final boolean vertical = Math.abs(s.hint.clone().normalize().getY()) < 0.5;
        c.pl.tasks.timer(id, 1, 1, (int) Math.ceil(s.range / s.speed) + 2, t -> {
            if (!c.alive()) return false;
            pos.add(dir.clone().multiply(s.speed)); trav[0] += s.speed;
            if (!pos.getBlock().isPassable()) return false;
            if (disp != null && disp.isValid()) disp.teleport(pos);
            Fx.Aud a = fx.at(pos);
            if (s.arc && (disp == null || t % 2 == 0)) arcDust(fx, a, pos, dir, s.scale * 0.8, vertical, s.c1, s.c2);
            a.dust(pos.clone().subtract(dir.clone().multiply(0.7)), 3, 0.25, s.c1, 1.1f);
            for (LivingEntity e : c.pl.combat.enemies(p, pos, s.radius)) {
                if (!hit.add(e.getUniqueId())) continue;
                if (c.hit(e, s.dmg)) {
                    Location el = e.getLocation().add(0, e.getHeight() / 2, 0);
                    a.dust(el, 14, 0.4, s.c2, 1.2f);
                    if (s.hitSound != null) fx.sound(el, s.hitSound, 0.9f, 1.0f);
                    if (s.onHit != null) s.onHit.accept(e);
                    n[0]++; if (s.pierce > 0 && n[0] >= s.pierce) return false;
                }
            }
            return trav[0] < s.range;
        }, () -> { if (disp != null) c.pl.tasks.release(id, disp); if (s.onEnd != null) s.onEnd.accept(pos.clone()); });
    }

    public static void arcDust(Fx fx, Fx.Aud a, Location pos, Vector dir, double radius, boolean vertical, Color main, Color alt) {
        Vector d = dir.clone().normalize(); Vector right = d.clone().crossProduct(UP);
        if (right.lengthSquared() < 1e-6) right = new Vector(1, 0, 0); right.normalize();
        Vector side = vertical ? right.clone().crossProduct(d).normalize() : right;
        for (int deg = -70; deg <= 70; deg += 10) { double r = Math.toRadians(deg); a.dust(pos.clone().add(side.clone().multiply(Math.sin(r) * radius)).add(d.clone().multiply((Math.cos(r) - 1) * radius * 0.9)), 1, 0.03, deg % 20 == 0 ? main : alt, 1.1f); }
    }

    public static final class F {
        public Location center; public double radius = 6, pull = 0, tickDmg = 0, endDmg = 0, endKnock = 1.0; public int ticks = 60, tickEvery = 20, slowAmp = -1, slowTicks = 30; public Color c1 = Color.WHITE, c2 = Color.WHITE;
        public String model; public float modelScale = 1f; public String tickSound; public int soundEvery = 20; public Consumer<Integer> onTick; public Runnable onEnd; public String endSound; public boolean sphereEnd = true; public String coreModel; public float coreScale = 2.5f;
    }

    public static void field(Ctx c, F s) {
        final Player p = c.p; final UUID id = p.getUniqueId(); final Fx fx = c.pl.fx; final Location ctr = s.center.clone();
        c.maxHits = Math.max(c.maxHits, 12);
        final ItemDisplay base = s.model == null ? null : fx.display(id, ctr.clone().add(0, 0.12, 0), s.model, new Vector3f(0.5f, 0.5f, 0.5f), Fx.flat(), false, null, 0);
        final float full = (float) (s.radius * 2.13);
        if (base != null) c.pl.tasks.later(id, 1, () -> fx.animate(base, new Vector3f(full, full, full), Fx.flat().rotateZ(1.3f), 12));
        final ItemDisplay core = s.coreModel == null ? null : fx.display(id, ctr.clone().add(0, 1.4, 0), s.coreModel, s.coreScale, null, true, s.c1, 2);
        c.pl.tasks.timer(id, 2, 2, s.ticks / 2, t -> {
            if (!c.alive()) return false;
            Fx.Aud a = fx.at(ctr); double ph = t * 0.2;
            fx.ring(a, ctr.clone().add(0, 0.15, 0), s.radius, (int) (s.radius * 6), ph, s.c1, 1.2f);
            fx.ring(a, ctr.clone().add(0, 0.2, 0), s.radius * (0.35 + 0.5 * ((t % 10) / 10.0)), (int) (s.radius * 3), -ph, s.c2, 1.0f);
            if (core != null && core.isValid() && t % 5 == 0) fx.animate(core, new Vector3f(s.coreScale * (1 + 0.15f * (t / 5 % 2)), s.coreScale, s.coreScale), new Quaternionf().rotateY((float) ph), 10);
            if (s.pull > 0) for (int k = 0; k < 6; k++) { double ang = ph * 2 + k * 1.05, rr = s.radius * (0.4 + 0.6 * ((t * 7 + k * 13) % 20) / 20.0); a.dust(ctr.clone().add(Math.cos(ang) * rr, 0.3 + (1 - rr / s.radius) * 1.2, Math.sin(ang) * rr), 1, 0, s.c2, 1.0f); }
            for (LivingEntity e : c.pl.combat.enemies(p, ctr, s.radius)) {
                if (s.pull > 0) { Vector to = ctr.toVector().add(new Vector(0, 0.5, 0)).subtract(e.getLocation().toVector()); double d = to.length(); if (d < 0.9) e.setVelocity(new Vector(0, 0.02, 0)); else c.pl.combat.push(p, e, to.normalize().multiply(Math.min(s.pull, 0.12 + d * 0.06)), c.castId); }
                if (s.slowAmp >= 0) c.pl.combat.root(p, e, s.slowTicks, s.slowAmp, c.castId);
                if (s.tickDmg > 0 && t > 0 && t % Math.max(1, s.tickEvery / 2) == 0) c.hit(e, s.tickDmg);
            }
            if (s.tickSound != null && t % Math.max(1, s.soundEvery / 2) == 0) fx.sound(ctr, s.tickSound, 0.8f, 1.0f);
            if (s.onTick != null) s.onTick.accept(t);
            return true;
        }, () -> {
            if (c.alive() && (s.endDmg > 0 || s.endKnock > 0)) burst(c, ctr, s.radius + 0.5, s.endDmg, s.endKnock, s.c1, s.c2, s.sphereEnd);
            if (s.endSound != null) fx.sound(ctr, s.endSound, 1.4f, 1.0f);
            if (base != null) c.pl.tasks.release(id, base); if (core != null) c.pl.tasks.release(id, core);
            if (s.onEnd != null) s.onEnd.run();
        });
    }

    public static void burst(Ctx c, Location ctr, double radius, double dmg, double knock, Color c1, Color c2, boolean fx) {
        if (fx) { Fx f = c.pl.fx; Fx.Aud a = f.at(ctr); f.sphere(a, ctr.clone().add(0, 1, 0), radius * 0.5, 36, c1, 1.5f); f.sphere(a, ctr.clone().add(0, 1, 0), radius * 0.3, 20, c2, 1.2f); f.ring(a, ctr.clone().add(0, 0.2, 0), radius, (int) (radius * 8), 0, c1, 1.5f); }
        for (LivingEntity e : c.pl.combat.enemies(c.p, ctr, radius)) {
            boolean ok = dmg <= 0 || c.hit(e, dmg);
            if (ok && knock > 0) { Vector out = e.getLocation().toVector().subtract(ctr.toVector()).setY(0); if (out.lengthSquared() < 1e-4) out = new Vector(1, 0, 0); c.pl.combat.push(c.p, e, out.normalize().multiply(knock).setY(0.4), c.castId); }
        }
    }

    /** Safe short dash (collision/floor/border checked). Returns false when there is no room. */
    public static boolean dash(Ctx c, double dist, int ticks, double hitR, double dmg, Color c1, Color c2, Consumer<Location> onEnd) {
        final Player p = c.p; final Location start = p.getLocation().clone();
        final Vector dir = p.getEyeLocation().getDirection().clone(); dir.setY(Math.max(-0.3, Math.min(0.3, dir.getY()))).normalize();
        Location last = start.clone();
        for (double d = 0.5; d <= dist + 1e-6; d += 0.5) { Location l = start.clone().add(dir.clone().multiply(d)); if (!Locs.standable(l)) break; last = l; }
        while (last.distanceSquared(start) > 1.0 && !Locs.hasFloor(last, 5)) last.subtract(dir.clone().multiply(0.5));
        if (last.distanceSquared(start) < 1.0) return false;
        final Location end = last.clone(); final Vector path = end.toVector().subtract(start.toVector()); final Set<UUID> crossed = new HashSet<>(); final Fx fx = c.pl.fx;
        c.pl.tasks.timer(p.getUniqueId(), 0, 1, ticks + 1, t -> {
            if (!c.alive()) return false;
            double f = (t + 1.0) / ticks; Location pt = start.clone().add(path.clone().multiply(f)); pt.setYaw(p.getLocation().getYaw()); pt.setPitch(p.getLocation().getPitch());
            Location prev = p.getLocation().add(0, 1, 0); p.teleport(pt); p.setVelocity(new Vector(0, 0, 0));
            Fx.Aud a = fx.at(pt); fx.line(a, prev, pt.clone().add(0, 1, 0), 0.3, c1, 1.3f); a.dust(pt.clone().add(0, 1, 0), 8, 0.4, c2, 1.1f);
            for (LivingEntity e : c.pl.combat.enemies(p, pt.clone().add(0, 1, 0), hitR)) if (crossed.add(e.getUniqueId()) && dmg > 0) c.hit(e, dmg);
            return t + 1 < ticks;
        }, () -> { if (onEnd != null && c.alive()) onEnd.accept(end); });
        return true;
    }

    /** Ground telegraph: shrinking ring + filling disc for `ticks`, then `then`. Returns immediately. */
    public static void telegraph(Ctx c, Location ctr, double radius, int ticks, Color c1, Color c2, Runnable then) {
        final Fx fx = c.pl.fx;
        c.pl.tasks.timer(c.p.getUniqueId(), 0, 2, ticks / 2 + 1, t -> {
            Fx.Aud a = fx.at(ctr); double f = Math.min(1.0, (t * 2.0) / ticks);
            fx.ring(a, ctr.clone().add(0, 0.15, 0), radius, (int) (radius * 7), 0, c1, 1.3f);
            fx.ring(a, ctr.clone().add(0, 0.2, 0), radius * f, (int) (radius * 5 * f + 6), t, c2, 1.2f);
            return t * 2 < ticks;
        }, () -> { if (c.alive() && then != null) then.run(); });
    }

    public static LivingEntity aimTarget(Ctx c, double range, double coneDeg) {
        Player p = c.p; Location eye = p.getEyeLocation(); Vector dir = eye.getDirection().normalize(); double minDot = Math.cos(Math.toRadians(coneDeg)); LivingEntity best = null; double bs = -1;
        for (LivingEntity e : c.pl.combat.enemies(p, eye, range)) {
            Vector to = e.getLocation().add(0, e.getHeight() / 2, 0).toVector().subtract(eye.toVector()); double dist = to.length();
            if (dist < 0.1 || dist > range) continue; double dot = to.clone().normalize().dot(dir);
            if (dot < minDot || !p.hasLineOfSight(e)) continue; double sc = dot - dist / (range * 4.0);
            if (sc > bs) { bs = sc; best = e; }
        }
        return best;
    }

    public static Location aimPoint(Player p, double range) {
        Location eye = p.getEyeLocation(); RayTraceResult r = p.getWorld().rayTraceBlocks(eye, eye.getDirection(), range, FluidCollisionMode.NEVER, true);
        if (r == null) return Locs.ground(eye.clone().add(eye.getDirection().multiply(range)));
        Location hit = r.getHitPosition().toLocation(p.getWorld()); if (r.getHitBlockFace() != null) hit.add(r.getHitBlockFace().getDirection().multiply(0.4)); return hit;
    }
}
