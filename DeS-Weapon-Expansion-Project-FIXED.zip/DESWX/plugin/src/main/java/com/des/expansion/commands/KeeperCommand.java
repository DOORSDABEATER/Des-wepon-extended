package com.des.expansion.commands;

import com.des.expansion.core.DeSWeaponExpansion;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;

/** /keeper give|remove|unlock|lock|status|test. While LOCKED (default) the trident cannot be obtained or used except through admin test mode. */
public final class KeeperCommand implements TabExecutor {
    private final DeSWeaponExpansion pl;
    public KeeperCommand(DeSWeaponExpansion pl) { this.pl = pl; }

    @Override public boolean onCommand(CommandSender s, Command c, String l, String[] a) {
        if (a.length == 0) { Cmd.say(s, "<aqua>/keeper <gray>give|remove|unlock|lock|status|test <dark_gray>(state: " + pl.keeper.state() + ")"); return true; }
        if (!Cmd.admin(s)) return true;
        switch (a[0].toLowerCase()) {
            case "status" -> { Cmd.say(s, "<aqua>KEEPER'S TRIDENT <gray>state: <white>" + pl.keeper.state() + " <gray>| keeper_trident.enabled=<white>" + pl.keeper.configEnabled() + " <gray>| ultimate_enabled=<white>" + pl.keeper.ultimateEnabled() + " <gray>| admin test mode=<white>" + pl.keeper.testMode()); }
            case "unlock" -> { pl.keeper.setTestMode(true); pl.adminLog.log(s, "keeper unlock (runtime admin test mode)"); Cmd.say(s, "<green>Admin test mode ON <gray>(runtime only, players with deswx.keeper.test). Public release = set keeper_trident.enabled: true in keeper.yml."); }
            case "lock" -> { pl.keeper.setTestMode(false); pl.adminLog.log(s, "keeper lock"); Cmd.say(s, "<yellow>Admin test mode OFF. <gray>KEEPER'S TRIDENT is " + pl.keeper.state() + "."); }
            case "give" -> { if (a.length < 2) { Cmd.say(s, "<gray>/keeper give <player>"); return true; } Player t = Cmd.online(s, a[1]); if (t == null) return true;
                if (!pl.keeper.configEnabled() && !pl.keeper.testMode()) { Cmd.say(s, "<red>KEEPER'S TRIDENT is LOCKED. <gray>Use /keeper unlock for admin testing."); return true; }
                var left = t.getInventory().addItem(pl.items.weapon("keeper")); if (!left.isEmpty()) { pl.items.revokeSerial(left.values().iterator().next()); Cmd.say(s, "<red>Inventory full."); return true; }
                if (pl.keeper.active(t)) pl.profiles.get(t.getUniqueId()).keeperOwned = true; pl.adminLog.log(s, "keeper give " + t.getName()); Cmd.say(s, "<green>Gave KEEPER'S TRIDENT to " + t.getName()); }
            case "remove" -> { if (a.length < 2) { Cmd.say(s, "<gray>/keeper remove <player>"); return true; } Player t = Cmd.online(s, a[1]); if (t == null) return true;
                int n = pl.items.removeWeapon(t, "keeper"); pl.profiles.get(t.getUniqueId()).keeperOwned = false; pl.adminLog.log(s, "keeper remove " + t.getName()); Cmd.say(s, "<green>Removed " + n + " item(s)."); }
            case "test" -> { if (!(s instanceof Player p)) { Cmd.say(s, "<red>Players only."); return true; } if (a.length < 2) { Cmd.say(s, "<gray>/keeper test <ability>"); return true; } String id = a[1].toLowerCase();
                if (!pl.keeper.abilities().containsKey(id)) { Cmd.say(s, "<red>Unknown ability."); return true; }
                pl.adminLog.log(s, "keeper test " + id); Cmd.say(s, "<gray>test " + id + ": <white>" + pl.abilities.cast(p, "keeper", id, true)); }
            default -> Cmd.say(s, "<red>Unknown subcommand.");
        }
        return true;
    }

    @Override public List<String> onTabComplete(CommandSender s, Command c, String l, String[] a) {
        if (!s.hasPermission("deswx.admin")) return List.of();
        if (a.length == 1) return Cmd.filter(List.of("give", "remove", "unlock", "lock", "status", "test"), a[0]);
        if (a.length == 2 && a[0].equalsIgnoreCase("test")) return Cmd.filter(new ArrayList<>(pl.keeper.abilities().keySet()), a[1]);
        if (a.length == 2 && (a[0].equalsIgnoreCase("give") || a[0].equalsIgnoreCase("remove"))) return Cmd.filter(Cmd.players(), a[1]);
        return List.of();
    }
}
