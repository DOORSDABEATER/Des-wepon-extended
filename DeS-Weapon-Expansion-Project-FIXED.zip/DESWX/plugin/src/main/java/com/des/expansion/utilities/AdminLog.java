package com.des.expansion.utilities;

import com.des.expansion.core.DeSWeaponExpansion;
import org.bukkit.command.CommandSender;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.time.Instant;

/** Administrator action log: console + plugins/DeSWeaponExpansion/admin-actions.log */
public final class AdminLog {
    private final DeSWeaponExpansion pl;
    private final File file;
    public AdminLog(DeSWeaponExpansion pl) { this.pl = pl; this.file = new File(pl.getDataFolder(), "admin-actions.log"); }
    public void log(CommandSender who, String action) {
        String line = Instant.now() + " [" + who.getName() + "] " + action;
        pl.getLogger().info("ADMIN " + line);
        try (FileWriter w = new FileWriter(file, true)) { w.write(line + System.lineSeparator()); } catch (IOException e) { pl.getLogger().warning("admin log: " + e.getMessage()); }
    }
}
