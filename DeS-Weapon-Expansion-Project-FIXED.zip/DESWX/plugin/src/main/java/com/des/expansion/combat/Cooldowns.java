package com.des.expansion.combat;

import org.bukkit.entity.Player;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Central cooldown manager (all three weapons). Key = weapon:ability. */
public final class Cooldowns {
    private final Map<UUID, Map<String, Long>> map = new HashMap<>();
    public static String key(String weapon, String id) { return weapon + ":" + id; }
    public long remainingMs(Player p, String key) { Map<String, Long> m = map.get(p.getUniqueId()); Long u = m == null ? null : m.get(key); return u == null ? 0 : Math.max(0, u - System.currentTimeMillis()); }
    public void set(Player p, String key, double seconds) { map.computeIfAbsent(p.getUniqueId(), k -> new HashMap<>()).put(key, System.currentTimeMillis() + (long) (seconds * 1000)); }
    public void clear(UUID id) { map.remove(id); }
}
