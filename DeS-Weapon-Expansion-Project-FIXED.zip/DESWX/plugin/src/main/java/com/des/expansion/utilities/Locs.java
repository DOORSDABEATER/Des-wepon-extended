package com.des.expansion.utilities;

import org.bukkit.FluidCollisionMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

public final class Locs {
    private Locs() { }
    public static boolean standable(Location feet) {
        World w = feet.getWorld();
        if (w == null || !w.getWorldBorder().isInside(feet) || feet.getY() < w.getMinHeight() || feet.getY() > w.getMaxHeight() - 2) return false;
        Block f = feet.getBlock(), h = feet.clone().add(0, 1, 0).getBlock();
        if (!f.isPassable() || !h.isPassable()) return false;
        Material m = f.getType();
        return m != Material.LAVA && m != Material.FIRE && m != Material.SOUL_FIRE && m != Material.CACTUS && m != Material.MAGMA_BLOCK;
    }
    public static boolean hasFloor(Location feet, int depth) {
        for (int i = 1; i <= depth; i++) { Block b = feet.clone().subtract(0, i, 0).getBlock(); if (!b.isPassable() || b.getType() == Material.WATER) return b.getType() != Material.MAGMA_BLOCK && b.getType() != Material.CACTUS; }
        return false;
    }
    public static Location ground(Location l) {
        World w = l.getWorld(); if (w == null) return l.clone();
        RayTraceResult r = w.rayTraceBlocks(l.clone().add(0, 1.0, 0), new Vector(0, -1, 0), 13, FluidCollisionMode.NEVER, true);
        if (r == null) return l.clone();
        Location g = r.getHitPosition().toLocation(w); g.setYaw(l.getYaw()); g.setPitch(0); return g.add(0, 0.05, 0);
    }
    public static Vector flat(Vector v) { Vector f = new Vector(v.getX(), 0, v.getZ()); return f.lengthSquared() < 1e-6 ? new Vector(0, 0, 1) : f.normalize(); }
}
