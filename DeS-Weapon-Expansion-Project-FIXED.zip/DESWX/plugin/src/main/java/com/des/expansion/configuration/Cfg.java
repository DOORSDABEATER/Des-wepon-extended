package com.des.expansion.configuration;

import com.des.expansion.core.DeSWeaponExpansion;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** config.yml, eclipse.yml, keeper.yml, vorathis.yml, cooldowns.yml, damage.yml. Every getter has a default, so stale files never break the plugin. */
public final class Cfg {
    public static final String[] FILES = {"config.yml", "eclipse.yml", "keeper.yml", "vorathis.yml", "cooldowns.yml", "damage.yml"};
    private final DeSWeaponExpansion pl;
    private final Map<String, YamlConfiguration> y = new HashMap<>();
    public Cfg(DeSWeaponExpansion pl) { this.pl = pl; }

    public void load() {
        for (String f : FILES) {
            File file = new File(pl.getDataFolder(), f);
            if (!file.exists()) pl.saveResource(f, false);
            y.put(f, YamlConfiguration.loadConfiguration(file));
        }
    }
    public YamlConfiguration file(String f) { return y.get(f); }
    public double d(String f, String p, double def) { return y.get(f).getDouble(p, def); }
    public int i(String f, String p, int def) { return y.get(f).getInt(p, def); }
    public boolean b(String f, String p, boolean def) { return y.get(f).getBoolean(p, def); }
    public String s(String f, String p, String def) { return y.get(f).getString(p, def); }
    public List<String> list(String f, String p) { return y.get(f).getStringList(p); }
    /** weapon ability value: <weapon>.yml -> abilities.<id>.<key> */
    public double ab(String weapon, String id, String key, double def) { return d(weapon + ".yml", "abilities." + id + "." + key, def); }
    public double cooldown(String weapon, String id, double def) { return d("cooldowns.yml", weapon + "." + id + ".cooldown", def); }
    public double cost(String weapon, String id, double def) { return d("cooldowns.yml", weapon + "." + id + ".cost", def); }
    public boolean abilityEnabled(String weapon, String id) { return b("cooldowns.yml", weapon + "." + id + ".enabled", true); }
    public boolean worldDisabled(String world) { return list("config.yml", "disabled-worlds").contains(world); }
}
