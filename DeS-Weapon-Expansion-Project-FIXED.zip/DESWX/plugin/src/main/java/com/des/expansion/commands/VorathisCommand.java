package com.des.expansion.commands;

import com.des.expansion.core.DeSWeaponExpansion;
import com.des.expansion.data.Profile;
import com.des.expansion.data.Relic;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * /vorathis ... Physical relic ITEMS (give/add/remove/place/unplace) and permanent relic PROGRESSION (unlock/lock/status/reset) are separate
 * command families and never affect each other. All commands are administrative and logged.
 */
public final class VorathisCommand implements TabExecutor {
    private record Pending(UUID target, boolean full, long expires) { }
    private final DeSWeaponExpansion pl;
    private final Map<String, Pending> pending = new HashMap<>();
    public VorathisCommand(DeSWeaponExpansion pl) { this.pl = pl; }

    private void help(CommandSender s) {
        Cmd.say(s, "<white><bold>VORATHIS</bold> <gray>commands (administrators):");
        Cmd.say(s, "<gray>/vorathis give|remove <player> <dark_gray>- the companion TOKEN item");
        Cmd.say(s, "<gray>/vorathis status|reset <player> | test <ability> | companion <player> <refresh|cleanup> | summon");
        Cmd.say(s, "<yellow>PHYSICAL ITEMS <dark_gray>(do not change progression):");
        Cmd.say(s, "<gray>/vorathis relic give|add|remove <player> <relic> | giveall|addall|removeall <player> | place <relic> | unplace | list");
        Cmd.say(s, "<yellow>PROGRESSION <dark_gray>(do not change items):");
        Cmd.say(s, "<gray>/vorathis relic unlock|lock <player> <relic> | unlockall|lockall <player> | status <player> | reset <player> [confirm]");
    }

    @Override public boolean onCommand(CommandSender s, Command c, String l, String[] a) {
        if (a.length == 0) { if (s.hasPermission("deswx.admin")) help(s); else Cmd.say(s, "<gray>/vorathis summon"); return true; }
        String sub = a[0].toLowerCase();
        if (sub.equals("summon") && s instanceof Player p && p.hasPermission("deswx.vorathis.use")) { pl.vorathis.toggleSummon(p); return true; }
        if (!Cmd.admin(s)) return true;
        switch (sub) {
            case "help" -> help(s);
            case "give" -> { if (a.length < 2) return usage(s, "give <player>"); Player t = Cmd.online(s, a[1]); if (t == null) return true;
                var left = t.getInventory().addItem(pl.items.weapon("vorathis")); if (!left.isEmpty()) { pl.items.revokeSerial(left.values().iterator().next()); Cmd.say(s, "<red>Inventory full."); return true; }
                Profile pr = pl.profiles.get(t.getUniqueId()); pr.vorathisOwned = true; pr.vorathisSummoned = true; pl.vorathis.companions().refresh(t); pl.adminLog.log(s, "vorathis give " + t.getName()); Cmd.say(s, "<green>Gave the VORATHIS token to " + t.getName() + " <gray>(relic progression unchanged)"); }
            case "remove" -> { if (a.length < 2) return usage(s, "remove <player>"); Player t = Cmd.online(s, a[1]); if (t == null) return true;
                int n = pl.items.removeWeapon(t, "vorathis"); pl.profiles.get(t.getUniqueId()).vorathisOwned = false; pl.vorathis.companions().refresh(t); pl.adminLog.log(s, "vorathis remove " + t.getName()); Cmd.say(s, "<green>Removed " + n + " token(s). <gray>Relic progression unchanged."); }
            case "status" -> { if (a.length < 2) return usage(s, "status <player>"); OfflinePlayer o = Cmd.anyone(s, a[1]); if (o != null) status(s, o); }
            case "reset" -> { if (a.length < 2) return usage(s, "reset <player> [confirm]"); OfflinePlayer o = Cmd.anyone(s, a[1]); if (o != null) confirmReset(s, o, true, a.length > 2 && a[2].equalsIgnoreCase("confirm")); }
            case "test" -> { if (!(s instanceof Player p)) { Cmd.say(s, "<red>Players only."); return true; } if (a.length < 2) return usage(s, "test <ability>"); String id = a[1].toLowerCase();
                if (!pl.vorathis.abilities().containsKey(id)) { Cmd.say(s, "<red>Unknown ability."); return true; } pl.adminLog.log(s, "vorathis test " + id); Cmd.say(s, "<gray>test " + id + ": <white>" + pl.abilities.cast(p, "vorathis", id, true)); }
            case "companion" -> { if (a.length < 3) return usage(s, "companion <player> <refresh|cleanup>"); Player t = Cmd.online(s, a[1]); if (t == null) return true;
                if (a[2].equalsIgnoreCase("refresh")) { pl.vorathis.companions().refresh(t); Cmd.say(s, "<green>Companion refreshed for " + t.getName()); } else if (a[2].equalsIgnoreCase("cleanup")) { pl.vorathis.companions().despawn(t.getUniqueId()); pl.tasks.cleanup(t.getUniqueId()); Cmd.say(s, "<green>Companion entities cleaned up for " + t.getName() + " <gray>(it respawns automatically if still eligible)"); } else return usage(s, "companion <player> <refresh|cleanup>");
                pl.adminLog.log(s, "vorathis companion " + t.getName() + " " + a[2]); }
            case "relic" -> relic(s, a);
            default -> Cmd.say(s, "<red>Unknown subcommand. /vorathis help");
        }
        return true;
    }

    private boolean usage(CommandSender s, String u) { Cmd.say(s, "<gray>/vorathis " + u); return true; }

    private void relic(CommandSender s, String[] a) {
        if (a.length < 2) { help(s); return; }
        String op = a[1].toLowerCase();
        switch (op) {
            // ---------------- physical items
            case "give", "add" -> { if (a.length < 4) { usage(s, "relic " + op + " <player> <relic>"); return; } Player t = Cmd.online(s, a[2]); Relic r = Relic.parse(a[3]); if (t == null) return; if (r == null) { Cmd.say(s, "<red>Unknown relic. " + ids()); return; }
                if (!giveRelic(t, r)) { Cmd.say(s, "<red>Inventory full - nothing given."); return; } pl.adminLog.log(s, "relic " + op + " " + t.getName() + " " + r.id); Cmd.say(s, "<green>Gave the physical relic <white>" + r.display + " <green>to " + t.getName() + " <gray>(its power was NOT unlocked)"); }
            case "remove" -> { if (a.length < 4) { usage(s, "relic remove <player> <relic>"); return; } Player t = Cmd.online(s, a[2]); Relic r = Relic.parse(a[3]); if (t == null) return; if (r == null) { Cmd.say(s, "<red>Unknown relic. " + ids()); return; }
                int n = pl.items.removeRelic(t, r); pl.adminLog.log(s, "relic remove " + t.getName() + " " + r.id + " x" + n); Cmd.say(s, "<green>Removed " + n + " physical copy(ies) of " + r.display + " <gray>(unlocked power unchanged)"); }
            case "giveall", "addall" -> { if (a.length < 3) { usage(s, "relic " + op + " <player>"); return; } Player t = Cmd.online(s, a[2]); if (t == null) return; int ok = 0; for (Relic r : Relic.values()) if (giveRelic(t, r)) ok++;
                pl.adminLog.log(s, "relic " + op + " " + t.getName() + " (" + ok + "/6)"); Cmd.say(s, "<green>Gave " + ok + "/6 physical relics to " + t.getName() + (ok < 6 ? " <red>(inventory full)" : "") + " <gray>(no power unlocked)"); }
            case "removeall" -> { if (a.length < 3) { usage(s, "relic removeall <player>"); return; } Player t = Cmd.online(s, a[2]); if (t == null) return; int n = 0; for (Relic r : Relic.values()) n += pl.items.removeRelic(t, r);
                pl.adminLog.log(s, "relic removeall " + t.getName() + " x" + n); Cmd.say(s, "<green>Removed " + n + " physical relic item(s) <gray>(unlocked powers unchanged)"); }
            case "place" -> { if (!(s instanceof Player p)) { Cmd.say(s, "<red>Players only."); return; } if (a.length < 3) { usage(s, "relic place <relic>"); return; } Relic r = Relic.parse(a[2]); if (r == null) { Cmd.say(s, "<red>Unknown relic. " + ids()); return; }
                String id = pl.vorathis.displays().place(p, r); if (id == null) { Cmd.say(s, "<red>Look at a block (max 8 blocks)."); return; } pl.adminLog.log(s, "relic place " + r.id + " id=" + id); Cmd.say(s, "<green>Placed " + r.display + " <gray>(display id " + id + ", progression untouched)"); }
            case "unplace" -> { if (!(s instanceof Player p)) { Cmd.say(s, "<red>Players only."); return; } Relic r = pl.vorathis.displays().unplace(p); if (r == null) { Cmd.say(s, "<red>No placed relic display near your crosshair."); return; } pl.adminLog.log(s, "relic unplace " + r.id); Cmd.say(s, "<green>Removed the placed " + r.display + " display."); }
            case "list" -> { Cmd.say(s, "<gray>Placed relic displays: <white>" + pl.vorathis.displays().count()); for (String d : pl.vorathis.displays().describe()) Cmd.say(s, "<dark_gray> - " + d); }
            // ---------------- progression
            case "unlock", "lock" -> { if (a.length < 4) { usage(s, "relic " + op + " <player> <relic>"); return; } OfflinePlayer o = Cmd.anyone(s, a[2]); Relic r = Relic.parse(a[3]); if (o == null) return; if (r == null) { Cmd.say(s, "<red>Unknown relic. " + ids()); return; }
                pl.vorathis.setRelic(o.getUniqueId(), r, op.equals("unlock")); pl.adminLog.log(s, "relic " + op + " " + o.getName() + " " + r.id); Cmd.say(s, "<green>" + r.display + " " + (op.equals("unlock") ? "UNLOCKED" : "LOCKED") + " for " + o.getName() + " <gray>(physical items untouched)"); }
            case "unlockall", "lockall" -> { if (a.length < 3) { usage(s, "relic " + op + " <player>"); return; } OfflinePlayer o = Cmd.anyone(s, a[2]); if (o == null) return;
                pl.vorathis.setAll(o.getUniqueId(), op.equals("unlockall")); pl.adminLog.log(s, "relic " + op + " " + o.getName()); Cmd.say(s, "<green>All six relics " + (op.equals("unlockall") ? "UNLOCKED" : "LOCKED") + " for " + o.getName() + " <gray>(physical items untouched)"); }
            case "status" -> { if (a.length < 3) { usage(s, "relic status <player>"); return; } OfflinePlayer o = Cmd.anyone(s, a[2]); if (o != null) status(s, o); }
            case "reset" -> { if (a.length < 3) { usage(s, "relic reset <player> [confirm]"); return; } OfflinePlayer o = Cmd.anyone(s, a[2]); if (o != null) confirmReset(s, o, false, a.length > 3 && a[3].equalsIgnoreCase("confirm")); }
            default -> help(s);
        }
    }

    private boolean giveRelic(Player t, Relic r) {
        ItemStack it = pl.items.relic(r); var left = t.getInventory().addItem(it);
        if (!left.isEmpty()) { pl.items.revokeSerial(it); return false; }
        pl.fx.sound(t.getLocation(), "deswx_vorathis:relic_item", 0.6f, 1f); return true;
    }

    private String ids() { StringBuilder b = new StringBuilder("<gray>Relics: "); for (Relic r : Relic.values()) b.append(r.id).append(' '); return b.toString(); }

    private void confirmReset(CommandSender s, OfflinePlayer o, boolean full, boolean confirm) {
        String key = s.getName(); long now = System.currentTimeMillis(); Pending p = pending.get(key);
        if (!confirm || p == null || !p.target().equals(o.getUniqueId()) || p.full() != full || p.expires() < now) {
            pending.put(key, new Pending(o.getUniqueId(), full, now + 30000));
            Cmd.say(s, "<yellow>This will " + (full ? "reset ALL VORATHIS progression (relics, xp, summon state)" : "reset the relic progression") + " of <white>" + o.getName() + "<yellow>. Physical items are NOT touched.");
            Cmd.say(s, "<yellow>Confirm within 30s: <white>/vorathis " + (full ? "reset " : "relic reset ") + o.getName() + " confirm"); return;
        }
        pending.remove(key);
        if (full) { pl.vorathis.resetProgress(o.getUniqueId()); Profile pr = pl.profiles.get(o.getUniqueId()); pr.vorathisSummoned = false; pl.profiles.saveSync(o.getUniqueId()); }
        else pl.vorathis.resetProgress(o.getUniqueId());
        pl.adminLog.log(s, "vorathis " + (full ? "reset" : "relic reset") + " " + o.getName()); Cmd.say(s, "<green>Progression reset for " + o.getName());
    }

    private void status(CommandSender s, OfflinePlayer o) {
        Profile pr = pl.profiles.get(o.getUniqueId()); Player on = o.getPlayer();
        Cmd.say(s, "<white><bold>VORATHIS</bold> <gray>status of <white>" + o.getName() + " <dark_gray>| stage <gold>" + pr.stageName() + " <dark_gray>| <white>" + pr.relicCount() + "<gray>/6 relics unlocked");
        for (Relic r : Relic.values()) {
            String item = on == null ? "<dark_gray>offline" : pl.items.countRelic(on, r) > 0 ? "<green>present x" + pl.items.countRelic(on, r) : "<red>absent";
            boolean u = pr.relicUnlocked[r.index()];
            Cmd.say(s, "<gray> " + r.display + " <dark_gray>(" + r.authority + ") | item: " + item + " <dark_gray>| power: " + (u ? "<green>UNLOCKED" : "<red>locked") + " <dark_gray>| fragment: " + (u ? "<gold>AWAKENED" : "<gray>dormant"));
        }
        Cmd.say(s, "<dark_gray>Physical items and unlocked powers are independent systems.");
    }

    @Override public List<String> onTabComplete(CommandSender s, Command c, String l, String[] a) {
        if (!s.hasPermission("deswx.admin")) return a.length == 1 ? Cmd.filter(List.of("summon"), a[0]) : List.of();
        List<String> relics = new ArrayList<>(); for (Relic r : Relic.values()) relics.add(r.id);
        if (a.length == 1) return Cmd.filter(List.of("help", "give", "remove", "status", "reset", "test", "companion", "summon", "relic"), a[0]);
        String sub = a[0].toLowerCase();
        if (sub.equals("relic")) {
            if (a.length == 2) return Cmd.filter(List.of("give", "add", "remove", "giveall", "addall", "removeall", "place", "unplace", "list", "unlock", "lock", "unlockall", "lockall", "status", "reset"), a[1]);
            String op = a[1].toLowerCase();
            if (a.length == 3 && op.equals("place")) return Cmd.filter(relics, a[2]);
            if (a.length == 3 && !op.equals("unplace") && !op.equals("list")) return Cmd.filter(Cmd.players(), a[2]);
            if (a.length == 4 && List.of("give", "add", "remove", "unlock", "lock").contains(op)) return Cmd.filter(relics, a[3]);
            if (a.length == 4 && op.equals("reset")) return Cmd.filter(List.of("confirm"), a[3]);
            return List.of();
        }
        if (a.length == 2 && sub.equals("test")) return Cmd.filter(new ArrayList<>(pl.vorathis.abilities().keySet()), a[1]);
        if (a.length == 2 && !sub.equals("summon")) return Cmd.filter(Cmd.players(), a[1]);
        if (a.length == 3 && sub.equals("companion")) return Cmd.filter(List.of("refresh", "cleanup"), a[2]);
        if (a.length == 3 && sub.equals("reset")) return Cmd.filter(List.of("confirm"), a[2]);
        return List.of();
    }
}
