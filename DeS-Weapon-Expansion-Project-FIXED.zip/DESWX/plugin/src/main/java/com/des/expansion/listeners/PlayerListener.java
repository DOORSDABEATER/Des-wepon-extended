package com.des.expansion.listeners;

import com.des.expansion.core.DeSWeaponExpansion;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.AsyncPlayerPreLoginEvent;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

import java.util.UUID;

/** Lifecycle: profile load/save, cleanup of tasks/entities/companions on quit, death and world change. */
public final class PlayerListener implements Listener {
    private final DeSWeaponExpansion pl;
    public PlayerListener(DeSWeaponExpansion pl) { this.pl = pl; }

    @EventHandler public void onPreLogin(AsyncPlayerPreLoginEvent e) { if (e.getLoginResult() == AsyncPlayerPreLoginEvent.Result.ALLOWED) pl.profiles.get(e.getUniqueId()); }
    @EventHandler public void onJoin(PlayerJoinEvent e) { pl.profiles.get(e.getPlayer().getUniqueId()).name = e.getPlayer().getName(); }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onQuit(PlayerQuitEvent e) {
        Player p = e.getPlayer(); UUID id = p.getUniqueId();
        pl.abilities.abort(p); pl.cooldowns.clear(id); pl.profiles.saveSync(id); pl.profiles.unload(id);
    }

    @EventHandler(priority = EventPriority.MONITOR) public void onDeath(PlayerDeathEvent e) { pl.abilities.abort(e.getEntity()); }          // companion respawns by itself once eligible again
    @EventHandler public void onWorld(PlayerChangedWorldEvent e) { pl.abilities.abort(e.getPlayer()); }
}
