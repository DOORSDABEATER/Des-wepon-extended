package com.des.expansion.listeners;

import com.des.expansion.abilities.Weapon;
import com.des.expansion.combat.Combat;
import com.des.expansion.core.DeSWeaponExpansion;
import org.bukkit.Bukkit;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.Event;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerItemHeldEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Controls for all three weapons (server side): right-click = cast selected | F = next | Q = previous | Shift+F = ultimate
 * (VORATHIS: Beyond the Impossible) | Shift+scroll = cycle | Shift+right-click with VORATHIS = summon/dismiss the companion.
 */
public final class WeaponListener implements Listener {
    private static final String[] KEYS = {"eclipse", "keeper", "vorathis"};
    private final DeSWeaponExpansion pl;
    private final Map<UUID, Long> last = new HashMap<>();
    public WeaponListener(DeSWeaponExpansion pl) { this.pl = pl; }

    private String key(ItemStack it) { String t = pl.items.typeOf(it); if (t == null) return null; for (String k : KEYS) if (k.equals(t)) return k; return null; }

    @EventHandler(priority = EventPriority.HIGH)
    public void onInteract(PlayerInteractEvent e) {
        if (e.getHand() != EquipmentSlot.HAND || (e.getAction() != Action.RIGHT_CLICK_AIR && e.getAction() != Action.RIGHT_CLICK_BLOCK)) return;
        Player p = e.getPlayer(); ItemStack it = p.getInventory().getItemInMainHand(); String k = key(it); if (k == null) return;
        e.setUseItemInHand(Event.Result.DENY); e.setUseInteractedBlock(Event.Result.DENY); e.setCancelled(true);
        if (!pl.items.valid(it)) { pl.abilities.msg(p, "<red>This item is not a genuine weapon."); return; }
        long now = System.currentTimeMillis();
        if (now - last.getOrDefault(p.getUniqueId(), 0L) < pl.cfg.i("config.yml", "controls.click-debounce-ticks", 4) * 50L) return;
        last.put(p.getUniqueId(), now);
        if (k.equals("vorathis") && p.isSneaking()) { pl.vorathis.toggleSummon(p); return; }
        pl.abilities.castSelected(p, k);
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onSwap(PlayerSwapHandItemsEvent e) {
        Player p = e.getPlayer(); String k = key(e.getOffHandItem()); if (k == null) return;          // the item that was in the main hand
        e.setCancelled(true);
        if (!pl.items.valid(e.getOffHandItem())) return;
        Weapon w = pl.abilities.weapon(k);
        if (p.isSneaking()) pl.abilities.cast(p, k, w.ultimateId(), false); else pl.abilities.select(p, k, 1);
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onDrop(PlayerDropItemEvent e) {
        ItemStack it = e.getItemDrop().getItemStack(); String k = key(it); if (k == null) return;
        e.setCancelled(true);                                                                              // weapons can never be dropped / traded by dropping
        if (pl.items.valid(it)) pl.abilities.select(e.getPlayer(), k, -1);
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onHeld(PlayerItemHeldEvent e) {
        Player p = e.getPlayer(); if (!p.isSneaking()) return;
        String k = key(p.getInventory().getItem(e.getPreviousSlot())); if (k == null || !pl.items.valid(p.getInventory().getItem(e.getPreviousSlot()))) return;
        int a = e.getPreviousSlot(), b = e.getNewSlot(); e.setCancelled(true);
        pl.abilities.select(p, k, (a == 8 && b == 0) ? 1 : (a == 0 && b == 8) ? -1 : Integer.signum(b - a));
    }

    private LivingEntity resolve(Entity d) {
        if (d instanceof LivingEntity le) return le;
        if (d instanceof Projectile pr && pr.getShooter() instanceof LivingEntity le) return le;
        return null;
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onMelee(EntityDamageByEntityEvent e) {
        if (!(e.getEntity() instanceof LivingEntity v) || pl.combat.isInternal(v.getUniqueId()) || !(e.getDamager() instanceof Player p) || e.getCause() != EntityDamageEvent.DamageCause.ENTITY_ATTACK) return;
        ItemStack it = p.getInventory().getItemInMainHand(); String k = key(it); if (k == null || !pl.items.valid(it) || !pl.combat.canTarget(p, v)) return;
        pl.abilities.weapon(k).onMelee(p, v, e);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onHurt(EntityDamageEvent e) {
        if (!(e.getEntity() instanceof Player p)) return;
        LivingEntity attacker = e instanceof EntityDamageByEntityEvent be ? resolve(be.getDamager()) : null;
        for (Weapon w : pl.abilities.all()) w.onHurt(p, e, attacker);
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onDeath(EntityDeathEvent e) {
        LivingEntity v = e.getEntity(); Combat.Tag t = pl.combat.lastHit(v.getUniqueId());
        if (t != null && System.currentTimeMillis() - t.time() < 5000) { Player k = Bukkit.getPlayer(t.attacker()); Weapon w = pl.abilities.weapon(t.weapon()); if (k != null && w != null && !k.equals(v)) w.onKill(k, v); }
        pl.combat.forget(v.getUniqueId());
    }
}
