package com.des.expansion.data;

import com.des.expansion.core.DeSWeaponExpansion;
import org.bukkit.Bukkit;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/** plugins/DeSWeaponExpansion/players/<uuid>.yml. Validated on load (clamped, safe defaults). Snapshot on caller thread, IO may be async. */
public final class ProfileStore {
    private final DeSWeaponExpansion pl;
    private final File dir;
    private final Map<UUID, Profile> cache = new ConcurrentHashMap<>();

    public ProfileStore(DeSWeaponExpansion pl) { this.pl = pl; dir = new File(pl.getDataFolder(), "players"); if (!dir.exists() && !dir.mkdirs()) pl.getLogger().warning("cannot create players dir"); }

    public Profile get(UUID id) { return cache.computeIfAbsent(id, this::load); }
    public boolean loaded(UUID id) { return cache.containsKey(id); }
    private File file(UUID id) { return new File(dir, id + ".yml"); }

    private Profile load(UUID id) {
        Profile p = new Profile(id); File f = file(id);
        if (!f.exists()) return p;
        YamlConfiguration y = YamlConfiguration.loadConfiguration(f);
        p.name = y.getString("name", "");
        p.eclipseOwned = y.getBoolean("eclipse.owned"); p.eclipseCharge = Math.max(0, Math.min(100, y.getDouble("eclipse.charge"))); p.eclipseXp = Math.max(0, y.getLong("eclipse.xp"));
        p.keeperOwned = y.getBoolean("keeper.owned"); p.keeperMarks = Math.max(0, Math.min(5, y.getInt("keeper.marks"))); p.keeperXp = Math.max(0, y.getLong("keeper.xp"));
        p.vorathisOwned = y.getBoolean("vorathis.owned"); p.vorathisSummoned = y.getBoolean("vorathis.summoned"); p.vorathisXp = Math.max(0, y.getLong("vorathis.xp"));
        for (Relic r : Relic.values()) p.relicUnlocked[r.index()] = y.getBoolean("vorathis.relics." + r.id);
        p.hud = y.getBoolean("settings.hud", true);
        ConfigurationSection u = y.getConfigurationSection("uses");
        if (u != null) for (String k : u.getKeys(false)) p.uses.put(k, Math.max(0, u.getInt(k)));
        return p;
    }

    private YamlConfiguration snap(Profile p) {
        YamlConfiguration y = new YamlConfiguration();
        y.set("name", p.name);
        y.set("eclipse.owned", p.eclipseOwned); y.set("eclipse.charge", p.eclipseCharge); y.set("eclipse.xp", p.eclipseXp);
        y.set("keeper.owned", p.keeperOwned); y.set("keeper.marks", p.keeperMarks); y.set("keeper.xp", p.keeperXp);
        y.set("vorathis.owned", p.vorathisOwned); y.set("vorathis.summoned", p.vorathisSummoned); y.set("vorathis.xp", p.vorathisXp);
        for (Relic r : Relic.values()) y.set("vorathis.relics." + r.id, p.relicUnlocked[r.index()]);
        y.set("settings.hud", p.hud);
        for (Map.Entry<String, Integer> e : p.uses.entrySet()) y.set("uses." + e.getKey(), e.getValue());
        return y;
    }

    public void saveSync(UUID id) { Profile p = cache.get(id); if (p == null) return; try { snap(p).save(file(id)); } catch (IOException e) { pl.getLogger().warning("save " + id + ": " + e.getMessage()); } }
    public void saveAllSync() { for (UUID id : cache.keySet()) saveSync(id); }
    public void saveAllAsync() {
        for (Profile p : cache.values()) { YamlConfiguration y = snap(p); File f = file(p.id); Bukkit.getScheduler().runTaskAsynchronously(pl, () -> { try { y.save(f); } catch (IOException ignored) { } }); }
    }
    public void unload(UUID id) { cache.remove(id); }
}
