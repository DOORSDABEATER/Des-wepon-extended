package com.des.expansion.items;

import com.des.expansion.core.DeSWeaponExpansion;
import com.des.expansion.data.Relic;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeModifier;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.EquipmentSlotGroup;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Item identity. Everything is recognised through PersistentDataContainer (type + relic + serial), never name or lore. Serials are issued only by
 * admin commands and registered in serials.yml: copies, renamed items and duplicated stacks are rejected/removed. Physical relic items live here and
 * have NO link to relic progression (data.Profile.relicUnlocked).
 */
public final class WeaponItems {
    private static final MiniMessage MM = MiniMessage.miniMessage();
    private final DeSWeaponExpansion pl;
    private final NamespacedKey kType, kRelic, kSerial;
    private final Set<String> serials = new HashSet<>();
    private final Map<String, UUID> holders = new HashMap<>();
    private final File file;

    public WeaponItems(DeSWeaponExpansion pl) {
        this.pl = pl;
        kType = new NamespacedKey(pl, "type"); kRelic = new NamespacedKey(pl, "relic"); kSerial = new NamespacedKey(pl, "serial");
        file = new File(pl.getDataFolder(), "serials.yml");
        if (file.exists()) serials.addAll(YamlConfiguration.loadConfiguration(file).getStringList("serials"));
    }

    private void save() {
        YamlConfiguration y = new YamlConfiguration(); y.set("serials", new ArrayList<>(serials));
        try { y.save(file); } catch (IOException e) { pl.getLogger().warning("serials.yml: " + e.getMessage()); }
    }

    private Component c(String s) { return MM.deserialize(s).decoration(TextDecoration.ITALIC, false); }

    private ItemStack base(String cfgFile, String defMat, String model, String name, List<String> lore, String type, double attack) {
        Material m = Material.matchMaterial(pl.cfg.s(cfgFile, "item.base-material", defMat)); if (m == null) m = Material.matchMaterial(defMat);
        ItemStack it = new ItemStack(m); ItemMeta meta = it.getItemMeta();
        meta.displayName(c(name)); List<Component> l = new ArrayList<>(); for (String s : lore) l.add(c(s)); meta.lore(l);
        meta.setUnbreakable(true); meta.addItemFlags(ItemFlag.HIDE_UNBREAKABLE, ItemFlag.HIDE_ATTRIBUTES); meta.setEnchantmentGlintOverride(true); meta.setMaxStackSize(1);
        NamespacedKey mk = NamespacedKey.fromString(pl.cfg.s(cfgFile, "item.model", model)); if (mk != null) meta.setItemModel(mk);
        if (attack > 0) meta.addAttributeModifier(Attribute.ATTACK_DAMAGE, new AttributeModifier(new NamespacedKey(pl, "atk_" + type), attack, AttributeModifier.Operation.ADD_NUMBER, EquipmentSlotGroup.MAINHAND));
        String serial = UUID.randomUUID().toString();
        meta.getPersistentDataContainer().set(kType, PersistentDataType.STRING, type);
        meta.getPersistentDataContainer().set(kSerial, PersistentDataType.STRING, serial);
        it.setItemMeta(meta); serials.add(serial); save();
        return it;
    }

    public ItemStack weapon(String key) {
        return switch (key) {
            case "eclipse" -> base("eclipse.yml", "NETHER_STAR", "deswx_eclipse:eclipse", pl.cfg.s("eclipse.yml", "item.display-name", "<gradient:#ff7a00:#fff1c2><bold>ECLIPSE</bold></gradient>"),
                lore("eclipse.yml", List.of("<gold><bold>MYTHICAL</bold> <dark_gray>- <gray>THE SUNLESS CROWN")), "eclipse", pl.cfg.d("eclipse.yml", "item.attack-damage", 6));
            case "keeper" -> base("keeper.yml", "BLAZE_ROD", "deswx_keeper:trident", pl.cfg.s("keeper.yml", "item.display-name", "<gradient:#2de0d0:#e6c35c><bold>KEEPER'S TRIDENT</bold></gradient>"),
                lore("keeper.yml", List.of("<aqua><bold>LEGENDARY</bold> <dark_gray>- <gray>THE SOVEREIGN OF THE DEEP")), "keeper", pl.cfg.d("keeper.yml", "item.attack-damage", 9));
            default -> base("vorathis.yml", "ECHO_SHARD", "deswx_vorathis:sigil", pl.cfg.s("vorathis.yml", "item.display-name", "<gradient:#fff3c4:#ffb347><bold>VORATHIS</bold></gradient>"),
                lore("vorathis.yml", List.of("<white><bold>SECRET</bold> <dark_gray>- <gray>THE SIXFOLD SOVEREIGN")), "vorathis", 0);
        };
    }

    private List<String> lore(String f, List<String> head) { List<String> l = new ArrayList<>(head); l.addAll(pl.cfg.list(f, "item.lore")); return l; }

    public ItemStack relic(Relic r) {
        String hex = String.format("#%02x%02x%02x", r.color.getRed(), r.color.getGreen(), r.color.getBlue());
        ItemStack it = base("vorathis.yml", "AMETHYST_SHARD", "deswx_vorathis:relic_" + r.id, "<color:" + hex + "><bold>" + r.display + "</bold>",
            List.of("<white><bold>SECRET RELIC</bold> <dark_gray>- <gray>Authority of <color:" + hex + ">" + r.authority, "<dark_gray>A physical relic. Holding it does NOT awaken its power.", "<dark_gray>Progression is granted separately by administrators."), "relic", 0);
        // model/material for relic items come from relic-item.* so the weapon token config does not leak into relics
        ItemMeta meta = it.getItemMeta();
        Material m = Material.matchMaterial(pl.cfg.s("vorathis.yml", "relic-item.base-material", "AMETHYST_SHARD"));
        meta.setItemModel(NamespacedKey.fromString("deswx_vorathis:relic_" + r.id));
        meta.getPersistentDataContainer().set(kRelic, PersistentDataType.STRING, r.id);
        it.setItemMeta(meta);
        return m != null && m != it.getType() ? it.withType(m) : it;
    }

    // ------------------------------------------------------------------ identification
    public String typeOf(ItemStack it) { return it == null || !it.hasItemMeta() ? null : it.getItemMeta().getPersistentDataContainer().get(kType, PersistentDataType.STRING); }
    public String serialOf(ItemStack it) { return it == null || !it.hasItemMeta() ? null : it.getItemMeta().getPersistentDataContainer().get(kSerial, PersistentDataType.STRING); }
    public Relic relicOf(ItemStack it) {
        if (!"relic".equals(typeOf(it))) return null;
        String id = it.getItemMeta().getPersistentDataContainer().get(kRelic, PersistentDataType.STRING);
        for (Relic r : Relic.values()) if (r.id.equals(id)) return r;
        return null;
    }
    public boolean registered(ItemStack it) { String s = serialOf(it); return s != null && serials.contains(s); }
    public boolean valid(ItemStack it) { return typeOf(it) != null && (!pl.cfg.b("config.yml", "items.require-serial", true) || registered(it)); }
    public boolean holds(Player p, String key) { ItemStack it = p.getInventory().getItemInMainHand(); return key.equals(typeOf(it)) && valid(it); }
    public boolean has(Player p, String key) { for (ItemStack it : p.getInventory().getContents()) if (it != null && key.equals(typeOf(it)) && valid(it)) return true; return false; }

    public int countRelic(Player p, Relic r) { int n = 0; for (ItemStack it : p.getInventory().getContents()) if (it != null && relicOf(it) == r && valid(it)) n++; return n; }

    /** Removes ONLY physical relic items of this relic (inventory + ender chest). Never touches progression. */
    public int removeRelic(Player p, Relic r) {
        int n = 0;
        n += strip(p.getInventory().getContents(), p.getInventory(), r, null);
        n += strip(p.getEnderChest().getContents(), p.getEnderChest(), r, null);
        if (n > 0) save();
        return n;
    }

    public int removeWeapon(Player p, String key) {
        int n = strip(p.getInventory().getContents(), p.getInventory(), null, key) + strip(p.getEnderChest().getContents(), p.getEnderChest(), null, key);
        if (n > 0) save();
        return n;
    }

    private int strip(ItemStack[] cont, org.bukkit.inventory.Inventory inv, Relic relic, String type) {
        int n = 0;
        for (int i = 0; i < cont.length; i++) {
            ItemStack it = cont[i]; if (it == null) continue;
            boolean match = relic != null ? relicOf(it) == relic : type.equals(typeOf(it));
            if (match) { String s = serialOf(it); if (s != null) serials.remove(s); inv.setItem(i, null); n++; }
        }
        return n;
    }

    /** Removes unregistered fakes and duplicated serials (same inventory, or a copy still held by another online player). */
    public void sanitize(Player p) {
        PlayerInventory inv = p.getInventory(); Set<String> seen = new HashSet<>();
        boolean need = pl.cfg.b("config.yml", "items.require-serial", true);
        for (int i = 0; i < inv.getSize(); i++) {
            ItemStack it = inv.getItem(i);
            if (it == null || typeOf(it) == null) continue;
            String s = serialOf(it);
            boolean fake = need && (s == null || !serials.contains(s));
            boolean dupe = s != null && !seen.add(s);
            if (!fake && !dupe && s != null) {
                UUID h = holders.get(s);
                if (h != null && !h.equals(p.getUniqueId())) { Player other = org.bukkit.Bukkit.getPlayer(h); if (other != null && hasSerial(other, s)) dupe = true; else holders.put(s, p.getUniqueId()); }
                else holders.put(s, p.getUniqueId());
            }
            if (fake || dupe) { inv.setItem(i, null); pl.getLogger().warning("Removed " + (fake ? "unregistered" : "duplicated") + " DeSWX item (" + typeOf(it) + ") from " + p.getName()); }
        }
    }

    private boolean hasSerial(Player p, String s) { for (ItemStack it : p.getInventory().getContents()) if (it != null && s.equals(serialOf(it))) return true; return false; }
    public void revokeSerial(ItemStack it) { String s = serialOf(it); if (s != null && serials.remove(s)) save(); }
}
