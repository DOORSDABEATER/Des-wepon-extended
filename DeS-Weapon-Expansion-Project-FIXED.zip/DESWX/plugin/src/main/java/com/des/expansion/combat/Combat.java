package com.des.expansion.combat;

import com.des.expansion.core.DeSWeaponExpansion;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Tameable;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scoreboard.Team;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Central combat validation and damage: target rules (friendly fire configurable), PvP/PvE/boss multipliers, per-hit health cap vs players,
 * crowd-control resistance, knockback clamp. Damage goes through LivingEntity#damage so vanilla armor and every protection plugin still apply.
 */
public final class Combat {
    public record Tag(UUID attacker, long time, String weapon) { }
    private record Immunity(UUID cast, long until) { }
    private final DeSWeaponExpansion pl;
    private final Set<UUID> internal = new HashSet<>();
    private final Map<UUID, Immunity> cc = new HashMap<>();
    private final Map<UUID, Tag> last = new HashMap<>();
    public Combat(DeSWeaponExpansion pl) { this.pl = pl; }

    private double d(String p, double def) { return pl.cfg.d("damage.yml", p, def); }
    public boolean isInternal(UUID v) { return internal.contains(v); }
    public Tag lastHit(UUID v) { return last.get(v); }
    public void forget(UUID v) { last.remove(v); cc.remove(v); }

    public static double maxHealth(LivingEntity t) { AttributeInstance a = t.getAttribute(Attribute.MAX_HEALTH); return a == null ? 20 : a.getValue(); }

    public boolean isBoss(LivingEntity t) {
        for (String n : pl.cfg.list("damage.yml", "boss-types")) { try { if (t.getType() == EntityType.valueOf(n.toUpperCase())) return true; } catch (IllegalArgumentException ignored) { } }
        return maxHealth(t) >= d("boss-health-threshold", 150);
    }

    public boolean canTarget(Player src, LivingEntity t) {
        if (t == null || t.equals(src) || t.isDead() || !t.isValid() || src.getWorld() != t.getWorld() || t.isInvulnerable()) return false;
        if (t instanceof ArmorStand && pl.cfg.b("damage.yml", "ignore-armor-stands", true)) return false;
        if (t instanceof Player tp) {
            if (!pl.cfg.b("damage.yml", "affect-players", true)) return false;
            if (tp.getGameMode() == GameMode.CREATIVE || tp.getGameMode() == GameMode.SPECTATOR || !tp.getWorld().getPVP()) return false;
            Team team = src.getScoreboard().getEntryTeam(src.getName());
            if (team != null && team.hasEntry(tp.getName()) && !team.allowFriendlyFire() && !pl.cfg.b("damage.yml", "friendly-fire", false)) return false;
        } else {
            if (!pl.cfg.b("damage.yml", "affect-mobs", true)) return false;
            if (t instanceof Tameable tm && tm.isTamed() && src.getUniqueId().equals(tm.getOwnerUniqueId())) return false;
        }
        return true;
    }

    public List<LivingEntity> enemies(Player src, Location c, double r) {
        List<LivingEntity> out = new ArrayList<>();
        if (c.getWorld() == null) return out;
        for (Entity e : c.getWorld().getNearbyEntities(c, r, r, r))
            if (e instanceof LivingEntity le && le.getLocation().add(0, le.getHeight() / 2, 0).distanceSquared(c) <= (r + le.getWidth() / 2) * (r + le.getWidth() / 2) && canTarget(src, le)) out.add(le);
        return out;
    }

    /** raw damage -> multipliers -> health cap -> vanilla damage. True only when health/absorption really dropped. */
    public boolean damage(Player src, LivingEntity t, double raw, String weapon) {
        if (!canTarget(src, t)) return false;
        double a = raw * d("global-multiplier", 1.0) * d("weapon-multipliers." + weapon, 1.0) * (t instanceof Player ? d("pvp-multiplier", 0.8) : d("pve-multiplier", 1.5));
        if (isBoss(t)) a *= d("boss-multiplier", 0.4);
        if (t instanceof Player) a = Math.min(a, maxHealth(t) * d("max-health-fraction-vs-players", 0.5));
        if (a <= 0.01) return false;
        if (pl.cfg.b("damage.yml", "bypass-iframes", true)) t.setNoDamageTicks(0);
        double before = t.getHealth() + t.getAbsorptionAmount(); UUID id = t.getUniqueId();
        internal.add(id);
        try { t.damage(a, src); } finally { internal.remove(id); }
        boolean ok = t.isDead() || t.getHealth() + t.getAbsorptionAmount() < before - 0.001;
        if (ok) last.put(id, new Tag(src.getUniqueId(), System.currentTimeMillis(), weapon));
        return ok;
    }

    public void tag(Player src, LivingEntity t, String weapon) { last.put(t.getUniqueId(), new Tag(src.getUniqueId(), System.currentTimeMillis(), weapon)); }

    public boolean push(Player src, LivingEntity t, Vector vel, UUID cast) {
        if (!canTarget(src, t)) return false;
        double m = isBoss(t) ? d("boss-cc-multiplier", 0.0) : 1.0;
        if (m <= 0) return false;
        long now = System.currentTimeMillis(); Immunity im = cc.get(t.getUniqueId());
        if (im != null && im.until() > now && !im.cast().equals(cast)) return false;
        Vector v = vel.clone().multiply(m); double max = d("max-velocity", 1.5);
        if (v.length() > max) v.normalize().multiply(max);
        if (!Double.isFinite(v.getX() + v.getY() + v.getZ())) return false;
        t.setVelocity(v);
        cc.put(t.getUniqueId(), new Immunity(cast, now + (long) (d("cc-immunity-ticks", 30) * 50)));
        if (cc.size() > 256) cc.values().removeIf(i -> i.until() < now);
        return true;
    }

    /** Slowness-based immobilisation with the same immunity / boss rules (players capped by max-root-ticks-players). */
    public boolean root(Player src, LivingEntity t, int ticks, int amp, UUID cast) {
        if (!canTarget(src, t)) return false;
        if (isBoss(t) && d("boss-cc-multiplier", 0.0) <= 0) return false;
        long now = System.currentTimeMillis(); Immunity im = cc.get(t.getUniqueId());
        if (im != null && im.until() > now && !im.cast().equals(cast)) return false;
        if (t instanceof Player) ticks = Math.min(ticks, (int) d("max-root-ticks-players", 50));
        t.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, ticks, amp, false, true, true));
        return true;
    }
}
