package com.des.expansion.weapons.vorathis;

import com.des.expansion.core.DeSWeaponExpansion;
import com.des.expansion.data.Relic;
import org.bukkit.Bukkit;
import org.bukkit.Chunk;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Administrator-placed relic displays (building / showcase). Persistent (placed-relics.yml), spawned per loaded chunk, floating animation,
 * particles, protected pedestal block. Placing one NEVER touches player progression. Displays have no interaction, so they cannot be
 * broken, stolen or duplicated; only /vorathis relic unplace removes an entry.
 */
public final class RelicDisplays {
    private static final UUID OWNER = new UUID(0xDE5DE5L, 0x7E11CL);
    private static final class Placed { String id; Relic relic; String world; double x, y, z; ItemDisplay d; }
    private final DeSWeaponExpansion pl;
    private final Map<String, Placed> placed = new LinkedHashMap<>();
    private final File file;
    private BukkitTask task; private int tick;

    public RelicDisplays(DeSWeaponExpansion pl) { this.pl = pl; file = new File(pl.getDataFolder(), "placed-relics.yml"); }

    public void start() {
        load();
        for (World w : Bukkit.getWorlds()) for (Chunk ch : w.getLoadedChunks()) chunkLoaded(ch);
        task = new BukkitRunnable() { @Override public void run() { tick(); } }.runTaskTimer(pl, 20L, 4L);
    }

    public void stop() { if (task != null) task.cancel(); for (Placed p : placed.values()) despawn(p); }

    private void load() {
        if (!file.exists()) return; YamlConfiguration y = YamlConfiguration.loadConfiguration(file); ConfigurationSection s = y.getConfigurationSection("placed"); if (s == null) return;
        for (String k : s.getKeys(false)) {
            Relic r = Relic.parse(s.getString(k + ".relic")); if (r == null) continue;
            Placed p = new Placed(); p.id = k; p.relic = r; p.world = s.getString(k + ".world", ""); p.x = s.getDouble(k + ".x"); p.y = s.getDouble(k + ".y"); p.z = s.getDouble(k + ".z"); placed.put(k, p);
        }
    }

    private void save() {
        YamlConfiguration y = new YamlConfiguration();
        for (Placed p : placed.values()) { String k = "placed." + p.id; y.set(k + ".relic", p.relic.id); y.set(k + ".world", p.world); y.set(k + ".x", p.x); y.set(k + ".y", p.y); y.set(k + ".z", p.z); }
        try { y.save(file); } catch (IOException e) { pl.getLogger().warning("placed-relics.yml: " + e.getMessage()); }
    }

    private Location loc(Placed p) { World w = Bukkit.getWorld(p.world); return w == null ? null : new Location(w, p.x, p.y, p.z); }

    private void spawn(Placed p) {
        if (p.d != null && p.d.isValid()) return; Location l = loc(p); if (l == null || !l.getChunk().isLoaded()) return;
        p.d = pl.fx.display(OWNER, l, "deswx_vorathis:relic_" + p.relic.id, 1.8f, null, false, null, 3);
    }
    private void despawn(Placed p) { if (p.d != null) pl.tasks.release(OWNER, p.d); p.d = null; }

    public void chunkLoaded(Chunk ch) { for (Placed p : placed.values()) { Location l = loc(p); if (l != null && l.getWorld() == ch.getWorld() && (l.getBlockX() >> 4) == ch.getX() && (l.getBlockZ() >> 4) == ch.getZ()) spawn(p); } }
    public void chunkUnloaded(Chunk ch) { for (Placed p : placed.values()) { Location l = loc(p); if (l != null && l.getWorld() == ch.getWorld() && (l.getBlockX() >> 4) == ch.getX() && (l.getBlockZ() >> 4) == ch.getZ()) despawn(p); } }

    /** Places the relic display on top of the block the admin is targeting. Returns the entry id or null. */
    public String place(Player admin, Relic r) {
        Block b = admin.getTargetBlockExact(8); if (b == null) return null;
        Placed p = new Placed(); p.id = UUID.randomUUID().toString().substring(0, 8); p.relic = r; p.world = b.getWorld().getName(); p.x = b.getX() + 0.5; p.y = b.getY() + 1.6; p.z = b.getZ() + 0.5;
        placed.put(p.id, p); spawn(p); save(); pl.fx.sound(b.getLocation().add(0.5, 1.5, 0.5), "deswx_vorathis:relic_place", 1f, 1f);
        return p.id;
    }

    /** Removes the placed relic nearest to the admin's crosshair (within 3 blocks). Unrelated entities are never touched. */
    public Relic unplace(Player admin) {
        Block b = admin.getTargetBlockExact(8); Location ref = b != null ? b.getLocation().add(0.5, 1.5, 0.5) : admin.getEyeLocation().add(admin.getEyeLocation().getDirection().multiply(4));
        Placed best = null; double bd = 9;
        for (Placed p : placed.values()) { Location l = loc(p); if (l == null || l.getWorld() != ref.getWorld()) continue; double d = l.distanceSquared(ref); if (d < bd) { bd = d; best = p; } }
        if (best == null) return null; despawn(best); placed.remove(best.id); save(); return best.relic;
    }

    public boolean isPedestal(Block b) {
        for (Placed p : placed.values()) if (p.world.equals(b.getWorld().getName()) && (int) Math.floor(p.x) == b.getX() && (int) Math.floor(p.y - 1.6) == b.getY() && (int) Math.floor(p.z) == b.getZ()) return true;
        return false;
    }
    public int count() { return placed.size(); }
    public List<String> describe() { List<String> l = new ArrayList<>(); for (Placed p : placed.values()) l.add(p.id + " " + p.relic.id + " @ " + p.world + " " + (int) p.x + "," + (int) p.y + "," + (int) p.z); return l; }

    private void tick() {
        tick += 4;
        for (Placed p : placed.values()) {
            if (p.d == null || !p.d.isValid()) continue; Location l = loc(p); if (l == null) continue;
            Location at = l.clone().add(0, 0.18 * Math.sin(tick * 0.08), 0); p.d.teleport(at);
            pl.fx.animate(p.d, new Vector3f(1.8f, 1.8f, 1.8f), new Quaternionf().rotateY((float) (tick * 0.05)), 4);
            if (tick % 20 == 0) pl.fx.at(at).dust(at.clone().add(0, 0.4, 0), 2, 0.35, p.relic.color, 1f);
        }
    }
}
