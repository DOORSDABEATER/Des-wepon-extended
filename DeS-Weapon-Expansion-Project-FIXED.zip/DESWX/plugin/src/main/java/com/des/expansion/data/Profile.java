package com.des.expansion.data;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Persistent per-player data (UUID keyed). */
public final class Profile {
    public final UUID id;
    public String name = "";
    public boolean eclipseOwned; public double eclipseCharge; public long eclipseXp;
    public boolean keeperOwned; public int keeperMarks; public long keeperXp;
    public boolean vorathisOwned, vorathisSummoned; public long vorathisXp;
    public final boolean[] relicUnlocked = new boolean[6];
    public boolean hud = true;
    public final Map<String, Integer> uses = new HashMap<>();
    public Profile(UUID id) { this.id = id; }

    public int relicCount() { int n = 0; for (boolean b : relicUnlocked) if (b) n++; return n; }
    /** Awakening stage 0..4 derived from unlocked relics (0 DORMANT, 1 STIRRING, 2 AWAKENED, 3 ASCENDANT, 4 SIXFOLD). */
    public int stage() { int n = relicCount(); return n == 0 ? 0 : n <= 2 ? 1 : n == 3 ? 2 : n <= 5 ? 3 : 4; }
    public static final String[] STAGE_NAMES = {"DORMANT", "STIRRING", "AWAKENED", "ASCENDANT", "SIXFOLD SOVEREIGN"};
    public String stageName() { return STAGE_NAMES[stage()]; }
}
