package com.des.expansion.core;

import com.des.expansion.abilities.AbilityService;
import com.des.expansion.combat.Combat;
import com.des.expansion.combat.Cooldowns;
import com.des.expansion.commands.EclipseCommand;
import com.des.expansion.commands.KeeperCommand;
import com.des.expansion.commands.VorathisCommand;
import com.des.expansion.configuration.Cfg;
import com.des.expansion.data.ProfileStore;
import com.des.expansion.items.WeaponItems;
import com.des.expansion.listeners.PlayerListener;
import com.des.expansion.listeners.WeaponListener;
import com.des.expansion.utilities.AdminLog;
import com.des.expansion.utilities.TaskTracker;
import com.des.expansion.weapons.eclipse.EclipseModule;
import com.des.expansion.weapons.keeper.KeeperModule;
import com.des.expansion.weapons.vorathis.VorathisModule;
import org.bukkit.Bukkit;
import org.bukkit.command.PluginCommand;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

/** Single entry point of the DeS Weapon Expansion: ECLIPSE, KEEPER'S TRIDENT, VORATHIS. */
public final class DeSWeaponExpansion extends JavaPlugin {
    private static DeSWeaponExpansion instance;
    public Cfg cfg; public ProfileStore profiles; public TaskTracker tasks; public Fx fx; public Combat combat; public Cooldowns cooldowns;
    public AbilityService abilities; public WeaponItems items; public AdminLog adminLog;
    public EclipseModule eclipse; public KeeperModule keeper; public VorathisModule vorathis;

    public static DeSWeaponExpansion get() { return instance; }

    @Override public void onEnable() {
        instance = this;
        cfg = new Cfg(this); cfg.load();
        adminLog = new AdminLog(this);
        profiles = new ProfileStore(this);
        tasks = new TaskTracker(this);
        fx = new Fx(this);
        combat = new Combat(this);
        cooldowns = new Cooldowns();
        items = new WeaponItems(this);
        abilities = new AbilityService(this);
        eclipse = new EclipseModule(this); keeper = new KeeperModule(this); vorathis = new VorathisModule(this);
        abilities.register(eclipse); abilities.register(keeper); abilities.register(vorathis);
        Bukkit.getPluginManager().registerEvents(new PlayerListener(this), this);
        Bukkit.getPluginManager().registerEvents(new WeaponListener(this), this);
        Bukkit.getPluginManager().registerEvents(vorathis, this);
        bind("eclipse", new EclipseCommand(this)); bind("keeper", new KeeperCommand(this)); bind("vorathis", new VorathisCommand(this));
        eclipse.enable(); keeper.enable(); vorathis.enable();
        long save = Math.max(60, cfg.i("config.yml", "autosave-seconds", 300)) * 20L;
        Bukkit.getScheduler().runTaskTimer(this, () -> profiles.saveAllAsync(), save, save);
        Bukkit.getScheduler().runTaskTimer(this, () -> { for (Player p : Bukkit.getOnlinePlayers()) items.sanitize(p); }, 200L, 100L);
        for (Player p : Bukkit.getOnlinePlayers()) profiles.get(p.getUniqueId()).name = p.getName();
        getLogger().info("DeS Weapon Expansion enabled: ECLIPSE, KEEPER'S TRIDENT (" + (keeper.state()) + "), VORATHIS");
    }

    private void bind(String name, org.bukkit.command.TabExecutor ex) {
        PluginCommand c = getCommand(name);
        if (c != null) { c.setExecutor(ex); c.setTabCompleter(ex); }
    }

    @Override public void onDisable() {
        if (vorathis != null) vorathis.disable();
        if (eclipse != null) eclipse.disable();
        if (keeper != null) keeper.disable();
        if (tasks != null) tasks.cleanupAll();
        if (profiles != null) profiles.saveAllSync();
    }
}
