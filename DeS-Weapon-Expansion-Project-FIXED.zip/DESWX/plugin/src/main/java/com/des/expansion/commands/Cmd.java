package com.des.expansion.commands;

import com.des.expansion.core.DeSWeaponExpansion;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;

/** Shared command helpers. */
final class Cmd {
    private Cmd() { }
    static void say(CommandSender s, String mm) { s.sendMessage(net.kyori.adventure.text.minimessage.MiniMessage.miniMessage().deserialize(mm)); }
    static boolean admin(CommandSender s) { if (s.hasPermission("deswx.admin")) return true; say(s, "<red>You do not have permission."); return false; }
    static Player online(CommandSender s, String name) { Player p = Bukkit.getPlayerExact(name); if (p == null) say(s, "<red>Player not found / offline: " + name); return p; }
    static OfflinePlayer anyone(CommandSender s, String name) {
        Player p = Bukkit.getPlayerExact(name); if (p != null) return p;
        OfflinePlayer o = Bukkit.getOfflinePlayerIfCached(name); if (o == null) say(s, "<red>Unknown player: " + name + " <gray>(must have joined this server before)"); return o;
    }
    static List<String> filter(List<String> all, String prefix) { List<String> o = new ArrayList<>(); for (String x : all) if (x.toLowerCase().startsWith(prefix.toLowerCase())) o.add(x); return o; }
    static List<String> players() { List<String> l = new ArrayList<>(); for (Player p : Bukkit.getOnlinePlayers()) l.add(p.getName()); return l; }
    static String s(DeSWeaponExpansion pl, String key) { return key; }
}
