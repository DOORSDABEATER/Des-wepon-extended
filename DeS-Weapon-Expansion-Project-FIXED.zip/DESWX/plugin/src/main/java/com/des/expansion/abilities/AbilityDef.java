package com.des.expansion.abilities;

/** One ability of any weapon. defCd/defCost are fallbacks; real values live in cooldowns.yml. */
public record AbilityDef(String weapon, String id, String name, double defCd, double defCost, boolean ultimate, boolean selfCooldown, Runner run) {
    public interface Runner { boolean run(Ctx c); }
    public String key() { return weapon + ":" + id; }
}
