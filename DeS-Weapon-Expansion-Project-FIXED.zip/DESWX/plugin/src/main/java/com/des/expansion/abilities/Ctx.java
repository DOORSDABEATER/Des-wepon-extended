package com.des.expansion.abilities;

import com.des.expansion.core.DeSWeaponExpansion;
import com.des.expansion.data.Profile;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** One ability activation: per-target hit limits, damage routing, config access. */
public final class Ctx {
    public final DeSWeaponExpansion pl; public final Player p; public final Profile prof; public final AbilityDef def; public final Weapon w;
    public final UUID castId = UUID.randomUUID();
    public final boolean forced;
    public int maxHits = 1; public double gained; public double dmgMult = 1.0;
    private final Map<UUID, Integer> hits = new HashMap<>();

    public Ctx(DeSWeaponExpansion pl, Player p, AbilityDef def, Weapon w, boolean forced) { this.pl = pl; this.p = p; this.prof = pl.profiles.get(p.getUniqueId()); this.def = def; this.w = w; this.forced = forced; }

    public double v(String key, double def0) { return pl.cfg.ab(def.weapon(), def.id(), key, def0); }
    public int vi(String key, int def0) { return (int) Math.round(v(key, def0)); }
    public int distinct() { return hits.size(); }
    public int hitCount(UUID id) { return hits.getOrDefault(id, 0); }

    public boolean hit(LivingEntity t, double raw) {
        int c = hits.getOrDefault(t.getUniqueId(), 0);
        if (c >= maxHits) return false;
        if (!pl.combat.damage(p, t, raw * dmgMult * w.damageMult(this, t), def.weapon())) return false;
        hits.put(t.getUniqueId(), c + 1);
        if (c == 0) w.onFirstHit(this, t);
        return true;
    }
    public boolean alive() { return p.isOnline() && !p.isDead(); }
}
