package com.des.expansion.weapons.keeper;

import com.des.expansion.abilities.AbilityDef;
import com.des.expansion.abilities.Ctx;
import com.des.expansion.abilities.Prims;
import com.des.expansion.abilities.Weapon;
import com.des.expansion.core.DeSWeaponExpansion;
import com.des.expansion.core.Fx;
import com.des.expansion.data.Profile;
import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * KEEPER'S TRIDENT - THE SOVEREIGN OF THE DEEP (LEGENDARY). Fully implemented but LOCKED by default:
 *   keeper.yml -> keeper_trident.enabled: false, keeper_trident.ultimate_enabled: false.
 * Locked = no ability activation, no progression (marks/mastery), no collection hooks, no crafting/drops (none exist), give refused.
 * `/keeper unlock` opens a runtime ADMIN TEST MODE (players with deswx.keeper.test only); it is never written to disk.
 */
public final class KeeperModule implements Weapon {
    public static final String KEY = "keeper", NS = "deswx_keeper:";
    static final Color TEAL = Color.fromRGB(40, 220, 210), AQUA = Color.fromRGB(190, 255, 250), GOLD = Color.fromRGB(230, 195, 90), DEEP = Color.fromRGB(0, 90, 100);
    public static final String[] STAGES = {"DORMANT KEEPER", "AWAKENED SENTINEL", "ETERNAL GUARDIAN"};

    private final DeSWeaponExpansion pl;
    private final Map<String, AbilityDef> defs = new LinkedHashMap<>();
    private final List<String> sel = new ArrayList<>();
    private final Map<UUID, Long> sanctuaryUntil = new HashMap<>(), meleeMark = new HashMap<>();
    private final Map<UUID, Location> sanctuaryCenter = new HashMap<>();
    private final Map<UUID, Map<UUID, Long>> repeat = new HashMap<>();
    private boolean testMode; private BukkitTask task; private int tick;

    public KeeperModule(DeSWeaponExpansion pl) { this.pl = pl; }

    private void reg(String id, String name, double cd, double cost, boolean ult, AbilityDef.Runner r) { defs.put(id, new AbilityDef(KEY, id, name, cd, cost, ult, false, r)); if (!ult) sel.add(id); }

    public void enable() {
        reg("tidal_judgement", "TIDAL JUDGEMENT", 8, 0, false, this::tidal);
        reg("abyssal_vortex", "ABYSSAL VORTEX", 22, 0, false, this::vortex);
        reg("keepers_prison", "KEEPER'S PRISON", 24, 0, false, this::prison);
        reg("skyfall_trident", "SKYFALL TRIDENT", 26, 0, false, this::skyfall);
        reg("sanctuary_of_the_deep", "SANCTUARY OF THE DEEP", 30, 0, false, this::sanctuary);
        reg("worlds_last_anchor", "WORLD'S LAST ANCHOR", 28, 0, false, this::anchor);
        reg("final_seal", "THE FINAL SEAL", 240, 0, true, this::finalSeal);
        task = new BukkitRunnable() { @Override public void run() { aura(); } }.runTaskTimer(pl, 40L, 10L);
    }
    public void disable() { if (task != null) task.cancel(); }

    // ------------------------------------------------------------------ lock state
    public boolean configEnabled() { return pl.cfg.b("keeper.yml", "keeper_trident.enabled", false); }
    public boolean ultimateEnabled() { return pl.cfg.b("keeper.yml", "keeper_trident.ultimate_enabled", false); }
    public boolean testMode() { return testMode; }
    public void setTestMode(boolean b) { testMode = b; }
    public String state() { return configEnabled() ? "ENABLED" : testMode ? "ADMIN TEST MODE" : "LOCKED"; }
    /** Can this player use / progress with the trident right now? */
    public boolean active(Player p) { return configEnabled() || (testMode && p.hasPermission("deswx.keeper.test")); }
    public int stage(Profile pr) { return pr.keeperXp >= pl.cfg.d("keeper.yml", "mastery.eternal-guardian-xp", 3000) ? 2 : pr.keeperXp >= pl.cfg.d("keeper.yml", "mastery.awakened-sentinel-xp", 800) ? 1 : 0; }

    // ------------------------------------------------------------------ Weapon
    @Override public String key() { return KEY; }
    @Override public String display() { return "KEEPER'S TRIDENT"; }
    @Override public Map<String, AbilityDef> abilities() { return defs; }
    @Override public List<String> selectable() { return sel; }
    @Override public String ultimateId() { return "final_seal"; }
    @Override public boolean holds(Player p) { return pl.items.holds(p, KEY); }
    @Override public String resourceName() { return "Keeper's Marks"; }
    @Override public double resource(Player p) { return pl.profiles.get(p.getUniqueId()).keeperMarks; }
    @Override public boolean spend(Player p, double a) { Profile pr = pl.profiles.get(p.getUniqueId()); if (pr.keeperMarks < a) return false; pr.keeperMarks -= (int) a; return true; }
    @Override public String blockReason(Player p, AbilityDef d, boolean forced) {
        if (d.ultimate() && !ultimateEnabled()) return "THE FINAL SEAL is locked until a future update";
        if (configEnabled()) return forced || p.hasPermission("deswx.keeper.use") ? null : "no permission";
        if (forced && p.hasPermission("deswx.admin")) return null;     // /keeper test works for admins even while locked (no progression is recorded)
        return testMode && p.hasPermission("deswx.keeper.test") ? null : "KEEPER'S TRIDENT is locked";
    }
    @Override public String hud(Player p) {
        if (!active(p)) return "<dark_aqua><bold>KEEPER'S TRIDENT</bold> <dark_gray>| <red>LOCKED";
        int sIdx = pl.abilities.selected(p, KEY); AbilityDef d = defs.get(sel.get(sIdx)); long cd = pl.cooldowns.remainingMs(p, d.key()); int m = pl.profiles.get(p.getUniqueId()).keeperMarks;
        String st = cd > 0 ? "<red>" + String.format("%.1fs", cd / 1000.0) : "<green>READY";
        return "<dark_aqua><bold>KEEPER'S TRIDENT</bold> <dark_gray>| <aqua>" + "\u25c6".repeat(m) + "<dark_gray>" + "\u25c7".repeat(Math.max(0, 5 - m)) + " <dark_gray>| <yellow>" + (sIdx + 1) + ". " + d.name() + " " + st;
    }

    @Override public void onFirstHit(Ctx c, LivingEntity t) {
        if (!active(c.p)) return;                      // locked => no accidental progression
        Profile pr = c.prof; int max = pl.cfg.d("keeper.yml", "marks.max", 5) > 0 ? (int) pl.cfg.d("keeper.yml", "marks.max", 5) : 5;
        if (c.distinct() == 1 && pr.keeperMarks < max && !c.def.ultimate()) pr.keeperMarks++;     // one mark per cast that connects
        long now = System.currentTimeMillis(); Map<UUID, Long> rp = repeat.computeIfAbsent(c.p.getUniqueId(), k -> new HashMap<>()); Long last = rp.get(t.getUniqueId());
        if (last == null || now - last > 8000) pr.keeperXp += 2;
        rp.put(t.getUniqueId(), now); if (rp.size() > 64) rp.values().removeIf(x -> now - x > 60000);
    }

    @Override public void onMelee(Player p, LivingEntity v, EntityDamageByEntityEvent e) {
        if (!active(p)) return;
        Profile pr = pl.profiles.get(p.getUniqueId()); long now = System.currentTimeMillis();
        if (p.getAttackCooldown() >= 0.9f && now - meleeMark.getOrDefault(p.getUniqueId(), 0L) > 3000 && pr.keeperMarks < 5) { pr.keeperMarks++; meleeMark.put(p.getUniqueId(), now); pr.keeperXp++; pl.fx.soundTo(p, NS + "mark", 0.6f, 1.1f); }
        pl.combat.tag(p, v, KEY); pl.fx.at(v.getLocation()).dust(v.getLocation().add(0, 1, 0), 8, 0.3, TEAL, 1.1f);
    }

    @Override public void onHurt(Player p, EntityDamageEvent e, LivingEntity attacker) {
        Location c = sanctuaryCenter.get(p.getUniqueId());
        if (c != null && sanctuaryUntil.getOrDefault(p.getUniqueId(), 0L) > System.currentTimeMillis() && c.getWorld() == p.getWorld() && c.distanceSquared(p.getLocation()) <= 36) {
            e.setDamage(e.getDamage() * (1 - pl.cfg.ab(KEY, "sanctuary_of_the_deep", "reduction", 0.30)));
            pl.fx.at(p.getLocation()).dust(p.getLocation().add(0, 1, 0), 10, 0.6, AQUA, 1.1f);
        }
    }
    @Override public void onKill(Player p, LivingEntity v) { if (active(p)) pl.profiles.get(p.getUniqueId()).keeperXp += 3; }
    @Override public void abort(Player p) { sanctuaryUntil.remove(p.getUniqueId()); sanctuaryCenter.remove(p.getUniqueId()); }

    private void aura() {
        tick++;
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (!holds(p) || !active(p)) continue; Profile pr = pl.profiles.get(p.getUniqueId()); int st = stage(pr);
            Location l = p.getLocation().add(0, 1.0, 0); Fx.Aud a = pl.fx.at(l); double t = tick * 0.5;
            a.dust(l.clone().add(Math.cos(t) * 0.8, Math.sin(t * 1.3) * 0.5, Math.sin(t) * 0.8), 1, 0, TEAL, 0.9f);
            if (st >= 1) a.particle(org.bukkit.Particle.BUBBLE_POP, l, 2, 0.5, 0.6, 0.5, 0.01);
            if (st >= 2) pl.fx.ring(a, p.getLocation().add(0, 0.1, 0), 1.1, 8, t, GOLD, 1.0f);
            if (tick % 16 == 0) pl.fx.sound(l, NS + "idle", 0.2f, 1f);
        }
    }

    // ------------------------------------------------------------------ helpers
    private int consume(Ctx c, int max) {
        if (!active(c.p) && !c.forced) return 0; if (!active(c.p)) return 0;
        int n = Math.min(c.prof.keeperMarks, max); if (n > 0) { c.prof.keeperMarks -= n; c.dmgMult *= 1 + n * pl.cfg.d("keeper.yml", "marks.bonus-per-mark", 0.15); pl.fx.soundTo(c.p, NS + "mark", 0.8f, 0.8f); }
        return n;
    }

    // ------------------------------------------------------------------ abilities
    private boolean tidal(Ctx c) {
        Player p = c.p; int n = consume(c, 3); Location eye = p.getEyeLocation(); Vector dir = eye.getDirection().clone(); dir.setY(dir.getY() * 0.4).normalize();
        p.swingMainHand(); pl.fx.sound(p.getLocation(), NS + "a1_tidal", 1.2f, 1f);
        Prims.P s = new Prims.P(); s.model = NS + "wave"; s.scale = (float) (c.v("scale", 3.6) + 0.4 * n); s.start = eye.clone().add(dir.clone().multiply(1.3)).subtract(0, 0.3, 0); s.dir = dir; s.range = c.v("range", 14); s.speed = c.v("speed", 1.3);
        s.radius = c.v("hit-radius", 2.0) + 0.2 * n; s.pierce = c.vi("pierce", 5); s.dmg = c.v("damage", 8); s.c1 = TEAL; s.c2 = AQUA; s.glow = TEAL; s.hitSound = NS + "a1_tidal";
        s.onEnd = end -> pl.fx.at(end).particle(org.bukkit.Particle.SPLASH, end, 30, 0.8, 0.5, 0.8, 0.1);
        Prims.projectile(c, s); return true;
    }

    private boolean vortex(Ctx c) {
        int n = consume(c, 3); Prims.F f = new Prims.F(); f.center = Prims.aimPoint(c.p, c.v("range", 16)); f.radius = c.v("radius", 6) + 0.5 * n; f.pull = c.v("pull", 0.5); f.ticks = c.vi("duration-ticks", 80);
        f.endDmg = c.v("collapse-damage", 7); f.endKnock = 1.0; f.c1 = TEAL; f.c2 = AQUA; f.model = NS + "rune_ring"; f.coreModel = NS + "orb"; f.coreScale = 2.2f; f.tickSound = NS + "a2_vortex"; f.soundEvery = 40; f.endSound = NS + "a4_skyfall";
        c.p.swingMainHand(); pl.fx.sound(f.center, NS + "a2_vortex", 1.3f, 1f); Prims.field(c, f); return true;
    }

    private boolean prison(Ctx c) {
        Player p = c.p; UUID id = p.getUniqueId(); LivingEntity t = Prims.aimTarget(c, c.v("range", 22), 30);
        if (t == null) { pl.abilities.msg(p, "<red>KEEPER'S PRISON <gray>- no target in sight"); return false; }
        int n = consume(c, 2); int ticks = c.vi("duration-ticks", 60) + n * 15; c.maxHits = 2;
        List<LivingEntity> caught = new ArrayList<>(); caught.add(t);
        for (LivingEntity e : pl.combat.enemies(p, t.getLocation(), c.v("spread", 2.5))) if (!e.equals(t) && caught.size() < c.vi("max-targets", 3)) caught.add(e);
        p.swingMainHand(); pl.fx.sound(t.getLocation(), NS + "a3_prison", 1.3f, 1f);
        List<LivingEntity> held = new ArrayList<>(); List<ItemDisplay> cages = new ArrayList<>();
        for (LivingEntity e : caught) {
            if (!pl.combat.root(p, e, ticks, 6, c.castId)) continue;      // honours CC immunity + boss resistance + player cap
            e.addPotionEffect(new PotionEffect(PotionEffectType.JUMP_BOOST, Math.min(ticks, (int) pl.cfg.d("damage.yml", "max-root-ticks-players", 50)), 128, false, false, false));
            held.add(e); c.hit(e, c.v("damage", 4)); ItemDisplay cg = pl.fx.display(id, e.getLocation().add(0, e.getHeight() / 2, 0), NS + "cage", (float) Math.max(2.0, e.getHeight() * 1.2), null, false, null, 2); if (cg != null) cages.add(cg);
        }
        if (held.isEmpty()) { pl.abilities.msg(p, "<yellow>KEEPER'S PRISON <gray>- target resists"); return false; }
        pl.tasks.timer(id, 2, 2, ticks / 2 + 1, t2 -> {
            for (int i = 0; i < held.size() && i < cages.size(); i++) { LivingEntity e = held.get(i); ItemDisplay cg = cages.get(i); if (!e.isValid() || e.isDead() || !cg.isValid()) continue;
                cg.teleport(e.getLocation().add(0, e.getHeight() / 2, 0)); Vector v = e.getVelocity(); e.setVelocity(new Vector(0, Math.min(v.getY(), 0), 0));
                pl.fx.ring(pl.fx.at(e.getLocation()), e.getLocation().add(0, 0.1, 0), 1.0, 10, t2 * 0.4, GOLD, 1f); }
            return c.alive();
        }, () -> { for (ItemDisplay cg : cages) pl.tasks.release(id, cg); for (LivingEntity e : held) if (e.isValid()) { pl.fx.at(e.getLocation()).dust(e.getLocation().add(0, 1, 0), 16, 0.5, AQUA, 1.2f); e.removePotionEffect(PotionEffectType.JUMP_BOOST); } });
        return true;
    }

    private boolean skyfall(Ctx c) {
        Player p = c.p; UUID id = p.getUniqueId(); int n = consume(c, 3); Location ctr = Prims.aimPoint(p, c.v("range", 24)); double rad = c.v("radius", 4); int lead = c.vi("telegraph-ticks", 24);
        p.swingMainHand(); pl.fx.sound(ctr, NS + "a4_skyfall", 1.4f, 0.9f);
        ItemDisplay tri = pl.fx.display(id, ctr.clone().add(0, 22, 0), NS + "trident", 6f, Fx.orient(new Vector(0, -1, 0), new Vector(1, 0, 0)), true, TEAL, 1);
        Prims.telegraph(c, ctr, rad, lead, TEAL, GOLD, null);
        pl.tasks.timer(id, Math.max(1, lead - 8), 1, 10, t -> { if (tri != null && tri.isValid()) tri.teleport(ctr.clone().add(0, 22 * (1 - Math.min(1.0, (t + 1) / 8.0)), 0)); pl.fx.line(pl.fx.at(ctr), ctr.clone().add(0, 22 * (1 - Math.min(1.0, t / 8.0)), 0), ctr, 0.5, TEAL, 1.4f); return c.alive(); },
            () -> { pl.tasks.release(id, tri); if (!c.alive()) return; pl.fx.sound(ctr, NS + "a6_anchor", 1.6f, 1f); Prims.burst(c, ctr, rad, c.v("damage", 14), c.v("knockback", 1.2), TEAL, AQUA, true);
                pl.fx.ring(pl.fx.at(ctr), ctr.clone().add(0, 0.3, 0), rad * 1.8, 50, 0, GOLD, 1.6f); pl.fx.at(ctr).particle(org.bukkit.Particle.SPLASH, ctr.clone().add(0, 1, 0), 60, 2, 1, 2, 0.2); });
        return true;
    }

    private boolean sanctuary(Ctx c) {
        Player p = c.p; UUID id = p.getUniqueId(); int n = consume(c, 3); int dur = c.vi("duration-ticks", 120) + n * 20; double rad = c.v("radius", 5);
        Location ctr = p.getLocation().clone(); sanctuaryCenter.put(id, ctr); sanctuaryUntil.put(id, System.currentTimeMillis() + dur * 50L);
        pl.fx.sound(ctr, NS + "a5_sanctuary", 1.3f, 1f); p.swingMainHand();
        ItemDisplay base = pl.fx.display(id, ctr.clone().add(0, 0.12, 0), NS + "rune_ring", (float) (rad * 2.13), Fx.flat(), false, null, 0);
        pl.tasks.timer(id, 2, 2, dur / 2, t -> {
            if (!c.alive()) return false; Fx.Aud a = pl.fx.at(ctr); pl.fx.ring(a, ctr.clone().add(0, 0.15, 0), rad, 36, t * 0.1, TEAL, 1.2f);
            for (int k = 0; k < 6; k++) { double ang = t * 0.2 + k * 1.05, h = 0.5 + 2.2 * ((t * 3 + k * 7) % 20) / 20.0; a.dust(ctr.clone().add(Math.cos(ang) * rad * 0.95, h, Math.sin(ang) * rad * 0.95), 1, 0, AQUA, 1.0f); }
            if (p.getWorld() == ctr.getWorld() && p.getLocation().distanceSquared(ctr) <= rad * rad && t % 20 == 0) p.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, 50, 0, false, false, true));
            if (t % 5 == 0) for (LivingEntity e : pl.combat.enemies(p, ctr, rad)) { Vector out = e.getLocation().toVector().subtract(ctr.toVector()).setY(0); if (out.lengthSquared() > 1e-4) pl.combat.push(p, e, out.normalize().multiply(0.35).setY(0.1), c.castId); }
            return true;
        }, () -> { pl.tasks.release(id, base); sanctuaryUntil.remove(id); sanctuaryCenter.remove(id); });
        return true;
    }

    private boolean anchor(Ctx c) {
        Player p = c.p; UUID id = p.getUniqueId(); int n = consume(c, 2); Location ctr = Prims.aimPoint(p, c.v("range", 20)); double rad = c.v("radius", 6); int lead = c.vi("telegraph-ticks", 16);
        p.swingMainHand(); pl.fx.sound(ctr, NS + "a6_anchor", 1.4f, 0.9f);
        ItemDisplay tri = pl.fx.display(id, ctr.clone().add(0, 16, 0), NS + "trident", 7f, Fx.orient(new Vector(0, -1, 0), new Vector(1, 0, 0)), true, GOLD, 1);
        pl.tasks.timer(id, 1, 1, lead, t -> { if (tri != null && tri.isValid()) tri.teleport(ctr.clone().add(0, 16 * (1 - (t + 1.0) / lead), 0)); return c.alive(); }, () -> pl.tasks.later(id, 6, () -> pl.tasks.release(id, tri)));
        Prims.telegraph(c, ctr, rad, lead, GOLD, TEAL, () -> {
            pl.fx.sound(ctr, NS + "a6_anchor", 1.6f, 1.1f); pl.fx.sphere(pl.fx.at(ctr), ctr.clone().add(0, 1, 0), 3, 30, GOLD, 1.5f);
            for (LivingEntity e : pl.combat.enemies(p, ctr, rad)) {
                if (!c.hit(e, c.v("damage", 9))) continue;
                pl.combat.root(p, e, c.vi("root-ticks", 80) + n * 20, 3, c.castId);
                pl.combat.push(p, e, new Vector(0, -0.9, 0), c.castId);       // anchored: pulled down
                if (e instanceof Player tp && tp.isGliding()) tp.setGliding(false);
            }
        });
        return true;
    }

    /** Reserved ultimate. Only runs when keeper_trident.ultimate_enabled is true (blocked otherwise by blockReason). */
    private boolean finalSeal(Ctx c) {
        Player p = c.p; UUID id = p.getUniqueId(); if (c.prof.keeperMarks < 5 && !c.forced) { pl.abilities.msg(p, "<yellow>THE FINAL SEAL <gray>needs 5 Keeper's Marks"); return false; }
        c.prof.keeperMarks = 0; double rad = c.v("radius", 10); Location ctr = p.getLocation().clone(); c.maxHits = 1;
        pl.fx.sound(ctr, NS + "u_seal", 3f, 1f);
        ItemDisplay ring = pl.fx.display(id, ctr.clone().add(0, 0.12, 0), NS + "rune_ring", (float) (rad * 2.13), Fx.flat(), true, TEAL, 0);
        Prims.telegraph(c, ctr, rad, c.vi("telegraph-ticks", 50), TEAL, GOLD, () -> {
            Prims.burst(c, ctr, rad, c.v("damage", 20), 1.0, TEAL, GOLD, true);
            for (LivingEntity e : pl.combat.enemies(p, ctr, rad)) pl.combat.root(p, e, 60, 5, c.castId);
            pl.tasks.release(id, ring);
        });
        return true;
    }
}
