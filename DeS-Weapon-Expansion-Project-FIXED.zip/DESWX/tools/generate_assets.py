#!/usr/bin/env python3
"""DeS Weapon Expansion - resource pack generator (ECLIPSE / KEEPER'S TRIDENT / VORATHIS).
Self-contained, deterministic. Namespaces: deswx_eclipse, deswx_keeper, deswx_vorathis. Run: python3 tools/generate_assets.py"""
import json, math, os, shutil, subprocess, sys
import numpy as np
from PIL import Image
from scipy import signal
from scipy.io import wavfile

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
PACK = os.path.join(ROOT, "resourcepack")
FR = 8; SR = 44100
rng = np.random.default_rng(2026)
yy, xx = np.mgrid[0:16, 0:16]
N1 = rng.random((16, 16)); N2 = rng.random((16, 16))
C = lambda *v: np.array(v, float)

def mix(a, b, t): t = np.clip(t, 0, 1)[..., None]; return a * (1 - t) + b * t
def blank(a=255): t = np.zeros((16, 16, 4), float); t[..., 3] = a; return t
def wave(f, k=8.0): return (np.sin(2 * math.pi * (yy / k - f / FR)) + 1) / 2
def tile_solid(col, noise=8):
    def g(f): t = blank(); t[..., :3] = col + N1[..., None] * noise; return t
    return g
def tile_flow(dark, bright, k=8.0):
    def g(f): t = blank(); w = wave(f, k) * (0.6 + 0.4 * np.sin(xx * 0.7 + yy * 0.2)); t[..., :3] = mix(dark, bright, w); return t
    return g
def tile_fx(col, col2, lo=90, hi=230, k=8.0):
    def g(f):
        t = blank(0); e = 1 - np.abs(yy - 7.5) / 8; s = 0.6 + 0.4 * np.sin(2 * math.pi * (xx / k - f / FR))
        t[..., :3] = mix(col, col2, e ** 2) * s[..., None]; t[..., 3] = np.clip(lo + (hi - lo) * e, 0, 255); return t
    return g
def tile_rings(col, bg=0, a=235, rings=(2.5, 5.5, 7.4), glyph=True):
    G = np.zeros((16, 16), bool)
    for r in (3, 8, 12): G[r, 3:13] = True
    for c in (4, 8, 11): G[2:14, c] = rng.random(12) > 0.4
    def g(f):
        t = blank(bg); d = np.hypot(xx - 7.5, yy - 7.5)
        for r in rings: m = np.abs(d - r) < 0.9; t[m, :3] = col; t[m, 3] = a
        if glyph:
            m = G & (d < 7); p = 0.6 + 0.4 * np.sin(2 * math.pi * (f / FR + d / 9)); t[m, :3] = col[None, :] * p[m][:, None]; t[m, 3] = a
        return t
    return g
def tile_glow(col, col2, a=230):
    def g(f):
        t = blank(0); d = np.hypot(xx - 7.5, yy - 7.5) / 10; p = 0.8 + 0.2 * math.sin(2 * math.pi * f / FR)
        t[..., :3] = mix(col2, col, 1 - d) * p; t[..., 3] = np.clip(a * (1.1 - d), 0, 255); return t
    return g
def tile_runes(col, bg):
    G = np.zeros((16, 16), bool)
    for x in range(16): G[int(round(7.5 + 4 * math.sin(x * 0.7))), x] = True
    for x in range(1, 15, 4): G[2:14, x] = rng.random(12) > 0.3
    def g(f):
        t = blank(); t[..., :3] = bg + N2[..., None] * 6; p = 0.55 + 0.45 * np.sin(2 * math.pi * (f / FR + (xx + yy) / 24.0)); t[G, :3] = col[None, :] * p[G][:, None]; return t
    return g
def tile_prism():
    def g(f):
        t = blank(); h = (xx + yy) / 30.0 + f / FR
        for i in range(3): t[..., i] = 128 + 127 * np.sin(2 * math.pi * (h + i / 3.0))
        return t
    return g
def tile_core(col, hot):
    def g(f):
        t = blank(); d = np.hypot(xx - 7.5, yy - 7.5) / 9; p = 0.75 + 0.25 * math.sin(2 * math.pi * f / FR)
        vein = (np.sin(xx * 1.3 + yy * 0.9 + f) > 0.7) * 0.3; t[..., :3] = mix(hot, col, d + vein) * p; return t
    return g

ECL = {"BLACK": tile_solid(C(14, 12, 12)), "EDGE": tile_flow(C(120, 30, 0), C(255, 130, 10)), "CORE": tile_core(C(255, 150, 30), C(255, 248, 215)),
       "EMBER": tile_glow(C(255, 140, 20), C(120, 30, 0), 200), "FXSLASH": tile_fx(C(255, 110, 10), C(255, 245, 200)), "FXDISC": tile_rings(C(255, 120, 10), 235, 240, (3, 6.5), False),
       "FXTRAP": tile_rings(C(255, 130, 20)), "FXSUN": tile_glow(C(255, 250, 220), C(255, 140, 20), 245)}
KEE = {"OBS": tile_solid(C(10, 14, 16)), "TEAL": tile_flow(C(0, 90, 100), C(40, 230, 215)), "GOLD": tile_solid(C(215, 170, 60), 25),
       "RUNE": tile_runes(C(60, 255, 230), C(10, 18, 20)), "FXWAVE": tile_fx(C(20, 170, 190), C(190, 255, 250)), "FXRING": tile_rings(C(60, 240, 220)),
       "FXCAGE": tile_fx(C(40, 200, 200), C(255, 215, 120), 110, 235, 4), "FXBUBBLE": tile_glow(C(200, 255, 250), C(20, 150, 170), 190)}
RELIC_COL = [C(255, 236, 160), C(80, 225, 255), C(150, 120, 255), C(255, 170, 40), C(165, 185, 95), C(235, 235, 245)]
VOR = {"STONE": tile_solid(C(60, 56, 50), 14), "CORE": tile_core(C(255, 205, 120), C(255, 252, 235)), "METAL": tile_solid(C(40, 34, 24), 10)}
for i, c in enumerate(RELIC_COL): VOR[f"R{i}"] = tile_prism() if i == 5 else tile_flow(c * 0.35, c)
VOR.update({"FXRIFT": tile_rings(C(170, 140, 255), 160, 235, (2, 5, 7.4), False), "FXCONSTRUCT": tile_fx(C(255, 170, 40), C(255, 245, 200)), "FXGLOW": tile_glow(C(255, 245, 210), C(255, 180, 60), 200)})

def atlas(ns, gens):
    names = list(gens); T = {n: ((i % 4) * 16, (i // 4) * 16) for i, n in enumerate(names)}; img = np.zeros((64 * FR, 64, 4), np.uint8)
    for f in range(FR):
        fr = np.zeros((64, 64, 4), float)
        for n, (px, py) in T.items(): fr[py:py + 16, px:px + 16] = gens[n](f)
        img[f * 64:(f + 1) * 64] = np.clip(fr, 0, 255).astype(np.uint8)
    d = os.path.join(PACK, "assets", ns, "textures/item"); os.makedirs(d, exist_ok=True)
    Image.fromarray(img, "RGBA").save(os.path.join(d, "atlas.png"))
    json.dump({"animation": {"frametime": 2, "interpolate": True}}, open(os.path.join(d, "atlas.png.mcmeta"), "w"), indent=2)
    return T

class NS:
    def __init__(s, ns, T):
        s.ns = ns; s.T = T; s.dir = os.path.join(PACK, "assets", ns); s.n = {}
        for x in ("models/item", "items", "sounds", "lang"): os.makedirs(os.path.join(s.dir, x), exist_ok=True)
    def box(s, f, t, tile, rot=None, emit=False, shade=True):
        for v in list(f) + list(t): assert -16 <= v <= 32, (s.ns, f, t)
        assert all(t[i] > f[i] for i in range(3)), (f, t)
        dims = {"north": (t[0] - f[0], t[1] - f[1]), "south": (t[0] - f[0], t[1] - f[1]), "east": (t[2] - f[2], t[1] - f[1]), "west": (t[2] - f[2], t[1] - f[1]), "up": (t[0] - f[0], t[2] - f[2]), "down": (t[0] - f[0], t[2] - f[2])}
        u0, v0 = s.T[tile][0] / 4.0, s.T[tile][1] / 4.0
        faces = {fc: {"uv": [u0, v0, u0 + min(max(w, .6), 4), v0 + min(max(h, .6), 4)], "texture": "#0"} for fc, (w, h) in dims.items()}
        e = {"from": [round(x, 3) for x in f], "to": [round(x, 3) for x in t], "faces": faces}
        if rot: e["rotation"] = {"angle": rot[0], "axis": rot[1], "origin": [round(o, 3) for o in rot[2]]}
        if emit: e["light_emission"] = 15
        if not shade: e["shade"] = False
        return e
    def cb(s, c, z, tile, rot=None, **kw):
        return s.box([c[i] - z[i] / 2 for i in range(3)], [c[i] + z[i] / 2 for i in range(3)], tile, rot=(rot[0], rot[1], tuple(c)) if rot else None, **kw)
    def save(s, name, els, display=None):
        m = {"textures": {"0": f"{s.ns}:item/atlas", "particle": f"{s.ns}:item/atlas"}, "elements": els}
        if display: m["display"] = display
        json.dump(m, open(os.path.join(s.dir, "models/item", name + ".json"), "w"), indent=1)
        json.dump({"model": {"type": "minecraft:model", "model": f"{s.ns}:item/{name}"}}, open(os.path.join(s.dir, "items", name + ".json"), "w"), indent=1)
        s.n[name] = len(els)

def octa(S, plane, ap, th, h, tile, emit=True, c=(8, 8, 8)):
    side = 2 * ap * math.tan(math.radians(22.5)); out = []
    def P(a, b, n): return {"xy": (c[0] + a, c[1] + b, c[2] + n), "xz": (c[0] + a, c[1] + n, c[2] + b), "yz": (c[0] + n, c[1] + a, c[2] + b)}[plane]
    def straight(a0, b0, a1, b1):
        p0, p1 = P(a0, b0, -h / 2), P(a1, b1, h / 2)
        return S.box([min(p0[i], p1[i]) for i in range(3)], [max(p0[i], p1[i]) for i in range(3)], tile, emit=emit, shade=False)
    out += [straight(-side / 2, -ap, side / 2, -ap + th), straight(-side / 2, ap - th, side / 2, ap), straight(ap - th, -side / 2, ap, side / 2), straight(-ap, -side / 2, -ap + th, side / 2)]
    k = ap - th / 2; axis = {"xy": "z", "xz": "y", "yz": "x"}[plane]
    for sa, sb in ((1, 1), (-1, -1), (1, -1), (-1, 1)):
        ang = (-45 if sa == sb else 45) * (-1 if plane == "xz" else 1)
        size = {"xy": (side, th, h), "xz": (side, h, th), "yz": (h, side, th)}[plane]
        out.append(S.cb(P(sa * k * 0.7071, sb * k * 0.7071, 0), size, tile, rot=(ang, axis), emit=emit, shade=False))
    return out

def arc(S, R, cy, angs, widths, depth, tile):
    return [S.cb((8 + R * math.sin(math.radians(p)), cy + R * math.cos(math.radians(p)), 8), (7.0, w, depth), tile, rot=(-p, "z") if p else None, emit=True, shade=False) for p, w in zip(angs, widths)]
def slash_model(S, t1, t2): return arc(S, 16, -6, (-45, -22.5, 0, 22.5, 45), (1.0, 2.4, 4.0, 2.4, 1.0), 1.3, t1) + arc(S, 16.9, -6, (-45, -22.5, 0, 22.5, 45), (.4, .8, 1.2, .8, .4), .8, t2)
def orb(S, r, t_out, t_core):
    c = (8, 8, 8)
    return [S.cb(c, (r, r, r), t_out, emit=True, shade=False), S.cb(c, (r, r, r), t_out, rot=(45, "y"), emit=True, shade=False), S.cb(c, (r, r, r), t_out, rot=(45, "x"), emit=True, shade=False), S.cb(c, (r * .55,) * 3, t_core, rot=(45, "z"), emit=True, shade=False)]

def hold_display(sc, ty3, tz3, ty1, tz1):
    return {"thirdperson_righthand": {"rotation": [0, -90, 10], "translation": [0, ty3, tz3], "scale": [sc] * 3}, "thirdperson_lefthand": {"rotation": [0, -90, 10], "translation": [0, ty3, tz3], "scale": [sc] * 3},
            "firstperson_righthand": {"rotation": [0, -90, -20], "translation": [1.13, ty1, tz1], "scale": [sc * .8] * 3}, "firstperson_lefthand": {"rotation": [0, -90, -20], "translation": [-1.13, ty1, tz1], "scale": [sc * .8] * 3},
            "gui": {"rotation": [0, 0, -40], "translation": [0, 0, 0], "scale": [.40] * 3}, "ground": {"rotation": [0, 0, 0], "translation": [0, 4, 0], "scale": [.5] * 3}, "fixed": {"rotation": [0, 180, -40], "translation": [0, 0, 0], "scale": [.4] * 3}}
def icon_display(sc=0.62):
    return {"gui": {"rotation": [20, 35, 0], "translation": [0, 0, 0], "scale": [sc] * 3}, "ground": {"rotation": [0, 0, 0], "translation": [0, 3, 0], "scale": [.5] * 3}, "fixed": {"rotation": [0, 180, 0], "translation": [0, 0, 0], "scale": [.5] * 3},
            "thirdperson_righthand": {"rotation": [0, 0, 0], "translation": [0, 3, 1], "scale": [.5] * 3}, "firstperson_righthand": {"rotation": [0, 0, 0], "translation": [1, 3, 1], "scale": [.5] * 3}}

def build_eclipse():
    S = NS("deswx_eclipse", atlas("deswx_eclipse", ECL))
    ch = octa(S, "xy", 7.6, 1.8, 1.6, "BLACK", emit=False) + octa(S, "xy", 5.9, 0.9, 1.0, "EDGE") + octa(S, "xy", 4.6, 0.6, 1.4, "BLACK", emit=False)
    ch += [S.cb((8, 8, 8), (3.2, 3.2, 1.2), "CORE", rot=(45, "z"), emit=True, shade=False), S.cb((8, 8, 8), (1.8, 1.8, 1.6), "FXSUN", emit=True, shade=False)]
    for ang in (0, 45):
        ch += [S.cb((8, 8, 8), (9.2, 0.8, 1.0), "EDGE", rot=(ang, "z") if ang else None, emit=True, shade=False), S.cb((8, 8, 8), (0.8, 9.2, 1.0), "EDGE", rot=(ang, "z") if ang else None, emit=True, shade=False)]
    for k in range(8):
        a = math.radians(k * 45 + 22.5); ch.append(S.cb((8 + 8.3 * math.cos(a), 8 + 8.3 * math.sin(a), 8), (1.4, 1.4, 1.2), "BLACK", rot=(45, "z")))
    S.save("chakram", ch, icon_display(.55)); S.save("eclipse", ch, icon_display(.55))
    S.save("solar_slash", slash_model(S, "FXSLASH", "CORE")); S.save("sun_core", orb(S, 8, "FXSUN", "CORE"))
    S.save("eclipse_disc", [S.cb((8, 8, 8), (13, 13, 0.8), "BLACK", shade=False), S.cb((8, 8, 8), (13, 13, 0.8), "BLACK", rot=(45, "z"), shade=False)] + octa(S, "xy", 7.9, 1.0, 1.2, "EDGE") + octa(S, "xy", 9.6, 0.6, 0.8, "FXSUN"))
    trap = octa(S, "xy", 7.8, .9, .3, "FXTRAP") + octa(S, "xy", 5.4, .7, .3, "FXTRAP") + octa(S, "xy", 3, .6, .3, "EDGE")
    for ang in (0, 45): trap += [S.cb((8, 8, 8), (14.8, .7, .3), "FXTRAP", rot=(ang, "z") if ang else None, emit=True, shade=False), S.cb((8, 8, 8), (.7, 14.8, .3), "FXTRAP", rot=(ang, "z") if ang else None, emit=True, shade=False)]
    S.save("trap", trap)
    return S

def build_keeper():
    S = NS("deswx_keeper", atlas("deswx_keeper", KEE)); E = []
    E += [S.box((7.0, -14, 7.0), (9.0, 14, 9.0), "OBS"), S.box((7.4, -14, 9.0), (8.6, 14, 9.15), "RUNE", emit=True, shade=False), S.cb((8, -14.6, 8), (3, 2.4, 3), "TEAL", rot=(45, "y"), emit=True)]
    for y in (-11, -5, 1, 7): E.append(S.box((6.4, y, 6.4), (9.6, y + 1.2, 9.6), "GOLD"))
    E += [S.box((4.0, 13, 6.6), (12.0, 14.6, 9.4), "GOLD"), S.box((6.6, 14.6, 6.8), (9.4, 17, 9.2), "GOLD"), S.box((7.2, 17, 7.2), (8.8, 30, 8.8), "OBS"),
          S.box((7.55, 17, 8.8), (8.45, 28, 8.95), "TEAL", emit=True, shade=False), S.cb((8, 30.6, 8), (1.4, 2.2, 1.4), "TEAL", rot=(45, "z"), emit=True)]
    for s in (-1, 1):
        cx = 8 + s * 4.4
        E += [S.box((cx - .8, 14.6, 7.2), (cx + .8, 24, 8.8), "OBS"), S.cb((cx + s * .8, 25.4, 8), (1.6, 3.4, 1.6), "OBS", rot=(-22.5 * s, "z")), S.cb((cx + s * 1.6, 27.4, 8), (1.2, 2.6, 1.2), "TEAL", rot=(-45 * s, "z"), emit=True),
              S.box((cx - .4, 14.6, 8.8), (cx + .4, 23, 8.95), "TEAL", emit=True, shade=False), S.box((cx - s * 1.6 - .4, 17, 7.6), (cx - s * 1.6 + .4, 20, 8.4), "GOLD")]
    for (px, py, pz) in ((12.5, 2, 9.5), (3.5, -6, 6.5), (12, 20, 6)): E.append(S.cb((px, py, pz), (1.0, 2.6, 1.0), "FXBUBBLE", rot=(22.5, "z"), emit=True, shade=False))
    S.save("trident", E, hold_display(1.0, 5.98, 0.16, 4.70, 1.67))
    S.save("wave", slash_model(S, "FXWAVE", "FXBUBBLE"))
    S.save("rune_ring", octa(S, "xy", 7.8, .9, .3, "FXRING") + octa(S, "xy", 5.5, .7, .3, "FXRING") + octa(S, "xy", 3, .6, .3, "GOLD"))
    cage = [S.cb((8 + 6 * math.cos(math.radians(k * 45)), 8, 8 + 6 * math.sin(math.radians(k * 45))), (.9, 15, .9), "FXCAGE", emit=True, shade=False) for k in range(8)]
    cage += octa(S, "xz", 6.6, .9, .6, "GOLD", c=(8, 1, 8)) + octa(S, "xz", 6.6, .9, .6, "GOLD", c=(8, 15, 8)); S.save("cage", cage)
    S.save("orb", orb(S, 8, "FXBUBBLE", "TEAL"))
    return S

RELICS = ["witness", "last_second", "weightless_heart", "first_spark", "final_remnant", "unnamed"]
def shape(S, i, accent, awake):
    body = accent if awake else "STONE"; em = awake; core = "CORE" if awake else "METAL"; E = []
    if i == 0: E += [S.cb((8, 8, 8), (8, 8, 1.6), body, rot=(45, "z"), emit=em), S.cb((8, 8, 8), (3, 3, 2.2), core, rot=(45, "z"), emit=em), S.cb((8, 8, 8), (1.2, 1.2, 2.6), "METAL")]
    elif i == 1:
        for k in range(4): E += [S.cb((8, 12.5 - k * 1.1, 8), (8 - k * 1.8,) * 1 + (1.1, 8 - k * 1.8), body, emit=em), S.cb((8, 3.5 + k * 1.1, 8), (8 - k * 1.8, 1.1, 8 - k * 1.8), body, emit=em)]
        E.append(S.cb((8, 8, 8), (1.0, 3, 1.0), core, emit=em))
    elif i == 2: E += octa(S, "xy", 5.6, 1.2, 1.4, body, emit=em) + [S.cb((8, 8, 8), (3.6, 3.6, 3.6), core, rot=(45, "y"), emit=em)]
    elif i == 3: E += [S.cb((8, 8, 8), (3, 10, 3), body, emit=em), S.cb((8, 8, 8), (3, 10, 3), body, rot=(45, "y"), emit=em), S.cb((8, 8, 8), (10, 3, 3), body, rot=(45, "z"), emit=em), S.cb((8, 8, 8), (2.4, 2.4, 2.4), core, rot=(45, "x"), emit=em)]
    elif i == 4: E += [S.cb((7, 9, 8), (3, 9, 1.8), body, rot=(22.5, "z"), emit=em), S.cb((10.2, 7.2, 8), (2.4, 7, 1.8), body, rot=(-22.5, "z"), emit=em), S.cb((8.2, 12.4, 8.4), (1.6, 3, 1.2), body, rot=(45, "z"), emit=em), S.cb((8.8, 4, 7.6), (1.4, 2.4, 1.2), "METAL")]
    else: E += [S.cb((8, 8, 8), (1.6, 11, 1.6), body, emit=em), S.cb((8, 8, 8), (11, 1.6, 1.6), body, emit=em), S.cb((8, 8, 8), (1.4, 8, 1.4), body, rot=(45, "z"), emit=em), S.cb((8, 8, 8), (1.4, 8, 1.4), body, rot=(-45, "z"), emit=em), S.cb((8, 8, 8), (2.6, 2.6, 2.6), "METAL", rot=(45, "y"))]
    if awake: E.append(S.cb((8, 8, 8), (13, 13, 0.5), "FXGLOW", emit=True, shade=False))
    return E
def shift_y(e, dy):
    e = json.loads(json.dumps(e)); e["from"][1] += dy; e["to"][1] += dy
    if "rotation" in e: e["rotation"]["origin"][1] += dy
    return e

def build_vorathis():
    S = NS("deswx_vorathis", atlas("deswx_vorathis", VOR))
    for i, r in enumerate(RELICS):
        S.save(f"frag_{r}_dormant", shape(S, i, f"R{i}", False)); S.save(f"frag_{r}_awake", shape(S, i, f"R{i}", True))
        base = [S.box((3, 1, 3), (13, 3, 13), "STONE"), S.box((4.5, 3, 4.5), (11.5, 4, 11.5), "METAL")]
        S.save(f"relic_{r}", base + [shift_y(e, 3) for e in shape(S, i, f"R{i}", True)], icon_display(.6))
    for st in range(5):
        E = [S.cb((8, 8, 8), (6, 6, 6), "STONE", rot=(45, "y")), S.cb((8, 8, 8), (6, 6, 6), "STONE", rot=(45, "x")), S.cb((8, 8, 8), (3.6 + st * .8,) * 3, "CORE", rot=(45, "z"), emit=st > 0)]
        if st >= 1: E += octa(S, "xy", 6.2, .7, .8, "R0" if st < 3 else "METAL")
        if st >= 2: E += octa(S, "yz", 7.0, .7, .8, "R1" if st < 4 else "METAL")
        if st >= 3: E += octa(S, "xz", 7.8, .8, .8, "R3") + [S.cb((8, 8, 8), (15, .6, .6), "METAL"), S.cb((8, 8, 8), (.6, 15, .6), "METAL")]
        if st >= 4: E += octa(S, "xy", 9.0, .8, .8, "R5") + [S.cb((8 + 9.5 * math.cos(math.radians(k * 60)), 8 + 9.5 * math.sin(math.radians(k * 60)), 8), (1.4,) * 3, f"R{k}", rot=(45, "z"), emit=True) for k in range(6)] + [S.cb((8, 8, 8), (22, 22, .3), "FXGLOW", emit=True, shade=False)]
        S.save(f"core_{st}", E, icon_display(.6) if st == 0 else None)
    S.save("sigil", [S.cb((8, 8, 8), (6, 6, 6), "STONE", rot=(45, "y")), S.cb((8, 8, 8), (3.4,) * 3, "CORE", rot=(45, "z"), emit=True)] + octa(S, "xy", 6.0, .8, .8, "R0") + octa(S, "yz", 7.2, .8, .8, "R5"), icon_display(.62))
    S.save("construct", [S.cb((8, 8, 8), (2.4, 30, 1.2), "FXCONSTRUCT", emit=True, shade=False), S.cb((8, 8, 8), (1.2, 32, 1.8), "R3", emit=True, shade=False), S.cb((8, 22, 8), (4, 2, 1.6), "R3", rot=(45, "z"), emit=True), S.cb((8, -5, 8), (5, 1.2, 1.4), "METAL")])
    S.save("rift", octa(S, "xy", 7.6, 1.2, .8, "FXRIFT") + octa(S, "xy", 5.4, .8, .8, "R2") + [S.cb((8, 8, 8), (8, 8, .6), "FXRIFT", rot=(45, "z"), emit=True, shade=False)])
    S.save("beam", [S.cb((8, 8, 8), (3, 3, 30), "FXCONSTRUCT", emit=True, shade=False), S.cb((8, 8, 8), (1.4, 1.4, 31), "FXGLOW", emit=True, shade=False)])
    return S

def Tt(d): return np.arange(int(SR * d)) / SR
def noise(d): return rng.normal(0, 1, int(SR * d))
def env(d, a=.005, k=4.0): t = Tt(d); return np.exp(-k * t / d) * np.minimum(1, t / max(a, 1e-4))
def lp(x, fc): b, a = signal.butter(4, min(fc, SR / 2 - 100) / (SR / 2), "low"); return signal.lfilter(b, a, x)
def hp(x, fc): b, a = signal.butter(4, fc / (SR / 2), "high"); return signal.lfilter(b, a, x)
def band(x, f0, f1, bw=.6):
    n = len(x); f, tt, Z = signal.stft(x, SR, nperseg=1024); fc = f0 * (f1 / f0) ** np.linspace(0, 1, Z.shape[1])
    m = np.exp(-.5 * ((np.log2(f[:, None] + 1e-3) - np.log2(fc[None, :])) / bw) ** 2); _, y = signal.istft(Z * m, SR, nperseg=1024); return np.pad(y[:n], (0, max(0, n - len(y))))
def sweep(d, f0, f1, c=2.0): t = Tt(d); f = f0 * (f1 / f0) ** ((t / d) ** (1 / c)); return np.sin(2 * math.pi * np.cumsum(f) / SR)
def dist(x, k=3.0): return np.tanh(x * k) / np.tanh(k)
def mixl(*p): n = max(len(x) for x in p); return sum(np.pad(x, (0, n - len(x))) for x in p)
def at(x, off, total): y = np.zeros(int(SR * total)); i = int(SR * off); y[i:i + len(x)] += x[:len(y) - i]; return y
def whoosh(d, f0, f1, bw=.6, sub=0): e = np.sin(np.pi * np.clip(Tt(d) / d, 0, 1)) ** 1.5; x = band(noise(d), f0, f1, bw) * e; return x + (sweep(d, f0 / 6, f1 / 8) * sub * e if sub else 0)
def impact(d, f0, f1, nz=.35, k=2.5): return dist(sweep(d, f0, f1, 1.5) * env(d, .002, 5) + lp(noise(d), 2500) * env(d, .0005, 18) * nz, k)
def boom(d, l0=1800, sub=48, tail=3.0):
    n = noise(d); y = np.zeros_like(n)
    for sg, fc in ((0, l0), (.15, l0 * .35), (.4, 220)): i = int(sg * SR); y[i:] += lp(n[i:], fc) * (.5 if sg else 1)
    t = Tt(d); return dist(y * np.exp(-tail * t / d) + sweep(d, sub * 1.8, sub * .6, 1) * np.exp(-2.2 * t / d) * 1.2, 1.8)
def charge(d, f0, f1, tr0=4, tr1=26, nz=.35, harm=3):
    t = Tt(d); k = t / d; ph = 2 * math.pi * np.cumsum(f0 * (f1 / f0) ** k) / SR; x = sum(np.sin(ph * (h + 1)) / (h + 1) for h in range(harm))
    tr = .6 + .4 * np.sin(2 * math.pi * np.cumsum(tr0 + (tr1 - tr0) * k) / SR); return (x * tr + band(noise(d), f0 * 4, f1 * 8, .8) * nz * k) * (.2 + .8 * k) * np.minimum(1, (d - t) * 20)
def bell(d, f, r=2.76, idx=3., k=5.): t = Tt(d); m = np.sin(2 * math.pi * f * r * t) * idx * np.exp(-k * t / d); return np.sin(2 * math.pi * f * t + m) * np.exp(-k * t / d)
def drone(d, f, det=.7, hf=3):
    t = Tt(d); x = 0
    for i in range(hf):
        for dt in (-det, 0, det): x = x + np.sin(2 * math.pi * (f * (i + 1) + dt * (i + 1)) * t + .4 * np.sin(2 * math.pi * .7 * t)) / (i + 1)
    return x * np.sin(np.pi * np.clip(t / d, 0, 1)) ** .5
def sizzle(d): n = int(SR * d); return hp(lp((rng.random(n) > .996) * rng.normal(0, 1, n), 7000), 800) * 3 * env(d, .001, 3)
def solar(d, f=70): return mixl(boom(d, 1500, f, 3.5), band(noise(d), 200, 4000, .9) * .3 * env(d, .01, 2))
def water(d, f0=300, f1=1500): return mixl(band(noise(d), f0, f1, .5) * env(d, .01, 3), bell(d, 520, 1.6, 2, 7) * .25)
def gong(d, f): t = Tt(d); return sum(np.sin(2 * math.pi * f * r * t + .5 * np.sin(2 * math.pi * 3 * t)) * a * np.exp(-k * t / d) for r, a, k in ((1, 1, 3), (1.5, .7, 4), (2.03, .5, 5), (2.8, .35, 6))) * np.minimum(1, t / .01)
def crystal(d, f): return mixl(*[at(bell(d, f * r, 2.9, 2.2, 6) * .5, i * .07, d) for i, r in enumerate((1, 1.5, 2, 3))])
def glitch(x, p=.15, seg=.03):
    y = x.copy(); n = int(seg * SR)
    for i in range(n, len(y) - 2 * n, n):
        r = rng.random()
        if r < p: y[i:i + n] = y[i - n:i]
        elif r < p * 1.5: y[i:i + n] = 0
    return y
def norm(x, pk=.89):
    x = np.nan_to_num(x); y = x / (np.max(np.abs(x)) + 1e-9) * pk; f = int(.004 * SR); y[:f] *= np.linspace(0, 1, f); y[-f * 4:] *= np.linspace(1, 0, f * 4); return y

SND_E = {"equip": lambda: mixl(solar(1.0, 60), crystal(1.0, 440) * .4), "idle": lambda: drone(3.0, 70, .5) * .25 + band(noise(3.0), 300, 3000, 1.1) * .08,
    "a01_cast": lambda: mixl(whoosh(.5, 600, 5000, .5), sizzle(.4)), "a01_hit": lambda: mixl(impact(.5, 300, 70, .6), sizzle(.4) * .6),
    "a02_rush": lambda: mixl(whoosh(.7, 300, 4500, .7, .5), sizzle(.5)), "a03_storm": lambda: mixl(drone(1.4, 90, 1.2) * .5, whoosh(1.4, 200, 3000, .9)),
    "a04_trap": lambda: mixl(charge(1.0, 80, 400, 3, 14, .4), gong(1.0, 110) * .4), "a05_pierce": lambda: mixl(whoosh(.5, 800, 7000, .5), impact(.4, 600, 100, .7)),
    "a06_throw": lambda: mixl(whoosh(.5, 400, 4000, .6), bell(.4, 1200, 2.4, 2, 9) * .3), "a06_return": lambda: mixl(whoosh(.6, 3000, 400, .6), impact(.3, 200, 80) * .6),
    "a07_well": lambda: mixl(charge(1.4, 50, 200, 2, 10, .5), drone(1.4, 55, 1.0) * .5), "a08_charge": lambda: charge(1.4, 70, 800, 3, 26, .5, 4), "a08_blast": lambda: solar(1.8, 45),
    "a09_guard": lambda: mixl(crystal(.9, 330), drone(.9, 110) * .4), "a10_afterimage": lambda: mixl(glitch(whoosh(.5, 900, 6000, .5), .3), sizzle(.3) * .6),
    "a11_totality": lambda: mixl(gong(2.0, 65), charge(1.6, 40, 160, 2, 10, .5)), "a12_lastlight": lambda: mixl(solar(1.6, 50), crystal(1.2, 660) * .5),
    "u_blacken": lambda: mixl(drone(3.0, 45, 1.3, 4) * .8, gong(3.0, 50)), "u_ascend": lambda: mixl(charge(3.0, 50, 600, 2, 24, .6, 4), crystal(2.5, 330) * .5),
    "u_execute": lambda: mixl(whoosh(1.2, 200, 6000, .9, .8), impact(.8, 250, 55, .8)), "u_totality": lambda: mixl(solar(3.6, 30), gong(3.0, 55) * .6, charge(1.0, 100, 1000, 4, 30)),
    "charge_ready": lambda: mixl(crystal(.8, 523), impact(.3, 200, 90) * .5)}
SND_K = {"equip": lambda: mixl(water(1.0), gong(1.2, 130) * .5), "idle": lambda: drone(3.0, 82, .6) * .22 + band(noise(3.0), 200, 1800, 1.0) * .1,
    "a1_tidal": lambda: mixl(water(1.0, 200, 3000), whoosh(.8, 150, 2500, .8, .6)), "a2_vortex": lambda: mixl(band(noise(1.6), 1200, 120, .8), drone(1.6, 65, 1.1) * .5),
    "a3_prison": lambda: mixl(crystal(.9, 392), gong(1.0, 196) * .5), "a4_skyfall": lambda: mixl(whoosh(.9, 3000, 200, .8, .6), boom(1.3, 1600, 44, 4)),
    "a5_sanctuary": lambda: mixl(crystal(1.4, 262), drone(1.4, 98) * .5), "a6_anchor": lambda: mixl(gong(1.6, 80), boom(1.4, 900, 38, 4)),
    "mark": lambda: mixl(bell(.5, 660, 2.1, 2, 8), water(.4)), "u_seal": lambda: mixl(gong(3.0, 49), charge(2.5, 40, 300, 2, 12, .5), water(2.0, 100, 800) * .5)}
SND_V = {"summon": lambda: mixl(crystal(1.4, 294), drone(1.4, 98) * .4), "idle": lambda: mixl(drone(3.2, 110, .4, 4) * .18, crystal(3.0, 440) * .1), "flinch": lambda: mixl(crystal(.4, 880) * .5, impact(.3, 400, 120) * .5),
    "alert": lambda: mixl(bell(.6, 523, 3.1, 2, 6), whoosh(.5, 600, 3000, .8) * .4),
    "r0_awaken": lambda: mixl(crystal(2.0, 523), charge(1.6, 200, 1200, 3, 18, .3)), "r1_awaken": lambda: mixl(glitch(crystal(2.0, 392), .25), sweep(1.6, 800, 200, 1) * env(1.6, .01, 2) * .4),
    "r2_awaken": lambda: mixl(drone(2.0, 150, 1.5) * .6, crystal(1.8, 311)), "r3_awaken": lambda: mixl(crystal(2.0, 659), boom(1.0, 1500, 70, 4) * .5),
    "r4_awaken": lambda: mixl(glitch(drone(2.0, 90, 1.6), .3) * .7, crystal(1.6, 233) * .5), "r5_awaken": lambda: mixl(gong(3.0, 55), crystal(3.0, 277), charge(2.4, 60, 700, 2, 22, .5)),
    "a01_arrival": lambda: mixl(whoosh(.8, 600, 6000, .6), crystal(.8, 660) * .5), "a02_voidstep": lambda: mixl(glitch(whoosh(.5, 1000, 6000, .5), .3), bell(.4, 440, 3, 3, 8) * .4),
    "a03_witness": lambda: mixl(crystal(1.0, 698), whoosh(.6, 2000, 500, .7) * .4), "a04_reprieve": lambda: mixl(sweep(.9, 200, 1600, 1) * env(.9, .005, 2) * .5, crystal(.8, 392)),
    "a05_gravity": lambda: mixl(charge(1.2, 60, 240, 2, 12, .4), drone(1.2, 65) * .5), "a06_genesis": lambda: mixl(crystal(1.2, 587), boom(1.0, 1400, 55, 4) * .6, whoosh(.9, 300, 4000, .8)),
    "a07_ashes": lambda: mixl(band(noise(1.4), 3000, 300, .9) * .8, drone(1.4, 82, 1.4) * .4), "a08_domain": lambda: mixl(gong(2.0, 110), crystal(1.8, 330) * .5),
    "a09_horizon": lambda: mixl(glitch(whoosh(.8, 800, 5000, .6), .3), crystal(.8, 740) * .5), "a10_law": lambda: mixl(glitch(gong(1.6, 90), .3), sweep(1.0, 1500, 120, 1) * env(1.0, .01, 3) * .5),
    "a11_reckoning": lambda: mixl(*[at(crystal(1.4, f) * .5, i * .12, 1.8) for i, f in enumerate((262, 330, 392, 494, 587, 698))], boom(1.4, 1400, 50, 4) * .6),
    "a12_charge": lambda: mixl(charge(3.0, 40, 800, 2, 28, .6, 5), crystal(3.0, 220) * .6), "a12_strike": lambda: mixl(boom(3.0, 2600, 32, 3), crystal(2.4, 440) * .5, whoosh(1.4, 100, 6000, 1.0, 1.0)),
    "relic_place": lambda: mixl(gong(1.4, 180), crystal(1.0, 523) * .5), "relic_item": lambda: crystal(.8, 659) * .8}

def sounds(S, table):
    tmp = os.path.join(ROOT, "tools", "_tmp"); os.makedirs(tmp, exist_ok=True); names = []
    for n, fn in table.items():
        x = norm(np.asarray(fn(), float)); w = os.path.join(tmp, n + ".wav"); wavfile.write(w, SR, (x * 32767).astype(np.int16))
        if subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", w, "-ac", "1", "-ar", str(SR), "-c:a", "libvorbis", "-q:a", "4", os.path.join(S.dir, "sounds", n + ".ogg")]).returncode: sys.exit("ffmpeg failed " + n)
        names.append(n)
    shutil.rmtree(tmp, ignore_errors=True)
    json.dump({n: {"sounds": [{"name": f"{S.ns}:{n}", "stream": n == "idle"}], "subtitle": f"subtitles.{S.ns}.{n}"} for n in names}, open(os.path.join(S.dir, "sounds.json"), "w"), indent=1)
    json.dump({f"subtitles.{S.ns}.{n}": n.replace("_", " ") for n in names}, open(os.path.join(S.dir, "lang", "en_us.json"), "w"), indent=1)
    return len(names)

if __name__ == "__main__":
    out = {}
    for fn, tab in ((build_eclipse, SND_E), (build_keeper, SND_K), (build_vorathis, SND_V)):
        S = fn(); out[S.ns] = (len(S.n), sounds(S, tab))
    json.dump({"pack": {"pack_format": 46, "supported_formats": {"min_inclusive": 46, "max_inclusive": 99}, "description": "DeS Weapon Expansion: ECLIPSE / KEEPER'S TRIDENT / VORATHIS"}}, open(os.path.join(PACK, "pack.mcmeta"), "w"), indent=1)
    ic = np.zeros((64, 64, 4), np.uint8); ic[..., 3] = 255
    for i in range(64):
        for j in range(64):
            d = math.hypot(i - 32, j - 32); ic[i, j, :3] = (255, 130, 10) if 14 < d < 20 else (40, 220, 210) if 24 < d < 28 else (235, 215, 140) if d < 8 else (10, 10, 12)
    Image.fromarray(ic).save(os.path.join(PACK, "pack.png")); print(out)
