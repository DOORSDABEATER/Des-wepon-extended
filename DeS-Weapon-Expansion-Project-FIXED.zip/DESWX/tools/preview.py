import json, math, os, sys
import numpy as np
from PIL import Image, ImageDraw
from scipy.spatial import ConvexHull
ROOT=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
def rot(p,ang,axis,org):
    a=math.radians(ang); c,s=math.cos(a),math.sin(a); x,y,z=p-org
    if axis=='z': x,y=x*c-y*s,x*s+y*c
    elif axis=='y': x,z=x*c+z*s,-x*s+z*c
    else: y,z=y*c-z*s,y*s+z*c
    return np.array([x,y,z])+org
def render(ns,name,S=7,size=(48,48),view='front'):
    A=f'{ROOT}/resourcepack/assets/{ns}'; atlas=np.array(Image.open(A+'/textures/item/atlas.png').convert('RGBA'))[:64]
    m=json.load(open(f'{A}/models/item/{name}.json')); items=[]
    for e in m['elements']:
        f=np.array(e['from'],float); t=np.array(e['to'],float)
        cs=np.array([[x,y,z] for x in (f[0],t[0]) for y in (f[1],t[1]) for z in (f[2],t[2])])
        if 'rotation' in e: r=e['rotation']; cs=np.array([rot(c,r['angle'],r['axis'],np.array(r['origin'],float)) for c in cs])
        u0,v0,u1,v1=[c*4 for c in e['faces']['north']['uv']]; reg=atlas[int(v0):int(v1),int(u0):int(u1)].reshape(-1,4).astype(float); reg=reg[reg[:,3]>0] if (reg[:,3]>0).any() else reg
        items.append((cs,reg[:,:3].mean(0)*(1.2 if 'light_emission' in e else 1.0)))
    W=size[0]*S+20; img=Image.new('RGB',(W,size[1]*S+20),(18,20,22)); d=ImageDraw.Draw(img)
    P=lambda c:(((c[0]+8)*S+10,(24-c[1])*S+10),c[2])
    items.sort(key=lambda it: np.mean([P(c)[1] for c in it[0]]))
    for cs,col in items:
        pts=np.array([P(c)[0] for c in cs])
        try: h=ConvexHull(pts)
        except Exception: continue
        d.polygon([tuple(pts[i]) for i in h.vertices],fill=tuple(int(v) for v in np.clip(col,0,255)),outline=(0,0,0))
    return img
tiles=[('deswx_eclipse','chakram'),('deswx_keeper','trident'),('deswx_vorathis','core_4'),('deswx_vorathis','frag_unnamed_awake'),('deswx_vorathis','relic_witness'),('deswx_vorathis','core_0')]
imgs=[render(n,m) for n,m in tiles]; w=sum(i.width for i in imgs[:3]); H=imgs[0].height
sheet=Image.new('RGB',(imgs[0].width*3,H*2),(18,20,22))
for k,i in enumerate(imgs): sheet.paste(i,((k%3)*imgs[0].width,(k//3)*H))
sheet.save(f'{ROOT}/documentation/model_previews.png'); print(sheet.size)
