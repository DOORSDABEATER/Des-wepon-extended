import re,sys,os
src=open(sys.argv[1]).read(); out=sys.argv[2]
parts=re.split(r'^//// FILE: (\S+)\n',src,flags=re.M)
for i in range(1,len(parts),2):
    p=os.path.join(out,parts[i]); os.makedirs(os.path.dirname(p),exist_ok=True); open(p,'w').write(parts[i+1])
print(len(parts)//2,'files')
